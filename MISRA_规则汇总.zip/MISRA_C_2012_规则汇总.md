# MISRA C:2012 全部规则汇总

来源：`/data2/lgf/MISRA/MISRA_C_Guidelines_2012.pdf`　｜　生成自 ValiantSec 规则库（xls 元数据 + desc 规则详情）

共 **143** 条规则 + **16** 条指令（Directive）。等级分布：强制 150 条、推荐 9 条。

---

> **阅读约定**
> 
> - 等级：**强制**（Required/Mandatory）、**推荐**（Advisory）、**文档**（Document，指需以文档形式满足的要求）
> - 「例外」条款直接决定规则是否适用于当前代码，务必先读例外再看规则
> - 标注「原文未给出该类型的独立示例」的条目，表示标准原文仅有另一类示例或仅有文字说明，未作补充创作
> - 小节标题为「原文示例（合规与不合规写法混排）」时，表示标准原文把两类写法放在同一段代码里，`// Compliant` 标记合规写法、`// Non-compliant` 标记不合规写法，本汇总未擅自拆分

---

## 目录

- [第 1 章 环境](#第-1-章-环境3-条)　（3 条）
- [第 2 章 未使用的代码](#第-2-章-未使用的代码7-条)　（7 条）
- [第 3 章 注释](#第-3-章-注释2-条)　（2 条）
- [第 4 章 字符集和词法规定](#第-4-章-字符集和词法规定2-条)　（2 条）
- [第 5 章 标识符](#第-5-章-标识符9-条)　（9 条）
- [第 6 章 基本类型](#第-6-章-基本类型2-条)　（2 条）
- [第 7 章 文字和常量](#第-7-章-文字和常量4-条)　（4 条）
- [第 8 章 声明与定义](#第-8-章-声明与定义14-条)　（14 条）
- [第 9 章 初始化](#第-9-章-初始化5-条)　（5 条）
- [第 10 章 类型](#第-10-章-类型8-条)　（8 条）
- [第 11 章 指针类型转换](#第-11-章-指针类型转换9-条)　（9 条）
- [第 12 章 表达式](#第-12-章-表达式4-条)　（4 条）
- [第 13 章 副作用](#第-13-章-副作用6-条)　（6 条）
- [第 14 章 控制语句表达式](#第-14-章-控制语句表达式4-条)　（4 条）
- [第 15 章 控制流](#第-15-章-控制流7-条)　（7 条）
- [第 16 章 switch语句](#第-16-章-switch语句7-条)　（7 条）
- [第 17 章 函数](#第-17-章-函数8-条)　（8 条）
- [第 18 章 指针和数组](#第-18-章-指针和数组8-条)　（8 条）
- [第 19 章 重叠存储](#第-19-章-重叠存储2-条)　（2 条）
- [第 20 章 预处理命令](#第-20-章-预处理命令14-条)　（14 条）
- [第 21 章 标准库](#第-21-章-标准库12-条)　（12 条）
- [第 22 章 资源](#第-22-章-资源6-条)　（6 条）
- [指令（Directives）](#指令directives16-条)　（16 条）

---

## 第 1 章 环境（3 条）

### MISRA_C_2012_01_01_rule　程序不得违反标准C语法和约束，并且不得超出具体实现的编译限制
> 等级：**强制**　分类：环境


程序应仅使用所选标准版本中指定的C语言及其库的功能。该标准允许实现提供语言扩展，并且该规则允许使用此类扩展。除非使用语言扩展，否则程序不得有以下行为：
◆ 包含任何违反标准中描述的语言语法的内容；
◆ 包含任何违反标准规定约束条件的内容。

**示例1：不规范用法**

```c
__inline int fun(int x)
{
    return x*5+1; //not complaint
}
编译器不支持__inline关键字
```

**示例1：规范用法之一**

```c
__inline int fun(int x)
{
    return x*5+1; //complaint
}
编译器支持__inline关键字
```

### MISRA_C_2012_01_02_rule　不应该使用语言扩展
> 等级：**强制**　分类：环境


依赖语言扩展的程序的可移植性较不依赖语言扩展的程序低。尽管本标准要求了符合标准的实施文档要提供语言的所有扩展，但仍存在无法完整描述所有情况的风险。
如果不使用此规则，则应在项目的设计文档中明确说明每种被使用的语言扩展。且应记录每个扩展的有效使用方法，如编译检测方法和诊断方法。
人们已经认识到，在嵌入式系统中使用语言扩展很有必要。但本标准要求语言的扩展不能改变任何严格符合程序的行为。例如，作为一项语言扩展功能，编译器可能会实施对二进制逻辑运算符的全面评估，
尽管标准规定了一旦确定结果就立即停止评估。这样的扩展，就不符合标准，因为在逻辑与运算符的右操作数中总会产生副作用，从而产生非预期的行为。

**示例1：不规范用法**

```c
bool (*FuncPointer)();
voi fun()
{
    if ((NULL != FuncPointer) && (*FuncPointer())) // 不合法
    {
        // ...
    }
}
上述语句是符合语法的，且就是利用了“一旦确定结果立即停止评估”的特性，在FuncPointer 值为NULL时执行“&&”的右操作数会非常危险，程序会跑到哪完全不可预知。
```

**示例1：规范用法**

```c
bool (*FuncPointer)();
voi fun()
{
    if (NULL != FuncPointer) // 合法
    {
        if(*FuncPointer())
        {
            // ...
        }
    }
}
```

### MISRA_C_2012_01_03_rule　不能有对未定义行为或未指定行为的依赖性。
> 等级：**强制**　分类：环境

引起未定义或未指定行为的任何程序都可能无法以预期的方式运行。在许多情况下，其结果仅仅是使程序不可移植，但也可能发生更严重的问题。例如，未定义的行为可能会影响计算结果。如果软件的正确执行取决于此计算，则可能会损害系统安全性。如果未定义的行为仅在极少数情况下才表现出来，则该问题将尤其难以检测到。

**示例1：不规范用法**

```c
int fun()
{
    int aa;int bb; //not complaint
    int ee=1,
    int ff=2;int gg=1; //not complaint
}
```

**示例1：规范用法之一**

```c
int fun()
{
    int aa;
    int bb;
    int ee=1,
    int ff=2;
    int gg=1;
}
将表达式拆分成两行
```

---

## 第 2 章 未使用的代码（7 条）

### MISRA_C_2012_02_01_rule　不能有不可达的代码
> 等级：**强制**　分类：未使用的代码


如果程序没有表现出任何未定义的行为，则无法执行不可达代码，并且不会对程序的输出产生任何影响。 因此，存在不可达代码可以表示存在程序逻辑错误。
一般编译器会在编译时移除所有不可达代码，尽管它并非必须这么做。而那些无法被编译器移除的不可达代码将造成资源浪费，比如：
◆ 它占用目标设备的内存空间；
◆ 它的存在可能导致编译器在围绕不可达代码进行控制权转移时选择更长、更慢的跳转指令；
◆ 在循环中，它可能会阻止整个循环驻留在指令缓存中。
有时，人们会主动插入一段看起来不可达的代码，用以处理特殊情况。例如，在switch 语句中，控制表达式的每个可能值都由显式情况描述，而default 子句应根据规则16.4 出现。default 子句的用途是捕获通常不应该出现但可能由于以下原因而生成的值：
◆ 程序中存在未定义的行为；
◆ 处理器硬件故障。
如果编译器能够确认default 子句不可达，则可以将其删除，从而清除该防御措施。如果该防御措施非常重要，则下述两者必须满足其一：要么保证编译器在证实不可达时仍保留该代码，要么采取措施使防御代码可达。前者与本规则有偏差，可能需要检查目标代码或使用单元测试来保证这种偏差。后者通常可以通过易失性(volatile)访问来实现。举例来说，编译器一般在执行switch 语句前，已经确定了其条件x的值是否被case 子句所覆盖，如：
uint16_t x;
switch (x)
而通过强制将x 识别为易失性左值的方式来访问它，编译器就必须假定这个表达式可以有任何值：
switch ( *( volatile uint16_t * ) &x )

**示例1：不规范用法**

```c
enum light { red, amber, red_amber, green };
enum light next_light ( enum light c )
{
   enum light res;
  switch ( c )
   {
        case red:
             res = red_amber;
            break;
         case red_amber:
             res = green;
             break;
         case green:
             res = amber;
              break;
        case amber:
            res = red;
             break;
        default:
         {
                break;
         }
   }
    return res;
    res = c; /* Non-compliant - this statement is certainly unreachable */
}
```

**示例1：规范用法之一**

```c
enum light { red, amber, red_amber, green };
enum light next_light ( enum light c )
{
   enum light res;
  switch ( c )
   {
        case red:
             res = red_amber;
            break;
         case red_amber:
             res = green;
             break;
         case green:
             res = amber;
              break;
        case amber:
            res = red;
             break;
        default:
         {
                break;
         }
   }
    res = c;
    return res;
}
第[25]行语句[res = c]在退出语句之前，代码都会执行
```

### MISRA_C_2012_02_02_rule　不得有无效代码
> 等级：**强制**　分类：未使用的代码


不论保留其执行还是被删除，均不会影响影响程序行为的操作，即构成无效代码。此处，我们假定语言扩展所引用的操作始终会对程序行为产生影响。
注意：在嵌入式系统中，通常情况下程序的行为不仅取决于它们的执行性质，还取决于它们发生的时间。
注意：不可达代码不是无效代码，因为它们不会被执行。不可达代码与无效代码的差别：不可达代码不会被执行，无效代码会被执行。
无效代码的存在，可能表明程序逻辑中存在错误。由于无效代码可能会被编译器删除，因此它可能会引起混乱。
例外:
强制转换为void 是显示声明有意不使用的值。因此，强制转换本身不是无效代码。它被视为使用了操作数的值，所以它不被定性为无效代码。

**示例1：不规范用法**

```c
void h(void)
{
    g(); /* 违规 - 该调用可以被移除 */
}
```

**示例1：规范用法之一**

```c
void g(void)
{
    /* 合规 - 此函数中无任何操作 */
}
```

### MISRA_C_2012_02_03_rule　不能有无用的类型声明
> 等级：**强制**　分类：未使用的代码


如果一个类型被声明但从未被使用过，对于审阅者来说，无法确定该声明是多余的还是被错误闲置的。

**示例1：不规范用法**

```c
typedef unsigned int uInt; //not compliant
int fun(void)
{
  unsigned int a;
  long b;
  /*...*/
  return 0;
}
```

**示例1：规范用法之一**

```c
typedef unsigned int uInt; // compliant
int fun(void)
{
  uInt a;
  long b;
  /*...*/
  return 0;
}
不存在无用的类型声明
```

### MISRA_C_2012_02_04_rule　不能有无用的tag声明
> 等级：**强制**　分类：未使用的代码


如果一个类型标签被声明但从未被使用过，对于审阅者来说，无法确定该类型标签是多余的还是被错误闲置的。

**示例1：不规范用法**

```c
#include <stdint.h>
void unusedtag ( void )
 {
    enum state { S_init, S_run, S_sleep}; /* Non-compliant */
 }

typedef struct record_t /* Non-compliant */
{
    uint16_t key;
    uint16_t val;
} record1_t;
```

**示例1：规范用法之一**

```c
void usedtag ( void )
 {
    enum state1 { S_init, S_run, S_sleep}; /* compliant */
    enum state1 a;
    switch(a)
    {
    case S_init:
    case S_run:
        break;
    default:
        return;
    }
 }
typedef struct /* Compliant */
{
     uint16_t key;
     uint16_t val;
} record2_t;
没有无用的tag声明。
```

### MISRA_C_2012_02_05_rule　不能有无用的宏声明
> 等级：**强制**　分类：未使用的代码


如果一个宏被声明但从未被使用过，对于审阅者来说，无法确定该宏是多余的还是被错误闲置的。

**示例1：不规范用法**

```c
#define SIZE_USED 6
#define DATA 3 /* not compliant */

int static_628(void)
{
	return SIZE_USED;
}
```

**示例1：规范用法之一**

```c
#define SIZE_USED 6
#define DATA 3
int good_static_628(void)
{
	return SIZE_USED+DATA;
}
所有的宏都被使用。
```

### MISRA_C_2012_02_06_rule　函数内不能包含无用的标号声明
> 等级：**强制**　分类：未使用的代码


如果一个执行标签(label)被声明但从未被使用过，对于审阅者来说，无法确定该执行标签是多余的还是被错误闲置的。

**示例1：不规范用法**

```c
void unused_label ( void )
{
int x = 6;
label1: /* Non-compliant */
  use_int16 (x);
}
```

**示例1：规范用法之一**

```c
int fun1(void)
{
  int a;
  lable2:
    a=3;
  if(a>0)
    goto lable2;
  return 0;
}
函数中不包含无用的标号声明
```

### MISRA_C_2012_02_07_rule　函数参数未被使用
> 等级：**强制**　分类：未使用的代码

函数参数未被使用

**示例1：不规范用法**

```c
void withunusedpara ( char *para1,int unusedpara ) /* Non-compliant - unused */
{
*para1 = 42U;
}
```

**示例1：规范用法之一**

```c
void withunusedpara ( char *para1,int unusedpara )
{
*para1 = 42U;
 unusedpara = 0；
}
函数参数[para1]、[unusedpara]均被使用
```

---

## 第 3 章 注释（2 条）

### MISRA_C_2012_03_01_rule　字符序列/*与// 不应出现在注释中。
> 等级：**强制**　分类：注释

字符序列“/*”和“//”不得在注释中使用

**示例1：不规范用法**

```c
/* some comment, end comment marker accidentally omitted
<<New Page>>
Perform_Critical_Safety_Function( X );
/* this comment is non-compliant */
void misra2012_3_1(void)
{
    int x,y,z;
    x = y // /*
            + z
         // */
        ;
}
```

**示例1：规范用法之一**

```c
/* some comment, end comment marker accidentally omitted
<<New Page>>
Perform_Critical_Safety_Function( X );
 this comment is compliant */
void misra2012_3_1(void)
{
    int x,y,z;
    x = y + z ; /*cccccc*/
}
不存在多行注释嵌套的情况
```

### MISRA_C_2012_03_02_rule　“//”注释中不得使用换行
> 等级：**强制**　分类：注释

“//”注释中不得使用续行符（反斜杠）延续到下一行。
单行注释若以反斜杠结尾，会因行拼接而把下一行代码并入注释。

**示例1：不规范用法**

```c
extern bool_t b;
void f(void)
{
    uint16_t x = 0; // comment \
    if (b)
    {
        ++x; /* if 语句被作为注释处理, 这里无条件执行 */
    }
}
```

**示例1：规范用法之一**

```c
extern bool_t b;
void f(void)
{
    uint16_t x = 0; // comment if (b)
    {
        ++x;
    }
}
单行注释直接单行写完，不加换行
```

---

## 第 4 章 字符集和词法规定（2 条）

### MISRA_C_2012_04_01_rule　不应使用八进制和十六进制编码序列。
> 等级：**强制**　分类：字符集和词法规定

不应使用八进制和十六进制换码顺序。

**示例1：不规范用法**

```c
void misra2012_4_1()
{
    int c1 = '\141'; /* Non-compliant */
}
```

**示例1：规范用法之一**

```c
void misra2012_4_1()
{
    int c1 = 97 ; /* -compliant */
}
第[3]行使用了八进制对应的十进制数
```

### MISRA_C_2012_04_02_rule　不能使用三字母词（trigraphs）。
> 等级：**强制**　分类：字符集和词法规定

不能使用三字母词（trigraphs）。

**示例1：不规范用法**

```c
void fun(){
  printf("Delete file (are you really sure??):");	//	not compliant
  printf("Delete file (are you really sure??=):");	//	not compliant
  printf("Delete file (are you really sure??(:");	//	not compliant
}
```

**示例1：规范用法之一**

```c
void fun(){
  printf("Delete file (are you really sure]:");	// compliant
  printf("Delete file (are you really sure#):");	// compliant
  printf("Delete file (are you really sure[:");	// compliant
}
第[2]、[3]、[4]行分别使用了三字母词对应的字符，不会造成混淆
```

---

## 第 5 章 标识符（9 条）

### MISRA_C_2012_05_01_rule　外部变量可以被区分
> 等级：**强制**　分类：标识符

外部变量可以被区分

**示例1：不规范用法**

```c
int32_t engine_exhaust_gas_temperature_raw;
int32_t engine_exhaust_gas_temperature_scaled; /* Non-compliant */
```

**示例1：规范用法之一**

```c
int32_t engine_exhaust_gas_temperature_raw;
int32_t help_bmkl_gas_temperature_scaled;
第[2]行外部变量与第[1]行的外部变量的前31个字符不一样
```

### MISRA_C_2012_05_02_rule　相同作用域的变量可以被区分
> 等级：**强制**　分类：标识符

相同作用域的变量可以被区分

**示例1：不规范用法**

```c
extern int engine_exhaust_gas_temperature_raw;
static int engine_exhaust_gas_temperature_scaled; /* Non-compliant */
```

**示例1：规范用法之一**

```c
void f ( void )
{
int engine_exhaust_gas_temperature_local; /* Compliant */
}

static int engine_exhaust_gas_temp_raw;
static int engine_exhaust_gas_temp_scaled; /* Compliant */
第[2]行的变量与其他变量不属于同一作用域，且第[6]、[7]行的两个相同作用域的变量的前31个字符不一样
```

### MISRA_C_2012_05_03_rule　内部作用域的标识符与外部作用域的标识符重名。
> 等级：**强制**　分类：标识符

内部作用域的标识符与外部作用域的标识符重名。

**示例1：不规范用法**

```c
int fun()
{
    int i; //not compliant
    if(i)
    {
        long i;
    }
    return 0；
}
```

**示例1：规范用法之一**

```c
int fun()
{
    int i; // compliant
    if(i)
    {
        long ll;
    }
    return 0；
}
第[6]行的变量[i]与第[3]行外层的变量[i]未重名
```

### MISRA_C_2012_05_04_rule　宏名称唯一。
> 等级：**强制**　分类：标识符

宏名称唯一。

**示例1：不规范用法**

```c
#define A012347890234567890DEFINE(X,Y,Z) (X)+(Y)+(Z) //not compliant
int A012347890234567890DEFINE; //Not compliant
```

**示例1：规范用法之一**

```c
#define A012347890234567890DEFINE(X,Y,Z) (X)+(Y)+(Z)
int FINE;
第[1]行的宏与第[2]行的变量名的前31个字符不一样
```

### MISRA_C_2012_05_05_rule　标识符名称和宏的名称一致。
> 等级：**强制**　分类：标识符

标识符名称和宏的名称一致。

**示例1：不规范用法**

```c
#define a 1
int fun()
{
   int a; //not compliant
}
```

**示例1：规范用法之一**

```c
#define a 1
int fun()
{
   int a1;
}
修改第[4]行的变量为[a1],y与第[1]行的宏名[a]不重名
```

### MISRA_C_2012_05_06_rule　typedef名称应唯一
> 等级：**强制**　分类：标识符

typedef名称应唯一

**示例1：不规范用法**

```c
typedef int INT;
INT out;
typedef unsigned char unit8_t; //Not Compliant
int main(void)
{
    typedef float unit8_t; //Not Compliant
}
```

**示例1：规范用法之一**

```c
typedef int INT;
INT out;
typedef unsigned char unit8_t;
int main(void)
{
    typedef float float32_t;
}
修改第[6]行的自定义类型为不同的类型
```

### MISRA_C_2012_05_07_rule　标签(tag)名称必须是唯一的标识符。
> 等级：**强制**　分类：标识符

标签(tag)名称必须是唯一的标识符。

**示例1：不规范用法**

```c
struct stag{ int a; int b}
void fun(int stag) //Not compliant
{
}
```

**示例1：规范用法之一**

```c
struct stag{ int a; int b}
void fun(int stags) // compliant
{
}
修改第[2]行的参数名为不同的名称
```

### MISRA_C_2012_05_08_rule　具有外部作用域的对象或者函数标识符应该唯一
> 等级：**强制**　分类：标识符

具有外部作用于的对象或者函数标识符应该唯一

**示例1：不规范用法**

```c
/* file1.c */
int count;
void foo ( void )
{
int index;
}
/* file2.c */
static void foo ( void ) /* Non-compliant*/
{

int count; /* Non-compliant*/
int index; /* Compliant - "index" has no linkage */
}
```

**示例1：规范用法之一**

```c
/* file1.c */
int count;
void foo ( void )
{
int index;
}
/* file2.c */
static void foo_s ( void ) /*compliant*/
{

int count_s; /* compliant*/
int index; /* Compliant - "index" has no linkage */
}
修改外部作用的标识符，使之与其他标识符不重名
```

### MISRA_C_2012_05_09_rule　静态标识符必须唯一
> 等级：**强制**　分类：标识符

静态标识符必须唯一

**示例1：不规范用法**

```c
static int count;
static void foo(void)
{
char count; /* Non-compliant */
char index;
}
void bar1 ( void )
{
static char count; /* Non-compliant */
char index;
foo ();
}
```

**示例1：规范用法之一**

```c
static int count;
static void foo(void)
{
char count_s; /*compliant */
char index;
}
void bar1 ( void )
{
static char count_b; /*compliant */
char index;
foo ();
}
修改其他变量名，使之与静态变量名不重名
```

---

## 第 6 章 基本类型（2 条）

### MISRA_C_2012_06_01_rule　位的定义必须是有符号整数或无符号整数
> 等级：**强制**　分类：基本类型


位域类型为：
◆ C90：unsigned int 或 signed int；
◆ C99：下列几种之一：
\  - unsigned int 或 signed int；
\  - 实现允许的其他显示声明的有符号或无符号整数类型；
\  - _Bool(C99 新增的布尔类型“bool”是它的同名宏，详见C99 stdbool.h)；
注意：允许使用typedef 来定义适当的类型。
“int”随具体实现(编译环境等)的不同可能为有符号也可能为无符号。
C90 中不允许使用enum、short、char 或其他任何类型，是因为它们的具体实现无法确定。不同的编译环境，对这些类型的符号和数据长度定义会不一致。
C99 中，实现可以定义位域声明中允许的其他整数类型。一般的C99 编译环境都会有选项，供选择enum、short、char 是否有符号和数据长度，这些确认后，其是否可用于位域声明自然也就明确了。

**示例1：不规范用法**

```c
struct s {
    int b2:2; /* 违规 - 不允许使用不明确符号的"int" */
    signed long b4:2; /* 违规 - 即使 long 和 int 大小相同 */
};
```

**示例1：规范用法之一**

```c
typedef unsigned int UINT_16;
struct s {
    unsigned int b1:2; /* 合规 */
    UINT_16 b3:2; /* 合规 - 由typedef声明的"unsigned int" */
};
```

### MISRA_C_2012_06_02_rule　单比特位域不应是有符号的类型
> 等级：**强制**　分类：基本类型


根据C99 标准第6.2.6.2 节，一个单比特(single-bit)带符号的位域数据具有1 个符号位和0 个值位。在任何整数表示中，0 个值位都无法指定有意义的值。
因此，一个单比特(single-bit)带符号的位域数据不太可能以有用的方式允许，而且它的存在也会给程序员带来困惑。
虽然C90 标准没有提供太多有关类型表示的详细信息，但与C99 相同的注意事项也适用。

**示例1：不规范用法**

```c
struct bs
{
  short s:1; //not complaint
  signed int i:1; //not complaint
}data;
```

**示例1：规范用法之一**

```c
struct bs
{
  short s:2; // complaint
  signed int i:2; // complaint
}data;
修改第[3]、[4]的有符号类型的变量的位域长度是2
```

---

## 第 7 章 文字和常量（4 条）

### MISRA_C_2012_07_01_rule　不能使用八进制常量。
> 等级：**强制**　分类：文字和常量

开发人员编写的常量前导零可能会被误读为十进制常量。八进制常数的表述方式：0**。
注意：此准则不适用于八进制转义序列，因为使用前导“\”字符混淆的范围较小。
例外：
整数常数零(写为“0”)严格来说是八进制常数，但是是本准则的允许例外。

**示例1：不规范用法**

```c
void main()
{
	int a=012; //Not compliant
	int i;
	for(i=01;i<012;i++) //Not compliant
	{
	}
}
```

**示例1：规范用法之一**

```c
void main()
{
	int a=12;
	int i;
	for(i=01;i<12;i++)
	{
	}
}
第[3]、[5]行使用十进制常量[12]
```

### MISRA_C_2012_07_02_rule　后缀“U”应该用在所有 unsigned类型的常量上。
> 等级：**强制**　分类：文字和常量

后缀“U”应该用在所有 unsigned类型的常量上。

**示例1：不规范用法**

```c
unsigned int a = 0x8000; // 违规
```

**示例1：规范用法之一**

```c
unsigned int b = 32768u; // 合规
```

### MISRA_C_2012_07_03_rule　l不能做后缀
> 等级：**强制**　分类：文字和常量


在声明文字时，使用大写后缀“L”可消除“1”(数字1)和“l”(字母“ el”)之间的潜在歧义。

**示例1：不规范用法**

```c
/*
l不能做后缀
*/
#include <stdio.h>
int main()
{
     long a = 0L;
     int b = 0l; /* Non-compliant */
     return 0;
}
```

**示例1：规范用法之一**

```c
/*
l不能做后缀
*/
#include <stdio.h>
int main()
{
     long a = 0L;
     int b = 0L;
     return 0;
}
第[8]行使用大写字母'L'作为后缀
```

### MISRA_C_2012_07_04_rule　字符串常量只能赋值给const char 指针
> 等级：**强制**　分类：文字和常量

字符串常量只能赋值给const char 指针

**示例1：不规范用法**

```c
extern void f1 ( char *s1 );
void g ( void )
{
	f1 ( "string" ); /* Non-compliant*/
}
char *name1 ( void )
{
	return ( "MISRA" ); /* non-compliant*/
}
int fun(int ia)
{
	char* str = "abc"; /* non-compliant*/
}
```

**示例1：规范用法之一**

```c
/* 合规 - p 有 const 修饰; 其他限定词是可接受的 */
const volatile char *p = "string";

extern void f2(const char *s2);
void g(void)
{
    f2("string"); /* 合规 */
}
const char *name2(void)
{
    return ("MISRA"); /* 合规 */
}
```

---

## 第 8 章 声明与定义（14 条）

### MISRA_C_2012_08_01_rule　声明缺少类型。
> 等级：**强制**　分类：声明与定义

C90 标准允许在某些情况下省略类型，在这种情况下，将隐式指定int 类型。 可能使用隐式int 的情况示例如下：
◆ 对象声明；
◆ 形参声明；
◆ 成员声明；
◆ typedef 声明；
◆ 函数返回类型。
省略显式类型声明可能会导致混淆。 例如，在声明中：
extern void g(char c, const k);
k 的类型隐式定义为const int，而实际可能期望为const char。

**示例1：不规范用法**

```c
extern a; //not complaint
int main()
{
   return 0;
}
```

**示例1：规范用法之一**

```c
extern int b; //complaint
int main()
{
   return 0;
}
第[1]行声明了[int]类型的变量[b]
```

### MISRA_C_2012_08_02_rule　函数参数要正确声明。
> 等级：**强制**　分类：声明与定义

函数参数要正确声明。

**示例1：不规范用法**

```c
#include<stdio.h>
int fun1(int); //not compliant
int fun(int a)
{
 return 0;
}
int fun2(int c,int) //not compliant
{
}
```

**示例1：规范用法之一**

```c
#include<stdio.h>
int fun1(int b); // compliant
int fun(int a)
{
 return 0;
}
int fun2(int c,int v) //compliant
{
}
int fun3(void)
{
}
为第[2]行的函数参数添加标识符名
```

### MISRA_C_2012_08_03_rule　对象或函数的所有声明必须使用相同的名称和类型。
> 等级：**强制**　分类：声明与定义

存储类说明符不在此规则的限定范围内。
同一对象或函数的声明使用一致类型和限定符会使代码更强壮。
在函数原型中指定形参名称可以检查函数定义及其声明的接口一致性。
例外:
相同基本类型的兼容版本可以互换使用。 例如，int，signed 和signed int 都是等效的。但仍建议显式使用完全相同的描述。

**示例1：不规范用法**

```c
int fun(int b);
int fun(int a) //Not compliant
{
    return a;
}
```

**示例1：规范用法之一**

```c
int fun(int b);
int fun(int b) //compliant
{
    return a;
}
第[2]行的函数定义的参数名[b]与第[1]行的函数声明的参数名[b]名称一致
```

### MISRA_C_2012_08_04_rule　当对象或函数具有外部链接时，他们兼容的外部声明必须是可见的
> 等级：**强制**　分类：声明与定义

当对象或函数具有外部链接时，他们兼容的外部声明必须是可见的

**示例1：不规范用法**

```c
int count = 0; /*Non Compliant */
extern int speed = 6000u; /* Non-compliant - no declaration*/
void func1 ( void )
{
/*Non Compliant */
}
```

**示例1：规范用法之一**

```c
extern int count;
int count = 0; /* Compliant */
extern int speed;
extern int speed = 6000u; /* compliant n*/
extern void func1 ( void );
void func1 ( void )
{
/* Compliant */
}
为第[1]、[2]行的全局变量[count]、[speed]添加声明；为第[3]行的函数[func1]添加声明
```

### MISRA_C_2012_08_05_rule　外部对象或变量只能在一个文件中被声明一次。
> 等级：**强制**　分类：声明与定义

将单一的声明放在头文件中，该头文件再被任何需要调用该标识符的编译单元包含，这是种通常做法。这种做法可以确保：
◆ 声明和定义的一致性；
◆ 不同编译单元中的声明的一致性。
注意：一个项目中可能会有很多的头文件，但是每个外部对象和函数只能在一个头文件中进行声明。

**示例1：不规范用法**

```c
//file1.h
extern int a;
//file2.h
extern int a; //not compliant
extern int b;
//main.c
#include "file1.h"
#include "file2.h"
int a = 0;
int b = 0;
```

**示例1：规范用法之一**

```c
//file1.h
extern int a;
//file2.h
extern int b;
//main.c
#include "file1.h"
#include "file2.h"
int a = 0;
int b = 0;
extern变量a被声明一次，只在file1.h头文件中
```

### MISRA_C_2012_08_06_rule　具有外部链接的标识符应该具有准确的外部定义。
> 等级：**强制**　分类：声明与定义

存在多个定义的标识符或是没有定义的标识符，其实现行为都是未定义的。即使定义相同，此规则也不允许在不同文件中使用多个定义(编译器也不允许)。如果有多个声明且声明有不同，则其行为也为未定义。

**示例1：不规范用法**

```c
//file1.c
int a = 0；
//file2.c
int a = 0; //not compliant
int b =1;
```

**示例1：规范用法之一**

```c
//file1.c
int a = 0；
//file2.c
int b = 1;
全局变量a有单一的定义，定义在file1.c文件中
```

### MISRA_C_2012_08_07_rule　函数或对象如果只在一个转换单元被使用，不应该被定义为extern的
> 等级：**强制**　分类：声明与定义


将对象定义为内部链接(internal linkage)或临时(no linkage)属性，可以限制对象的可见范围，从而减少无意中访问该对象的机会。同理，赋予函数局部属性，也可降低其可见性，从而减少无意中调用该函数的机会。
遵守此规则还避免了不同翻译单元或库的同名标识符之间出现混淆的可能。

**示例1：不规范用法**

```c
//a.cpp
int b;
b = 1;
//b.cpp
extern int a; //not compliant
a = 5;
```

**示例1：规范用法之一**

```c
//file1.cpp
int b;
b = 1;
//file2.cpp
int a;
a = 5;
变量a只在file2.cpp文件中使用，去掉extern，声明为文件作用域的变量
```

### MISRA_C_2012_08_08_rule　static 存储类标识符应该用于具有内部链接的对象和函数的定义和声明。
> 等级：**强制**　分类：声明与定义

static 存储类标识符应该用于具有内部链接的对象和函数的定义和声明。

**示例1：不规范用法**

```c
static int x = 0; /* definition: internal linkage */
extern int x; /* Non-compliant */
static int f ( void ); /* declaration: internal linkage */
int f ( void ) /* Non-compliant */
{
 return 1;
}
static int g ( void ); /* declaration: internal linkage */
extern int g ( void ) /* Non-compliant */
{
 return 1;
}
```

**示例1：规范用法之一**

```c
static int x = 0; /* definition: internal linkage */
static int x; /* compliant */
static int f ( void ); /* declaration: internal linkage */
static int f ( void ) /* compliant */
{
 return 1;
}
static int g ( void ); /* declaration: internal linkage */
static int g ( void ) /* compliant */
{
 return 1;
}
声明第[2]行的变量x、第[3]行的函数f、第[9]行的函数g为static类型
```

### MISRA_C_2012_08_09_rule　如果对一个对象的访问只是在一个单一函数中，那么对象在函数块范围内声明
> 等级：**强制**　分类：声明与定义

如果对一个对象的访问只是在一个单一函数中，那么对象在函数块范围内声明

**示例1：不规范用法**

```c
int a;
int b; //Not compliant
void funA()
{
    int m = a;
}
void funB()
{
    if(b>1)
    {
        a++;
     }
}
```

**示例1：规范用法之一**

```c
int a;
void funA()
{
    int m = a;
}
void funB()
{
    int b; //compliant
    if(b>1)
    {
        a++;
     }
}
变量b声明在了函数funB中
```

### MISRA_C_2012_08_10_rule　内联函数应被声明为static
> 等级：**强制**　分类：声明与定义


如果一个内联函数是使用外部链接声明的，但在不同编译单元中都有定义，则该行为是未定义的。
调用通过外部链接声明的内联函数可以调用函数的外部定义，也可以使用内联定义。 尽管这不应影响所调用函数的行为，但可能会影响执行时间，因此对实时程序产生影响。
注意：将内联函数的定义放在标头文件中，则该内联函数可被用于多个编译单元。

**示例1：不规范用法**

```c
inline void func(){ //not compliant
	int a = 1;
	int b = a;
}

int main()
{
	func();
	return 0;
}
```

**示例1：规范用法之一**

```c
inline static void fun(){
	int m = 0;
}
int main()
{
	fun();
	return 0;
}
inline函数声明为static类型
```

### MISRA_C_2012_08_11_rule　具有外部链接的数组大小必须明确定义
> 等级：**强制**　分类：声明与定义


尽管标准C 允许使用不完整类型声明数组并访问其元素，但显式的确定数组大小更安全。为每个声明提供其大小信息，可以检查它们的一致性。它还可以允许静态检查器在无需分析多个编译单元的情况下执行某些数组边界分析。

**示例1：不规范用法**

```c
#include<stdio.h>

int fun();

int arr1[]; //not compliant

char ch[]; //not

long lint[]; //not

int main(void)
{
	int a = 521;
	int m[]; //OK	非外部连接地数组
	int n[10]; //OK
    return 0;
}

int fun(){
	return 0;
}
```

**示例1：规范用法之一**

```c
int arr2[] = {1,2,4}; //OK

int arr3[10] = {1,2}; //OK

int *arr4 = new int[10];	//OK
```

### MISRA_C_2012_08_12_rule　枚举列表中元素的隐式值必须唯一
> 等级：**强制**　分类：声明与定义

枚举元素的值必须唯一。

**示例1：不规范用法**

```c
enum DAY {MON=1, TUE, WED, THU=3}; //not compliant
```

**示例1：规范用法之一**

```c
enum DAY {MON=1, TUE, WED}; //compliant
初始化了第一个元素的值，其他元素会依次加1
```

### MISRA_C_2012_08_13_rule　指针尽可能被声明为const
> 等级：**强制**　分类：声明与定义


除下述两种情况外，都应将指针限定为指向const 限定类型：
◆ 指针用于修改被指向的对象；
◆ 通过以下两种方式之一将一个指针复制到另一个指针：
\  - 内存分配；
\  - 内存移动或复制函数。
为简单起见，此规则是根据指针及其指向的类型编写的。但是，它同样适用于数组及其包含的元素类型。除下述情况外，数组应有const 限定类型的元素：
◆ 数组的任一元素会被修改；
◆ 数组会被复制给符合上述例外情况，指向非const 限定类型的指针。

**示例1：不规范用法**

```c
int f ( int *p ) //not complaint
{
 return *p;
}
int first ( int a[ 5 ] ) //not complaint
{
 return a[ 0 ];
}
```

**示例1：规范用法之一**

```c
int f (const int *p ) //complaint
{
 return *p;
}
int first (const int a[ 5 ] ) //complaint
{
 return a[ 0 ];
}
函数f的指针参数p、函数first的参数数组a被声明为const类型
```

### MISRA_C_2012_08_14_rule　禁用restrict 类型声明
> 等级：**强制**　分类：声明与定义


谨慎的使用“restrict”类型限定符可以提高编译器编译代码的效率。它还可以优化静态分析。但是，要使用“restrict”类型限定符，程序员必须确保用两个或多个指针操作的内存区域不会重叠。
如果未正确使用“restrict”，则会存在很大的编译器生成与预期不符的代码的风险。

**示例1：不规范用法**

```c
void user_copy ( void * restrict p, void * restrict q, size_t n ) //not compliant
{
}
```

**示例1：规范用法之一**

```c
void user_copy ( void * p, void * q, size_t n ) //compliant
{
}
去掉函数user_copy的两个指针参数p与q的类型的restrict修饰符
```

---

## 第 9 章 初始化（5 条）

### MISRA_C_2012_09_01_rule　变量赋值之前不应被使用
> 等级：**推荐**　分类：初始化


根据C 标准，具有静态存储持续时间(静态变量)在非明确初始化时将自动初始化为零；具有自动存储持续时间(临时变量)则不会自动初始化，因此可能具有不确定的值。
注意：在某些情况下，有可能发生忽略自动对象(临时变量)的显示初始化的情况。比如，当使用goto 或switch 语句跳转到标签时，就有可能“绕过”对象的声明；这种情况下，对象的声明被认为是符合预期的(即不会报编译错误)，但是任何显式的初始化都将被忽略。

**示例1：不规范用法**

```c
int uninit() {
	int ret;
	int flag;
	scanf("%d", &flag);
	if (flag > 0) {
 ret = flag;
	} else if (flag < 0) {
 ret = -flag;
	}
	return ret * ret; //当flag=0时，ret未被初始化
}
```

**示例1：规范用法之一**

```c
int uninit() {
	int ret;
	int flag;
	scanf("%d", &flag);
	if (flag > 0) {
 ret = flag;
	} else if (flag < 0) {
 ret = -flag;
	} else {
 ret = 0;
	} //任何条件下都给ret设置初始化的操作，排除了安全隐患。
	return ret * ret;
}
在使用前必须进行初始化
```

### MISRA_C_2012_09_02_rule　数组或结构体初始化的嵌套结构必须与定义一致。
> 等级：**强制**　分类：初始化

数组或结构体初始化的嵌套结构必须与定义一致。

**示例1：不规范用法**

```c
int16_t y1[ 3 ][ 2 ] = { 1, 2, 0, 0, 5, 6 }; /* Non-compliant */
int16_t z3[ 2 ][ 2 ] = { { 0 }, [ 1 ][ 0 ] = 0, 1 }; /* Non-compliant */
```

**示例1：规范用法之一**

```c
int16_t y1[ 3 ][ 2 ] = { { 1, 2 }, { 0 }, { 5, 6 } }; /* Compliant */
int16_t z3[ 2 ][ 2 ] = { [ 0 ][ 1 ] = 0, { 0, 1 } }; /* Compliant */
修改y1与z3的初始化结构，与定义保持一致
```

### MISRA_C_2012_09_03_rule　数组不允许部分初始化。
> 等级：**强制**　分类：初始化

如果数组对象或子对象的任何元素被显式初始化，则整个对象或子对象都应被显式初始化。
例外:
1.{0}形式的初始化可用于显式初始化数组对象或子对象的所有元素。
2.可以使用仅由指定的初始化组成的数组初始化形式，例如执行稀疏初始化。
3.使用字符串文字初始化的数组不需要为每个元素都初始化。

**示例1：不规范用法**

```c
/* Non-compliant - y[ 2 ] is implicitly initialized */
int32_t y[ 3 ] = { 0, 1 };
/* Non-compliant - t[ 0 ] and t[ 3 ] are implicitly initialized */
float32_t t[ 4 ] = { [ 1 ] = 1.0f, 2.0f };
```

**示例1：规范用法之一**

```c
/* Compliant */
int32_t y[ 3 ] = { 0, 1, 2 };
/* Compliant - designated initializers for sparse matrix */
float32_t t[ 4] = { [ 1 ] = 1.0f, [ 2 ] = 2.0f };
```

### MISRA_C_2012_09_04_rule　一个对象的元素不能被初始化超过一次
> 等级：**强制**　分类：初始化

对象的一个元素不得被初始化超过一次。
使用指定初始化器（designated initializer）时需格外小心，因为对象元素的初始化可能被无意地重复，导致先前已初始化的元素被覆盖。对于被覆盖的初始化器，C99 标准并未规定其副作用是否发生。为了支持稀疏数组和结构体，可以只初始化应用所必需的元素。

**示例1：不规范用法**

```c
/*
01_01_09
初始化
01_01_09_06
一个对象不能被初始化超过一次
*/
#include <stdio.h>
struct MyStruct
{
   int a;
   int b;
};
int main()
{
	printf("01_01_09_06\n一个对象的元素不能被初始化超过一次\n");
	int i=0;
	i = 5;
	int a[3]={[0]=1,[2]=2,[2]=3}; //not compliant

	struct MyStruct struct1 = {1,2},struct3 = {2,3};
	struct MyStruct struct2 = {.a=1, .b=2, .a=3}; //not compliant
	printf("%d\n",struct2.a);
	return 0;
}
```

**示例1：规范用法之一**

```c
/*
01_01_09
初始化
01_01_09_06
一个对象不能被初始化超过一次
*/
#include <stdio.h>
struct MyStruct
{
   int a;
   int b;
};
int main()
{
	printf("01_01_09_06\n一个对象的元素不能被初始化超过一次\n");
	int i=0;
	i = 5;
	int a[3]={[0]=1,[2]=2}; //Compliant

	struct MyStruct struct1 = {1,2},struct3 = {2,3};
	struct MyStruct struct2 = {.a=1, .b=2}; //Compliant
	printf("%d\n",struct2.a);
	return 0;
}
```

### MISRA_C_2012_09_05_rule　数组的声明不详细。
> 等级：**强制**　分类：初始化

如果一个数组未明确指定大小，则其大小由初始化元素的最高索引确定。当使用指定初始化时，可能并不总是清楚哪个初始化具有最高的索引，尤其是在初始化包含大量元素的情况下。
为了清晰明确设计意图，应明确声明数组大小。这么操作也给程序开发过程中更改初始化数组元素索引提供了保护，因为它违反了限制(参见C99 第6.7.8 节)，在数组范围外初始化元素。

**示例1：不规范用法**

```c
int main(void)
{
    int array[] = {0, 1, 2}; // not-1
    int i;
    int data = 0;
    for(i=0; i<3; i++)
    {
        data = data + array[i];
    }
    return 0;
}
```

**示例1：规范用法之一**

```c
int main(void)
{
    int array[3] = {0, 1, 2}; // ok-1
    int i;
    int data = 0;
    for(i=0; i<3; i++)
    {
        data = data + array[i];
    }
    return 0;
}
数组定义有显式的边界限定。
```

---

## 第 10 章 类型（8 条）

### MISRA_C_2012_10_01_rule　操作数不得有不适当的基本类型
> 等级：**强制**　分类：类型


例外：
有符号型的常量表达式，若其值为非负，可以用作移位运算符的右手操作数。

**示例1：不规范用法**

```c
void fun()
{
float f32a;
f32a & 2U ;/* not compliant */
f32a << 2 ;/* not compliant */
}
```

**示例1：规范用法之一**

```c
void fun()
{
float f32a;
(unsigned int)f32a & 2U ;/* Compliant */
(unsigned int)f32a << 2 ;/* Compliant */
}
```

### MISRA_C_2012_10_02_rule　不能对char类型进行基本的加减运算。
> 等级：**强制**　分类：类型

不能对char类型进行基本的加减运算。

**示例1：不规范用法**

```c
int b,c;
char a;
b=a-9; //not compliant
c=a+5; //not compliant
b=b-4;
```

**示例1：规范用法之一**

```c
int b,c;
signed char a;
b=a-9; // Compliant
c=a+5; // Compliant
b=b-4;
```

### MISRA_C_2012_10_03_rule　一个表达式的值不应被赋值到较窄的基本型或不同基本类型类别的对象
> 等级：**强制**　分类：类型


例外：
1.有符号型的对象的非负整数常量表达式可以赋值给无符号型的对象，只要它的值可以用该类型完全表示。
2.初始化操作“{0}”可用于初始化聚合(数组、结构体)或联合类型。

**示例1：不规范用法**

```c
//The following are non-compliant as they have different essential type categories:
void fun()
{
    signed int s32a;
    unsigned char u8a,u8b,u8c;
    unsigned int u32a;
    unsigned short u16a;
    char cha;
    u8a = 1.0f; /* unsigned and floating */
    _Bool bla = 0; /* boolean and signed */
    cha = 7; /* character and signed */
    u8a = 'a'; /* unsigned and character */
    u8b = 1 - 2; /* unsigned and signed */
    u8c += 'a'; /* u8c = u8c + 'a' assigns character to unsigned */
    use_uint32 ( s32a ); /* signed and unsigned */
    //The following are non-compliant as they contain assignments to a narrower essential type:
    u16a = u32a; /* uint32_t to uint16_t */
    use_uint16 ( u32a ); /* uint32_t to uint16_t */
}
unsigned char foo1 ( unsigned int x )
{
    return x; /* uint16_t to uint8_t */
}
unsigned short use_uint16 ( unsigned short x )
{
    return x;
}
unsigned int use_uint32(unsigned int x )
{
    return x;
}
```

**示例1：规范用法之一**

```c
//The following are non-compliant as they have different essential type categories:
void fun()
{
    signed int s32a;
    unsigned char u8a,u8b,u8c;
    unsigned int u32a;
    unsigned short u16a;
    char cha;
    u8a = (unsigned char)1.0f;
    _Bool bla = 0; /* boolean and signed */
    cha = (char)7;
    u8a = (unsigned char)'a';
    u8b = (unsigned char)(1 - 2);
    u8c += 'a'; /* u8c = u8c + 'a' assigns character to unsigned */
    use_uint32 ( s32a ); /* signed and unsigned */
    //The following are non-compliant as they contain assignments to a narrower essential type:
    u16a = (unsigned short)u32a;
    use_uint16 ( u32a ); /* uint32_t to uint16_t */
}
unsigned char foo1 ( unsigned int x )
{
    return x; /* uint16_t to uint8_t */
}
unsigned short use_uint16 ( unsigned short x )
{
    return x;
}
unsigned int use_uint32(unsigned int x )
{
    return x;
}
```

### MISRA_C_2012_10_04_rule　操作者在通常的算术转换执行两个操作数必须具有相同的基本类型类别
> 等级：**强制**　分类：类型


C 语言允许程序员具有极大的自由度，并允许自动执行不同算术类型之间的隐式赋值。但是，使用这些隐式转换可能会导致意外结果，并可能导致值、符号或精度的损失。
MISRA 的基本类型模型强制使用了更强的类型限制，以保证隐式类型转换的结果与开发人员的期望一致。
例外：
以下操作被允许，用以保证常见的字符操作被识别为合规：
1.双目运算符“+”和“+=”允许一个操作数是字符型，而另一个操作数为有符号型或无符号型；
2.双目运算符“-”和“-=”允许字符型的左操作数和有符号型或无符号型的右操作数。

**示例1：不规范用法**

```c
/*
10_数值类型转换
COBOT_01_01_10_28

*/
#include <stdio.h>
int main()
{
    typedef int INT;
    int a = 1;
    char b = 2;
    unsigned int c = 0;
    int d = 0;
    d = a + c; //not compliant
    d += c; //not compliant
    c += b; //not compliant
    d = a^c; //not compliant
    enum enuma { A1, A2, A3 } ena;
    enum enumb { B1, B2, B3 } enb;
    ena = A1;
    enb = B1;
    ena > B1; //not compliant
    return 0;
}
```

**示例1：规范用法之一**

```c
/*
10_数值类型转换
COBOT_01_01_10_28

*/
#include <stdio.h>
int main()
{
    typedef int INT;
    int a = 1;
    char b = 2;
    unsigned int c = 0;
    int d = 0;
    d = a + (int)c; //Compliant
    d += (int)c; //Compliant
    c += (unsigned int)b; //Compliant
    d = a^(int)c; //Compliant
    enum enuma { A1, A2, A3 } ena;
    enum enumb { B1, B2, B3 } enb;
    ena = A1;
    enb = B1;
    ena > A1; //Compliant
    return 0;
}
```

### MISRA_C_2012_10_05_rule　一个表达式的值不应被转换一个不恰当的基本类型
> 等级：**强制**　分类：类型


例外：
可以将带符号的值为0 或1 的整数常量表达式强制转换为布尔型。 这允许实现非C99 布尔模型。

**示例1：不规范用法**

```c
/*
10_数值类型转换
COBOT_01_01_10_28

*/
#include <stdio.h>
int main()
{
    typedef int INT;
    typedef INT _INT;
    _INT _int = 1;
    _int = 2;
    char _char_1 = 'a' ,_char_2 = 'a';
    enum {a=1, b, c}_enum_1, enum1;
    enum {d=1,e,f,g}_enum_2, enum2;;
    signed int _sint_1 = 1, _sint_2 = 2;
    unsigned int _uint_1 = 1, _uint_2 = 2;
    float _float_1 = 1.0, _float_2 = 2.0;
    _char_2 = (char)_char_1;
    _char_2 = (char)_float_1; //not compliant
    enum2 = ( enum _enum_2)_sint_1; //not compliant
    _sint_2 = (signed int)enum1;
    _uint_2 = (unsigned int) _char_1;
    _float_2 = (float)_char_1; //not compliant
    _float_2 = (float)enum1;
    return 0;
}
```

**示例1：规范用法之一**

```c
/*
10_数值类型转换
COBOT_01_01_10_28

*/
#include <stdio.h>
int main()
{
    typedef int INT;
    typedef INT _INT;
    _INT _int = 1;
    _int = 2;
    char _char_1 = 'a' ,_char_2 = 'a';
    enum {a=1, b, c}_enum_1, enum1;
    enum {d=1,e,f,g}_enum_2, enum2;;
    signed int _sint_1 = 1, _sint_2 = 2;
    unsigned int _uint_1 = 1, _uint_2 = 2;
    float _float_1 = 1.0, _float_2 = 2.0;
    _char_2 = (char)_char_1;
    //_char_2 = (char)_float_1; //not compliant
    _sint_2 = (signed int)enum1;
    _uint_2 = (unsigned int) _char_1;
    //_float_2 = (float)_char_1; //not compliant
    _float_2 = (float)enum1;
    return 0;
}
```

### MISRA_C_2012_10_06_rule　一种复合表达式的值不应被分配到更广泛的基本类型对象
> 等级：**强制**　分类：类型

一种复合表达式的值不应被分配到更广泛的基本类型对象。

**示例1：不规范用法**

```c
/*
10_数值类型转换
COBOT_01_01_10_36
一种复合表达式的值不应被分配到更广泛的基本类型对象
*/
#include <stdio.h>
int main()
{
    int a = 1, b = 2;
    unsigned int d=0,e=0;
    long long c = 0;
    c = a+(long)b; //not compliant
    d = (unsigned int)(a+b);
    d = (unsigned int)a;
    c = (long)(a + b); //not compliant
    return 0;
}
```

**示例1：规范用法之一**

```c
/*
10_数值类型转换
COBOT_01_01_10_36
一种复合表达式的值不应被分配到更广泛的基本类型对象
*/
#include <stdio.h>
int main()
{
    int a = 1, b = 2;
    unsigned int d=0,e=0;
    long long c = 0;
    c = ( long long)(a+b); //Compliant
    d = (unsigned int)(a+b);
    d = (unsigned int)a;
    c = ( long long)(a + b); //Compliant
    return 0;
}
```

### MISRA_C_2012_10_07_rule　如果一个复合表达式作为一个运算符的操作数，该运算符的另一个操作数不应该是位宽较宽的基本类型
> 等级：**强制**　分类：类型

如果一个复合表达式作为一个运算符的操作数，该运算符的另一个操作数不应该是位宽较宽的基本类型

**示例1：不规范用法**

```c
/*
10_数值类型转换
COBOT_01_01_10_36
如果一个复合表达式作为一个操作数的运算符，常用算术操作符的其他操作数不应具有较宽的基本类型
*/
#include <stdio.h>
int main()
{
    unsigned short u16a = 1, u16b = 2;
    unsigned int u32a = 0, u32b = 1;
    u16a = u16a + u16b +u16b;
     //The following are compliant:
    u32b = u32a * u16a + u16b; /* No comp osite conversion */
    u32b = ( u32a * u16a ) + u16b; /* No composite conversion */
    u32b = u32a * ( ( unsigned int ) u16a + u16b ); /* Both operands of * have* same essential type */
    u32a += ( u32b + u16b ); /* No composite conversion */

    //The following are non-compliant:
    u32b = u32a * ( u16a + u16b ); /* Implicit conversion of ( u16a + u16b ) */
    u32a += ( u16a + u16b ); /* Implicit conversion of ( u16a + u16b ) */
    u32b /= u16a;
    return 0;
}
```

**示例1：规范用法之一**

```c
/*
10_数值类型转换
COBOT_01_01_10_36
如果一个复合表达式作为一个操作数的运算符，常用算术操作符的其他操作数不应具有较宽的基本类型
*/
#include <stdio.h>
int main()
{
    unsigned short u16a = 1, u16b = 2;
    unsigned int u32a = 0, u32b = 1;
    u16a = u16a + u16b +u16b;
     //The following are compliant:
    u32b = u32a * u16a + u16b; /* No comp osite conversion */
    u32b = ( u32a * u16a ) + u16b; /* No composite conversion */
    u32b = u32a * ( ( unsigned int ) u16a + u16b ); /* Both operands of * have* same essential type */
    u32a += ( u32b + u16b ); /* No composite conversion */

    //The following are non-compliant:
    u32b = u32a * ( ( unsigned int ) u16a + u16b );
    u32a += ( u32b + u16b );
    u32b /= u16a;
    return 0;
}
```

### MISRA_C_2012_10_08_rule　一种复合表达式的值不应被转换为不同基本类型类别或更广泛的基本类型
> 等级：**强制**　分类：类型

一种复合表达式的值不应被转换为不同基本类型类别或更广泛的基本类型

**示例1：不规范用法**

```c
/*
10_数值类型转换
COBOT_01_01_10_38
一种复合表达式的值不应被转换为不同基本类型类别或更广泛的基本类型
*/
#include <stdio.h>
int main()
{
    int a = 1, b = 2;
    unsigned int d = 0, e = 0;
    long long c = 0;
    c = a+(long)b;
    d = (unsigned int)(a +b); //not compliant
    d = (unsigned int)a;
    c = (long long)(a + b); //not compliant
    return 0;
}
```

**示例1：规范用法之一**

```c
/*
10_数值类型转换
COBOT_01_01_10_38
一种复合表达式的值不应被转换为不同基本类型类别或更广泛的基本类型
*/
#include <stdio.h>
int main()
{
    int a = 1, b = 2;
    unsigned int d = 0, e = 0;
    long long c = 0;
    c = a+(long)b;
    d = a +(unsigned int)b; // Compliant
    d = (unsigned int)a;
    c = a+(long long)b; // Compliant
    return 0;
}
```

---

## 第 11 章 指针类型转换（9 条）

### MISRA_C_2012_11_01_rule　函数指针与其他类型的指针不应发生转换
> 等级：**强制**　分类：指针类型转换


指向函数的指针与以下任何一种的转换，都将导致不确定的行为：
◆ 指向对象的指针；
◆ 指向不完整类型的指针；
◆ void *。
若通过与被调用函数类型不兼容的指针来调用函数，其行为是不确定的。C 标准允许将指向函数的指针转换为具有不同类型的函数的指针和将整数转换为指向函数的指针。但是，这两项都被此规则禁止，以避免使用不兼容的指针类型调用函数而导致的未定义行为。
例外：
1.空指针常量(NULL)可以转换为指向函数的指针；
2.指向函数的指针可以转换为void；
3.函数类型(标识符)可以隐式转换为指向该函数类型的指针。

**示例1：不规范用法**

```c
#include <stdint.h>
typedef void ( *fp16 ) ( int16_t n );
typedef void ( *fp32 ) ( int32_t n );
#include <stdlib.h> /* To obtain macro NULL */
typedef fp16 ( *pfp16 ) ( void );
void misra2012_11_01(void)
{
    fp16 fp1 = NULL; /* Compliant - exception 1 */
    fp32 fp2 = ( fp32 ) fp1; /* Non-compliant - function pointer into different function pointer */
}
```

**示例1：规范用法之一**

```c
#include <stdint.h>
typedef void ( *fp16 ) ( int16_t n );
typedef void ( *fp32 ) ( int32_t n );
#include <stdlib.h> /* To obtain macro NULL */
typedef fp16 ( *pfp16 ) ( void );
void misra2012_11_01(void)
{
    fp16 fp1 = NULL; /* Compliant - exception 1 */
    // fp32 fp2 = ( fp32 ) fp1; /* Non-compliant - function pointer into different function pointer */
}
```

### MISRA_C_2012_11_02_rule　转换不应一个指针指向一个不完整的类型和其他类型之间进行
> 等级：**强制**　分类：指针类型转换


普通指针与指向不完整类型间的转换可能会导致指针未正确对齐，从而导致行为不确定。
将不完整类型的指针转与浮点型互相转换，也会导致未定义的行为。
指向不完整类型的指针有时用作隐藏对象的表示形式的一种封装方式。将不完整类型的指针转换为指向对象(完整类型/明确类型)的指针会破坏这种封装。
例外：
1.空指针常量(NULL)可以转换为指向不完整类型的指针。
2.指向不完整类型的指针可能会转换为void。

**示例1：不规范用法**

```c
int main(void){
struct s;
struct s * sp;
int *ip = ( int16_t * ) sp; //not compliant
return 0;
}
```

**示例1：规范用法之一**

```c
int main(void){
struct s{int a, int b};
struct s * sp;
int *ip = ( int16_t * ) sp; //Compliant
return 0;
}
将[struct s]类型补全。
```

### MISRA_C_2012_11_03_rule　不得在指向不同对象类型的指针之间执行强制转换
> 等级：**强制**　分类：指针类型转换


指向不同对象的指针间的转换可能会导致指针未正确对齐，从而导致未定义的行为。即使已知转换会产生正确对齐的指针，使用该指针访问对象的行为也可能是未定义的。例如，如果将类型为int 的对象作为short 进行访问，则即使int 和short 具有相同的表示和对齐要求，其行为也是未定义的。 有关详细信息，请参见C90 第6.3 节，C99 第6.5 节第7 段。
例外：
将指向对象类型的指针转换为指向对象类型为char，signed char 或unsigned char 之一的指针是被允许的。C 标准确保了可以使用指向这些类型的指针来访问对象的各个字节。

**示例1：不规范用法**

```c
uint8_t *p1;
uint32_t *p2;
/* 违规 - possible incompatible alignment */
p2 = (uint32_t *)p1;
extern uint32_t read_value(void);
extern void print(uint32_t n);
void f (void)
{
    uint32_t u = read_value();
    uint16_t *hi_p = (uint16_t *)&u; /* 违规 - 即使可能正确对齐了 */
    *hi_p = 0; /* 尝试在大端模式的机器上清除高16位 */
    print(u); /* 上一行代码可能不被执行 */
}
```

**示例1：规范用法之一**

```c
int * const * pcpi;
const int * const * pcpci;
pcpci = (const int * const *)pcpi;
```

### MISRA_C_2012_11_04_rule　指针变量和整型数据之间使用强制转换。
> 等级：**强制**　分类：指针类型转换

将整数转换为指向对象的指针可能会导致指针未正确对齐，从而导致未定义的行为。
将对象的指针转换为整数可能会产生无法以所选整数类型表示的值，从而导致未定义的行为。
例外:
具有整数类型的空指针常量(NULL)可以转换为指向对象的指针。

**示例1：不规范用法**

```c
unsigned int s=0;
unsigned int *p1_ptr;
p1_ptr=(unsigned int*)s; //Not compliant
```

**示例1：规范用法之一**

```c
unsigned int s=0;
unsigned int *p1_ptr;
p1_ptr=&s; //Compliant
```

### MISRA_C_2012_11_05_rule　一个转换不应进行从void指针变成指向对象的指针
> 等级：**强制**　分类：指针类型转换

一个转换不应进行从void指针变成指向对象的指针

**示例1：不规范用法**

```c
int main()
{
   	int *p32;
	void *p;
	unsigned int *p16;
	p16 = p; /* Non-compliant */
	p = ( void * ) p16; /* Compliant */
	p32 = ( int * ) p; /* Non-compliant */
 	return 0;
}
```

**示例1：规范用法之一**

```c
int main()
{
   int *p32;
	int *p;
	unsigned int *p16;
	p16 = (unsigned int *)p; /* Compliant */
	p = ( unsigned int * ) p16; /* Compliant */
	p32 = p; /* Compliant */
 	return 0;
}
第(4)行将[void*]类型改成其他指针类型。
```

### MISRA_C_2012_11_06_rule　转换不应在指向void的指针和一个算术类型之间进行
> 等级：**强制**　分类：指针类型转换

转换不应在指向void的指针和一个算术类型之间进行

**示例1：不规范用法**

```c
int main()
{
    void * p;
    unsigned int u;
    p = ( void * ) 0x1234u; /* Non-compliant - implementation-defined */
    p = ( void * ) 1024.0f; /* Non-compliant - undefined */
    u = ( unsigned int ) p; /* Non-compliant - implementation-defined */
    return 0;
}
```

**示例1：规范用法之一**

```c
int main()
{
    void * p;
    unsigned int u;
    p = &u; /* Compliant */
    //p = ( void * ) 1024.0f; /* Non-compliant - undefined */
    u = ( unsigned int *) p; /* Compliant */
    return 0;
}
```

### MISRA_C_2012_11_07_rule　转换不应在指向对象的指针和一个非整数的算术类型之间进行
> 等级：**强制**　分类：指针类型转换

转换不应在指向对象的指针和一个非整数的算术类型之间进行

**示例1：不规范用法**

```c
int main()
{
    int * p;
    float f;
    f = ( float ) p; /* Non-compliant */
    p = ( int * ) f; /* Non-compliant */
    return 0;
}
```

**示例1：规范用法之一**

```c
int main()
{
    int * p;
    float f;
    f = ( float *) p; /* Compliant */
    p = ( int * ) &f; /* Compliant */
    return 0;
}
```

### MISRA_C_2012_11_08_rule　移除const和volatile的指针类型转换是不允许的。
> 等级：**强制**　分类：指针类型转换

移除const和volatile的指针类型转换是不允许的。

**示例1：不规范用法**

```c
int *a;
volatile char *b;
const char *c;
a = (int *)b; //not compliant
a = (int *)c; //not compliant
```

**示例1：规范用法之一**

```c
int *a;
char *b;
char *c;
a = (int *)b; // Compliant
a = (int *)c; // Compliant
```

### MISRA_C_2012_11_09_rule　NULL应只允许转换为空指针常量整数形式
> 等级：**强制**　分类：指针类型转换

NULL应只允许转换为空指针常量整数形式

**示例1：不规范用法**

```c
int main()
{
    int *p1 = 0; /* Non-compliant */
    return 0;
}
```

**示例1：规范用法之一**

```c
int main()
{
    int *p1 = ( void * ) 0; /* Compliant */
    return 0;
}
```

---

## 第 12 章 表达式（4 条）

### MISRA_C_2012_12_01_rule　在表达式中的运算符优先次序应明确。
> 等级：**强制**　分类：表达式

在表达式中的运算符优先次序应明确。

**示例1：不规范用法**

```c
int main()
{
	int x,y;
	if(x==0&&y)	//not compliant
	{
	}
	return 0;
}
```

**示例1：规范用法之一**

```c
int main()
{
	int x,y;
	if((x==0)&&(y))	//compliant
	{
	}
	return 0;
}
```

### MISRA_C_2012_12_02_rule　位移操作符的右操作数必须介于零到一个小于对左操作数的基本类型的位宽。
> 等级：**强制**　分类：表达式

位移操作符的右操作数必须介于零到一个小于对左操作数的基本类型的位宽。

**示例1：不规范用法**

```c
int main(void)
{
    unsigned int x, y, z;
    x = 0x00000001;
    y = x << 33; // not-1
    x = 0x80000000;
    z = x >> 33; // not-2
    return 0;
}
```

**示例1：规范用法之一**

```c
int main(void)
{
    unsigned int x, y, z;
    x = 0x00000001;
    y = x << 1; // ok-1
    x = 0x80000000;
    z = x >> 1; // ok-2
    return 0;
}
移位运算符的右手操作数应该位于零和某数之间，这个数要小于左手操作数的基本类型的位宽。
```

### MISRA_C_2012_12_03_rule　禁止使用逗号操作数。
> 等级：**强制**　分类：表达式

禁止使用逗号操作数。

**示例1：不规范用法**

```c
int main(void)
{
    int a=8,b=9;
    int c = (a,b); //not compliant
    return 0;
}
```

**示例1：规范用法之一**

```c
int main(void)
{
    int a=8,b=9;
    int c =a;
    c = b;
    return 0;
}
将第[4]行的表达式拆开
```

### MISRA_C_2012_12_04_rule　常量表达式的求值不应导致无符号整数回绕
> 等级：**推荐**　分类：表达式

无符号整数表达式不会严格意义上"溢出"，而是发生回绕。虽然在运行时使用模运算可能有充分理由，但在编译期求值的常量表达式中出现回绕往往不是有意为之，容易掩盖逻辑错误。
本规则适用于满足常量表达式约束的表达式，无论其是否出现在要求常量表达式的上下文中。如果表达式不会被求值（例如它出现在逻辑与运算符的右操作数、而左操作数恒为 false），则本规则不适用。

**示例1：不规范用法**

```c
#define BASE 65024u
switch ( x )
{
  case BASE + 0u: f ( ); break;
  case BASE + 1u: g ( ); break;
  case BASE + 512u: h ( ); break; /* 违规 - 16 位 int 上回绕到 0 */
}

#if 1u + ( 0u - 10u ) /* 违规 - ( 0u - 10u ) 回绕 */

#define DELAY 10000u
#define WIDTH 60000u
void fixed_pulse ( void )
{
  uint16_t off_time16 = DELAY + WIDTH; /* 违规 - 70000 回绕为 4464 */
}
```

**示例1：规范用法之一**

```c
const uint16_t c = 0xffffu;
void f ( void )
{
  uint16_t y = c + 1u; /* 合规 - c+1 访问了对象，不是常量表达式 */
}

bool_t b;
void g ( void )
{
  uint16_t x = ( 0u == 0u ) ? 0u : ( 0u - 1u ); /* 合规 - 该分支不被求值 */
  uint16_t y = b ? 0u : ( 0u - 1u ); /* 违规 - 该分支可能被求值 */
}
```

---

## 第 13 章 副作用（6 条）

### MISRA_C_2012_13_01_rule　初始化程序列表不得包含持久性副作用
> 等级：**强制**　分类：副作用

初始化程序列表不得包含持久性副作用

**示例1：不规范用法**

```c
volatile u int16_t v1;
void f(void)
{
    /* 违规 - 易失性访问是持久的副作用 */
    uint16_t a[2] = { v1, 0 };
}

uint16_t x = 0u;
extern void p(uint16_t a[2]);
void h(void)
{
    /* 违规 - 两个副作用 */
    p((uint16_t[2]) { x++, x++ });
}
```

**示例1：规范用法之一**

```c
void g(uint16_t x, uint16_t y)
{
    /* 合规 - 无副作用 */
    uint16_t a[2] = { x + y, x - y };
}
```

### MISRA_C_2012_13_02_rule　表达式的副作用在任何执行顺序下都应该是相同的。
> 等级：**强制**　分类：副作用

表达式的副作用在任何执行顺序下都应该是相同的。

**示例1：不规范用法**

```c
typedef int bool;
#ifndef true
#define true 1
#endif // true
#ifndef false
#define false 0
#endif // false
void static_p1(void)
{
    unsigned int z = 0u, x = 0u;
    bool flag = true;
    /*...*/
    if(flag=false)
    {
        z = x-1u;
    }
    /*...*/
}

 void static_p2(void)
 {
     unsigned int y=0u, x=0u, z=1u;
     volatile unsigned int v=1u;
     /*...*/
     x=v+z/v*y;
     /*...*/
 }

 unsigned int exp_1(unsigned int *p_1)
{
    unsigned int x = *p_1;
    (*p_1) = x*x;
    return x;
}
unsigned int exp_2(unsigned int *p_1)
{
    unsigned int x = *p_1;
    (*p_1) = (x%2);
    return x;
}
void static_p3(void)
{
    unsigned int y = 3u, x = 0u;
    x = exp_1(&y)+exp_2(&y);
}
```

**示例1：规范用法之一**

```c
typedef int bool;
#ifndef true
#define true 1
#endif // true
#ifndef false
#define false 0
#endif // false
void static_p1(void)
{
    unsigned int z = 0u, x = 0u;
    bool flag = true;
    /*...*/
    if(flag==false)
    {
        z = x-1u;
    }
    /*...*/
}

 void static_p2(void)
 {
     unsigned int y=0u, x=0u, z=1u;
     unsigned int v=1u;
     /*...*/
     x=v+z/v*y;
     /*...*/
 }

unsigned int exp_1(unsigned int *p_1)
{
    unsigned int x = *p_1;
    (*p_1) = x*x;
    return x;
}
unsigned int exp_2(unsigned int *p_1)
{
    unsigned int x = *p_1;
    (*p_1) = (x%2);
    return x;
}
void static_p3(void)
{
    unsigned int y = 3u, x = 0u;
    x = exp_1(&y);
    x = x+exp_2(&y);
}
```

### MISRA_C_2012_13_03_rule　含有递增（++）或递减一个完整的表达（ - ）操作者应没有其他潜在的副作用。
> 等级：**强制**　分类：副作用

含有递增（++）或递减一个完整的表达（ - ）操作者应没有其他潜在的副作用。

**示例1：不规范用法**

```c
int fun(int p);
int main(void)
{
    int x = 1, y = 2, z = 3l;
    int r;
    y = y + (x++); // not-1
    z = z + (++y); // not-2
    z = fun(--z); // not-3
    r = fun(z--); // not-4
    return 0;
}
int fun(int p)
{
    int ret;
    ret = 2*p;
    return ret;
}
```

**示例1：规范用法之一**

```c
int fun(int p);
int main(void)
{
    int x = 1, y = 2, z = 3l;
    int r;
    y = y + x;
    x++; // ok-1
    y++; // ok-2
    z = z + y;
    z--; // ok-3
    z = fun(z);
    r = fun(z);
    z--; // ok-4
    return 0;
}
int fun(int p)
{
    int ret;
    ret = 2*p;
    return ret;
}
将自增（++）和自减（--）同其他算术操作隔离开。
```

### MISRA_C_2012_13_04_rule　赋值表达式的结果不应该被使用。
> 等级：**强制**　分类：副作用

赋值表达式的结果不应该被使用。

**示例1：不规范用法**

```c
typedef int bool;
#ifndef true
#define true 1
#endif // true
#ifndef false
#define false 0
#endif // false
void static_p(void)
{
    unsigned int z = 0u, x = 0u;
    bool flag = true;
    /*...*/
    if(flag=false)
    {
        z = x-1u;
    }
    /*...*/
}
```

**示例1：规范用法之一**

```c
typedef int bool;
#ifndef true
#define true 1
#endif // true
#ifndef false
#define false 0
#endif // false
void static_p(void)
{
    unsigned int z = 0u, x = 0u;
    bool flag = true;
    /*...*/
    if(flag==false)
    {
        z = x-1u;
    }
    /*...*/
}
在第(13)行将[=]改为[==]。
```

### MISRA_C_2012_13_05_rule　&&或||右边的表达式不应该有副作用。
> 等级：**强制**　分类：副作用

&&或||右边的表达式不应该有副作用。

**示例1：不规范用法**

```c
int main(void)
{
int i;
if(a||(i++)) //Not compliant
return 0;
}
```

**示例1：规范用法之一**

```c
int main(void)
{
int i;
if(a||(i)) //Compliant
i++;
return 0;
}
```

### MISRA_C_2012_13_06_rule　不能在具有副作用的表达式中使用sizeof运算符
> 等级：**强制**　分类：副作用

不能在具有副作用的表达式中使用sizeof运算符

**示例1：不规范用法**

```c
#include <stdint.h>
#include <stdio.h>
void misra2012_13_6(int32_t n)
{
    volatile int32_t i;
    volatile uint32_t v;
    int32_t j;
    size_t s;
    s = sizeof ( j++ ); /* Non-compliant */
    s = sizeof ( int32_t[ n++ ] ); /* Non-compliant */
    s = sizeof ( void ( *[ n ] ) ( int32_t a[ v ] ) ); /* Non-compliant */
}
```

**示例1：规范用法之一**

```c
#include <stdint.h>
#include <stdio.h>
void good_misra2012_13_6(int32_t n)
{
    volatile uint32_t v;
    size_t s;
    int32_t j;
    s = sizeof ( j ); /* Compliant */
    s = sizeof ( v ); /* Compliant - exception */
    s = sizeof ( int32_t ); /* Compliant */
    s = sizeof ( int32_t[ n ] ); /* Compliant */
}
```

---

## 第 14 章 控制语句表达式（4 条）

### MISRA_C_2012_14_01_rule　循环语句的控制表达式不能包含任何浮点类型的对象。
> 等级：**强制**　分类：控制语句表达式

使用浮点型数据作为循环计数器时，舍入误差的积累可能会导致预期的循环次数与实际不匹配。当循环步长不是浮点数舍入后所能表示的值的时候，这种情况就有可能发生。
即使带有浮点型循环计数器的循环在一个实现中可能行为正确，但在另一个实现中它可能会得出不同的循环次数。

**示例1：不规范用法**

```c
int main()
{
	float f;
	for(f=1;f<3;f++) //Not compliant
	{
 printf("Number=%f\n",f);
	}
	double d;
	for(d=1;d<3;d++) //Not compliant
	{
 printf("Number=%lf\n",d);
	}
	long double ld;
	for(ld=1;ld<3;ld++) //Not compliant
	{
 printf("Number=%llf\n",ld);
	}
}
```

**示例1：规范用法之一**

```c
int main()
{
	int f;
	for(f=1;f<3;f++) //Compliant
	{
 printf("Number=%f\n",f);
	}
	int d;
	for(d=1;d<3;d++) //Compliant
	{
 printf("Number=%lf\n",d);
	}
	int ld;
	for(ld=1;ld<3;ld++) //Compliant
	{
 printf("Number=%llf\n",ld);
	}
}
```

### MISRA_C_2012_14_02_rule　for循环格式要正确。
> 等级：**强制**　分类：控制语句表达式

for 循环语句包含三个子句，此规则对它们的要求为：
第一个子句：
◆ 不得为空，或
◆ 应为循环计数器分配一个值，或
◆ 应定义并初始化循环计数器(C99)。
第二个子句：
◆ 应该是没有持久副作用的表达式，并且
◆ 应使用循环计数器和可选的循环控制标志，并且
◆ 不得使用在for 循环主体中修改的任何其他对象。
第三个子句：
◆ 应该是一个表达式，其唯一的持久副作用是修改循环计数器的值，并且
◆ 不得使用在for 循环主体中修改的对象。
for 循环中只能有一个循环计数器，且不能在for 循环主体中修改。
循环控制标志定义为：在第二个子句使用的基本型为布尔型的对象的单个标识符。
for 循环主体的行为包括了在该主体内调用的所有函数的行为。
例外：
三个子句都可以为空，例如for (;;)，以便允许无限循环。

**示例1：不规范用法**

```c
int main()
{
	int i=0,j=0;
	for(i=1,j=0;i<3&&j<3;i++,j++)
	{
 printf("i=%d,j=%d\n",i,j);
	}
}
```

**示例1：规范用法之一**

```c
int main()
{
	int i=0,j=0;
	for(;i<3&&j<3;i++)
	{
 printf("i=%d,j=%d\n",i,j);
                j++;
	}
}
```

### MISRA_C_2012_14_03_rule　不允许进行结果不会改变的布尔运算。
> 等级：**强制**　分类：控制语句表达式

此规则适用于：
◆ if，while，for，do…while 和switch 语句的控制表达式；
◆ ?:运算符的第一个操作数。
如果控制表达式的值不变，则意味着可能存在编程错误。因存在不变表达式而无法到达的任何代码都可以由编译器删除。例如，这可能会导致从可执行文件中删除防御性代码。
例外：
\1. 允许使用用于创建无限循环的不变的控制表达式。
\2. 允许do…while 循环使用值为0 的布尔型控制表达式。

**示例1：不规范用法**

```c
#define defval 0

void static_p(void)
{
    if (0)
    {
        /*...*/
    }
    if (defval)
    {
        /*...*/
    }
}
```

**示例1：规范用法之一**

```c
//#define defval 0

void static_p(int x)
{

    if (x)
    {
        /*...*/
    }
    else
   {
        /*...*/
   }
}
```

### MISRA_C_2012_14_04_rule　if语句的控制表达式应具有基本布尔类型
> 等级：**强制**　分类：控制语句表达式


强类型检查要求if 语句或迭代语句的控制表达式的基本类型为布尔型。

**示例1：不规范用法**

```c
int i;
if ( i ) /* Non-compliant */
{
}
```

**示例1：规范用法之一**

```c
int i;
if ( i != 0 ) /* Compliant */
{
}
```

---

## 第 15 章 控制流（7 条）

### MISRA_C_2012_15_01_rule　禁止使用goto语句。
> 等级：**强制**　分类：控制流

禁止使用goto语句。

**示例1：不规范用法**

```c
#define xx goto label1;
int main()
{
        xx;
	label1:
	printf("label1\n");
}
```

**示例1：规范用法之一**

```c
int main()
{
	printf("label1\n");
}
```

### MISRA_C_2012_15_02_rule　goto 语句仅允许跳到在同一函数中声明的稍后位置的标签
> 等级：**强制**　分类：控制流

goto 语句仅允许跳到在同一函数中声明的稍后位置的标签

**示例1：不规范用法**

```c
void f(void)
{
    int32_t j = 0;
L1:
    ++j;
    if (10 == j)
    {
        goto L1; /* 违规 */
    }
}
```

**示例1：规范用法之一**

```c
void f(void)
{
    int32_t j = 0;
    ++j;
    if (10 == j)
    {
        goto L2; /* 合规 */
    }
L2 :
    ++j;
}
```

### MISRA_C_2012_15_03_rule　goto 语句引用的标签必须在goto 语句所在代码块或包含该代码块的上级代码块中声明
> 等级：**强制**　分类：控制流

goto 语句引用的标签必须在goto 语句所在代码块或包含该代码块的上级代码块中声明

**示例1：不规范用法**

```c
void f1(int32_t a)
{
    if (a <= 0)
    {
        goto L2; /* 违规 - L2 在其他代码块中 */
    }
    goto L2; /* 违规 - L2 在子代码块中 */
    if (a > 0)
    {
L2:
        ;
    }
}
```

**示例1：规范用法之一**

```c
void f1(int32_t a)
{
    goto L1; /* 合规 - L1 在同代码块 */
    if (a == 0)
    {
        goto L1; /* 合规 - L1 在包含此goto语句的上级代码块中 */
    }
L1:
    if (a > 0)
    {
        ;
    }
}
```

### MISRA_C_2012_15_04_rule　在循环中不应有超过一条break语句或goto语句用来终止循环
> 等级：**强制**　分类：控制流

在循环中不应有超过一条break语句或goto语句用来终止循环

**示例1：不规范用法**

```c
#include<stdio.h>
/*
对任何迭代语句至多只应有一条break语句用于循环的结束
*/
int main()
{
	int i=1;
	while(i<3)
	{
 printf("Number=%d\n",i++);
	}
	do
	{
 printf("Number=%d\n",i++);
	} while(i<5);
	for(i=5;i<7;i++)
	{
 printf("Number=%d\n",i);
	}COBOT_14/
	i=1;
	while(i<3)
	{
 printf("Number=%d\n",i++);
 if(i>2)
 {
 break; //not compliant
 break; //not compliant
 }
	}
	do
	{
 printf("Number=%d\n",i++);
 if(i>4)
 {
 break; //not compliant
 break; //not compliant
 }
	} while(i<5);
	for(i=5;i<7;i++)
	{
 printf("Number=%d\n",i);
 if(i>6)
 {
 break; //not compliant
 break; //not compliant
 }
	}
}
```

**示例1：规范用法之一**

```c
void fun()
{
    for (x = 0; x < LIMIT; ++x)
    {
        if (ExitNow(x))
        {
            break;
        }
        for (y = 0; y < x; ++y)
        {
            if (ExitNow(LIMIT - y))
            {
                break;
            }
        }
    }
}
每个循环都只有一个break 语句用于提前终止循环
```

### MISRA_C_2012_15_05_rule　函数有单一退出点。
> 等级：**强制**　分类：控制流

函数有单一退出点。

**示例1：不规范用法**

```c
int fun() //not compliant
{
    int a;
    if(a>0) return a;
    else return 1;
}
int fun3() //not compliant
{
    int c=0;
    return 1;
    return 2;
}
```

**示例1：规范用法之一**

```c
int fun() //Compliant
{
    int a;

    return (a>0)?a:1;
}
int fun3() //Compliant
{
    int c=0;
    return 1;
    //return 2;
}
一个函数在其结尾有单一的退出点。
```

### MISRA_C_2012_15_06_rule　选择语句和循环语句应该用大括号括起来。
> 等级：**强制**　分类：控制流

选择语句和循环语句应该用大括号括起来。

**示例1：不规范用法**

```c
int main_bad1(void)
{
    int i;
    int data[10];
    for(i=0; i<10; i++)
        data[i] = 0; // not-1
    return 0;
}

int main_bad2(void)
{
    int i = 0;
    int j;
    // ......
    if (0 == i) // Cobot报在此处
        j = 1; // not-1
    else if (1 == i) // Cobot报在此处
        j = 3; // not-2
    else // Cobot报在此处
        j = 5; // not-3
    return 0;
}
```

**示例1：规范用法之一**

```c
int main_good1(void)
{
    int i;
    int data[10];
    for(i=0; i<10; i++)
    {
        data[i] = 0; // ok-1
    }
    return 0;
}

int main_good2(void)
{
    int i = 0;
    int j;
    // ......
    if (0 == i)
    {
        j = 1; // ok-1
    }
    else if (1 == i)
    {
        j = 3; // ok-2
    }
    else
    {
        j = 5; // ok-3
    }
    return 0;
}
[for]循环体，if，else if，else用大括号括起来。
```

### MISRA_C_2012_15_07_rule　所有if..else if应该以else语句结束。
> 等级：**强制**　分类：控制流

所有if..else if应该以else语句结束。

**示例1：不规范用法**

```c
int main(void)
{
    int i = 0, j = 0;
    double x = 0.0;
    // ......
    if (0 == i)
    {
        x = 1.0;
    }
    else if (1 == i) // not-1
    {
        x = 2.0;
    }
    if (0 == j)
    {
        x = x + 5.0;
    }
    return 0;
}
```

**示例1：规范用法之一**

```c
int main(void)
{
    int i = 0, j = 0;
    double x = 0.0;
    // ......
    if (0 == i)
    {
        x = 1.0;
    }
    else if (1 == i)
    {
        x = 2.0;
    }
    else // ok-1
    {
        x = 0.0;
    }
    if (0 == j)
    {
        x = x + 5.0;
    }
    return 0;
}
添加if…else if中缺少else分支。
```

---

## 第 16 章 switch语句（7 条）

### MISRA_C_2012_16_01_rule　switch语句格式要正确。
> 等级：**强制**　分类：switch语句

switch语句格式要正确。

**示例1：不规范用法**

```c
switch(i)
{
case 0: //Not compliant
	printf("case 0\n");
case 1: //Not compliant
        printf("case 1\n");
default: //Not compliant
        printf("default\n");
}
```

**示例1：规范用法之一**

```c
switch(i)
{
case 0: //Compliant
	printf("case 0\n");
        break;
case 1: //Compliant
        printf("case 1\n");
        break;
default: //Compliant
        printf("default\n");
        break;
}
为每个case、default分支添加break语句。
```

### MISRA_C_2012_16_02_rule　switch标签只能用在当最紧密封闭（closely-enclosing）的复合语句是switch语句体的时候
> 等级：**强制**　分类：switch语句


C 标准允许将switch 标签(即case 标签或default 标签)放置在switch 语句主体中的任何语句之前，这可能会导致结构混乱的代码。 为了防止这种情况，switch 标签只能出现在构成switch 语句主体的复合语句的最外层。

**示例1：不规范用法**

```c
switch ( x )
{
    case 1:
        if ( flag )
        {
        case 2: /* Non-compliant */
            x = 1;
        }
        break;
    default:
        break;
}
```

**示例1：规范用法之一**

```c
switch ( x )
{
    case 1:
        break;
    case 2: /* Compliant */
        x = 1;
        break;
    default:
        break;
}
```

### MISRA_C_2012_16_03_rule　无条件的break语句应该终止每个非空的switch子句。
> 等级：**强制**　分类：switch语句

如果开发人员未能以break 语句结束switch 子句，则控制流将“落入”其下面的switch 子句，或者，如果没有这样的子句，则控制流将退出并进入switch 语句后的语句。 尽管有时会故意设计进入随后的switch 子句中，但这通常是一个错误。 在switch 语句末尾出现的未终止的switch 子句可能会落入以后添加的任何switch 子句中。
为了确保可以检测到此类错误，每个switch 子句中的最后一条语句都应为break 语句，如果switch子句为复合语句，则该复合语句中的最后一条语句应为break 语句。
注意：一个switch 子句(switch-clause)被定义为包含至少一个语句。此规则允许出现两个连续的标签(case 或default)没有任何中间语句的情况。

**示例1：不规范用法**

```c
void static_p(int p_1)
{
    int i=0, j=0;
    switch(p_1)
    {
    case 0:
        j = 0;
    case 1:
        j = i;
        break;
    default:
        i = j+1;
    }
    /*...*/
}
```

**示例1：规范用法之一**

```c
void static_p(int p_1)
{
    int i=0, j=0;
    switch(p_1)
    {
    case 0:
        j = 0;
        break;
    case 1:
        j = i;
        break;
    default:
        i = j+1;
        break;
    }
    /*...*/
}
在第(6)行的[case 0:]语句添加[break]语句；在第(12)行的[default:]语句添加[break]语句。
```

### MISRA_C_2012_16_04_rule　在switch 语句中没有default 语句。
> 等级：**强制**　分类：switch语句

在最后的break 语句之前，default 标签后面的switch 子句应至少包含以下任一内容：
◆ 一条语句，或
◆ 一条注释。
对default 标签的要求的目的是防御性编程。Default 标签后面的所有语句均旨在采取适当的措施。 如果标签后没有语句，则可以使用注释来解释为什么未采取任何具体措施。

**示例1：不规范用法**

```c
void static_p(int p_1)
{
    int i = 0, j = 0;
    /*...*/
    switch(p_1)
    {
    case 0:
        j = 0;
        break;
    case 1:
        j = i;
        break;
    }
    /*...*/
}
```

**示例1：规范用法之一**

```c
void static_p(int p_1)
{
    int i = 0, j = 0;
    /*...*/
    switch(p_1)
    {
    case 0:
        j = 0;
        break;
    case 1:
        j = i;
        break;
   default:
        /*...*/
        break;
    }
    /*...*/
}
在第(5)行的[switch]语句中添加[default]分支。
```

### MISRA_C_2012_16_05_rule　default应该是switch语句的第一个或者最后的子句
> 等级：**强制**　分类：switch语句

default应该是switch语句的第一个或者最后的子句

**示例1：不规范用法**

```c
switch ( x )
{
    case 0:
        ++x;
        break;
    default: /* Non-compliant - default is mixed with the case labels */
        x = 0;
        break;
    case 1:
    case 2:
        break;
}
```

**示例1：规范用法之一**

```c
switch ( x )
{
    case 0:
        ++x;
        break;
    case 1:
    case 2:
        break;
    default: /* Compliant - default is the final label */
        x = 0;
        break;
}
第(9)行将default作为switch语句最后的case。
```

### MISRA_C_2012_16_06_rule　每一个switch语句应至少有两个分支。
> 等级：**强制**　分类：switch语句

仅有单个路径的switch 语句是多余的，且其存在很可能表示出现了编程错误。

**示例1：不规范用法**

```c
int main(void)
{
    int i = 0;
    switch(i) // not-1
    {
    default:
        break;
    }
    return 0;
}
```

**示例1：规范用法之一**

```c
int main(void)
{
    int i = 0;
    switch(i) // ok-1
    {
    case 0:
        break;
    default:
        break;
    }
    return 0;
}
在第(4)行的[switch]语句中添加[case]分支。
```

### MISRA_C_2012_16_07_rule　switch表达式不应是有效的布尔值。
> 等级：**强制**　分类：switch语句

标准C 要求switch 语句的控制表达式具有整数类型。由于(C 语言中)布尔值是用整数实现的，因此可能会出现由布尔表达式控制的switch 语句。在这种情况，用if-else 构造会更合适。

**示例1：不规范用法**

```c
int main(void)
{
    int x = 0;
    int y = 0;
    // ......
    switch(0 == x) // not-1
    {
    case 1:
        y = 1;
        break;
    default:
        y = 2;
        break;
    }
    return 0;
}
```

**示例1：规范用法之一**

```c
int main(void)
{
    int x = 0;
    int y = 0;
    // ......
    switch(x) // ok-1
    {
    case 1:
        y = 1;
        break;
    default:
        y = 2;
        break;
    }
    return 0;
}
在第(6)行[switch]分支表达式改为[x]。
```

---

## 第 17 章 函数（8 条）

### MISRA_C_2012_17_01_rule　禁止使用stdarg.h
> 等级：**强制**　分类：函数


标准C 中列出了许多与<stdarg.h>功能相关的不确定行为的实例，包括：
◆ 在使用va_start 的函数的末尾未使用va_end；
◆ va_arg 在同一va_list 上的不同函数中使用；
◆ 参数的类型与va_arg 指定的类型不兼容。

**示例1：不规范用法**

```c
#include <stdarg.h>
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
void h(va_list ap) //not
{
	double y;
    y=va_arg(ap, double); //not
}

void f(uint16_t n)
{
	uint32_t x;
    va_list ap; //not
    va_start(ap,n); //not
    x=va_arg(ap,uint32_t); //not
    h(ap);
    x=va_arg(ap,uint32_t); //not
    h(ap);
}

void g(void)
{
	f(1);
}
```

### MISRA_C_2012_17_02_rule　函数不能调用自身。
> 等级：**强制**　分类：函数

递归会带来堆栈空间溢出的危险，这可能会导致严重的故障。除非对递归进行了严格控制，否则无法在执行之前确定最坏情况的堆栈使用情况。

**示例1：不规范用法**

```c
void foo_B();

void foo_A()
{
	foo_B();//函数[foo_A]调用了函数[foo_B]，在函数[foo_B]调用了函数[foo_A]，存在循环调用关系。
}
void foo_B()
{
	foo_A();//函数[foo_A]调用了函数[foo_B]，在函数[foo_B]调用了函数[foo_A]，存在循环调用关系。
}
int main()
{
	foo_A();
  	return 0;
}
```

**示例1：规范用法之一**

```c
void foo_B();

void foo_A()
{
     if(...) //增添合适的调用条件检查
	foo_B();
}
void foo_B()
{
     if(...) //增添合适的调用条件检查
	foo_A();
}
int main()
{
	foo_A();
  	return 0;
}
函数循环调用中存在调用条件检查。
```

### MISRA_C_2012_17_03_rule　函数不能隐式声明。
> 等级：**强制**　分类：函数

在原型存在的情况下进行函数调用，(C 语言编译器的)约束条件可确保参数的数量与参数的数量匹配，并且可以将每个参数分配给其相应的参数。
如果隐式声明函数，C90 编译器将假定该函数的返回类型为int。由于隐式函数声明不提供原型，因此编译器将没有有关函数参数的数量及其类型的信息。不正确的类型转换可能导致传递参数和分配返回值以及其他未定义的行为。

**示例1：不规范用法**

```c
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;

int fun1(void);
int fun1(void) {}; // ok

int main(void)
{
    fun2(1);
    return 0;
}
void fun2(uint16_t n) // not
{
	uint32_t x;
}
```

**示例1：规范用法之一**

```c
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;

int fun1(void);
int fun1(void) {}; // ok
void fun2(uint16_t n) ;
int main(void)
{
    fun2(1);
    return 0;
}
void fun2(uint16_t n) // not
{
	uint32_t x;
}
第(9)行调用函数[fun2]，第(6)行声明函数[fun2]。
```

### MISRA_C_2012_17_04_rule　返回值为non_void的函数中只有 return 语句没有返回值。
> 等级：**强制**　分类：函数

函数的返回值有return 语句的表达式提供。如果非void 函数没有返回值，但是调用函数使用了返回的值，则该行为是不确定的。为避免这种情况，限制非void 函数：
◆ 每个return 语句都必须有一个表达式，并且
◆ 如果不遇到return 语句，禁止执行到函数的末尾。

**示例1：不规范用法**

```c
int fun1(int);
int fun2(int);
int fun3(int);
int fun1(int a)
{
    ; //not compliant
}
int fun2(int b)
{
    return ; //not compliant
}
int fun3(int c)
{
    return c; // compliant
}
```

**示例1：规范用法之一**

```c
int fun1(int);
int fun2(int);
int fun3(int);
int fun1(int a)
{
    return a; //not compliant
}
int fun2(int b)
{
    return b; //not compliant
}
int fun3(int c)
{
    return c; // compliant
}
```

### MISRA_C_2012_17_05_rule　与声明为数组类型的函数的形参对应的实参应具有适当数量的元素
> 等级：**强制**　分类：函数


将函数形参声明为数组比声明为指针能更清楚地指定函数接口。(声明为数组时，)该函数期望的最小元素数已明确说明，而使用指针则不能。
函数形参声明为不指定大小的数组表示该函数可以处理任何大小的数组。在这种情况下，预计将通过其他方式传达数组大小，例如，通过将数组长度作为另一个参数进行传递，或通过使用定值作为数组终止(最大下标值)。
使用数组边界是一种建议方法，因为它允许在函数体内实现越界检查，并在参数传递上进行额外检查。在C 语言中，将大小错误的数组传递给具有指定大小的参数是合法的，这可能会导致意外行为。

**示例1：不规范用法**

```c
void fn1 ( int32_t array1[ 4 ] );
void fn2 ( int32_t array2[ ] );
void fn ( int32_t *ptr )
{
  int32_t arr3[ 3 ] = { 1, 2, 3 };
  int32_t arr4[ 4 ] = { 0, 1, 2, 3 };

  fn1 ( arr4 ); // Compliant
  fn1 ( arr3 ); // Non-compliant
  fn1 ( ptr ); // Compliant
  fn2 ( arr4 ); // Compliant
  fn2 ( ptr ); // Compliant
}
```

**示例1：规范用法之一**

```c
void fn1 ( int32_t array1[ 3 ] );
void fn2 ( int32_t array2[ ] );
void fn ( int32_t *ptr )
{
  int32_t arr3[ 3 ] = { 1, 2, 3 };
  int32_t arr4[ 4 ] = { 0, 1, 2, 3 };

  fn1 ( arr4 ); // Compliant
  fn1 ( arr3 ); // Compliant
  fn1 ( ptr ); // Compliant
  fn2 ( arr4 ); // Compliant
  fn2 ( ptr ); // Compliant
}
将第(1)行函数声明[fn1]中形参数组array1的长度改为[3]。
```

### MISRA_C_2012_17_06_rule　数组参数的声明中不得含有static关键字在[]之间
> 等级：**强制**　分类：函数

数组参数的声明中不得含有static关键字在[]之间

**示例1：不规范用法**

```c
#include <stdio.h>
int total ( int n, int a[ static 20 ] ) //not compliant
{
    int i;
    int sum = 0;

    for ( i = 0; i < n; ++i )
    {
    sum = sum + a[ i ];
    }
    return sum;
}
int main(void)
{
	return 0;
}
```

**示例1：规范用法之一**

```c
#include <stdio.h>
int total ( int n, int a[ 20 ] ) // compliant
{
    int i;
    int sum = 0;

    for ( i = 0; i < n; ++i )
    {
    sum = sum + a[ i ];
    }
    return sum;
}
int main(void)
{
	return 0;
}
第(2)去掉static。
```

### MISRA_C_2012_17_07_rule　函数返回值如果是non—void，则必须被使用
> 等级：**强制**　分类：函数

函数返回值如果是non—void，则必须被使用

**示例1：不规范用法**

```c
#include <stdio.h>
int total ( int sum ) //not compliant
{
    return sum;
}

void fun()
{
    total(20); //not compliant
    int x = total(20); //compliant
    int y = 0;
    y = total(20); //compliant
    return ;
}
int main(void)
{
    total(20); //not compliant
    int x = total(20); //compliant
    int y = 0;
    y = total(20); //compliant

	return 0;
}
```

**示例1：规范用法之一**

```c
#include <stdio.h>
int total ( int sum ) //not compliant
{
    return sum;
}

void fun()
{
    (void)total(20); //compliant
    int x = total(20); //compliant
    int y = 0;
    y = total(20); //compliant
    return ;
}
int main(void)
{
    (void)total(20); //compliant
    int x = total(20); //compliant
    int y = 0;
    y = total(20); //compliant

	return 0;
}
第(9、17)行函数[total]前加void。
```

### MISRA_C_2012_17_08_rule　函数参数不应该被修改
> 等级：**强制**　分类：函数

函数参数不应该被修改

**示例1：不规范用法**

```c
#include <stdio.h>
int total1 ( int sum )
{
    int p = 1;
    sum = p; //not compliant
    return p;
}
void total2( char *p, char *q )
{
    p =q; //not compliant
    *p = *q; //compliant
    return;
}

int main(void)
{
    char *p = NULL;
    char ch = 'a';
    p = &ch;
	return 0;
}
```

**示例1：规范用法之一**

```c
#include <stdio.h>
int total1 ( int sum )
{
    int p = 1;
    //sum = p; //not compliant
    return p;
}
void total2( char *p, char *q )
{
    //p =q; //not compliant
    *p = *q; //compliant
    return;
}

int main(void)
{
    char *p = NULL;
    char ch = 'a';
    p = &ch;
	return 0;
}
```

---

## 第 18 章 指针和数组（8 条）

### MISRA_C_2012_18_01_rule　指针操作数的算术运算应仅用于寻址与该指针操作数相同数组的元素
> 等级：**强制**　分类：指针和数组


C 语言标准中允许创建一个指向数组末尾再加1 的指针，此规则也允许这么做。但是，解引用(dereferencing, 即*pointer 操作)指向数组末尾再加1 的指针的行为是未定义的，因此被此规则禁止。
此规则适用于下述所有形式的数组索引：
integer_expression + pointer_expression
pointer_expression + integer_expression
pointer_expression - integer_expression
pointer_expression += integer_expression
pointer_expression -= integer_expression
++pointer_expression
pointer_expression++
--pointer_expression
pointer_expression--
pointer_expression[integer_expression]
integer_expression[pointer_expression]
如果通过上述表达式获得的结果既不是指向与指针表达式(pointer_expression)所指向的相同数组元素的指针，也不是指向该数组末尾再加1 的指针，则其行为是未定义的。
多重数组，即“由数组组成的数组”。此规则不允许使用指针算数的方式来寻址不同的子数组。数组下标不得越过其“内部”边界，因为其行为是未定义的。

**示例1：不规范用法**

```c
void f1(void)
{
    int32_t data = 0;
    int32_t b = 0;
    int32_t c[10] = { 0 };
    int32_t d[5][2] = { 0 }; /* 二维数组 */
    int32_t *p3 = &c[11]; /* 违规 - 未定义, 指针越界多于1 */
    data = *p2; /* 违规 - 未定义, 反引用越界1的值 */
    c[-1] = 0; /* 违规 - 未定义, 超出数组范围 */
    data = c[10]; /* 违规 - 未定义, 反引用越界1的值 */
    data = d[2][3]; /* 违规 - 未定义, 超出内部边界 */
}
```

**示例1：规范用法之一**

```c
void f1(void)
{
    int32_t data = 0;
    int32_t b = 0;
    int32_t c[10] = { 0 };
    int32_t d[5][2] = { 0 }; /* 二维数组 */
    int32_t *p1 = &c[0]; /* 合规 */
    int32_t *p2 = &c[10]; /* 合规 - 指针越界1 */
    p1++; /* 合规 */
    data = *(&data + 0); /* 合规 - C语言将data识别为长度为1的数组 */
    d[3][1] = 0; /* 合规 */
    data = *(*(d + 3) + 1); /* 合规 */
    p1 = d[1]; /* 合规 */
    data = p1[1]; /* 合规 - p1 寻址长度为2的数组 */
}
```

### MISRA_C_2012_18_02_rule　指针减法应该指向数组中的元素。
> 等级：**强制**　分类：指针和数组

此规则适用于以下形式的表达式：
pointer_expression_1 - pointer_expression_2
如果pointer_expression_1 和pointer_expression_2 未指向同一数组的元素，也未指向该数组末尾的元素，则这是未定义的行为。

**示例1：不规范用法**

```c
void fun()
{
    char *string1="abc";
    char *string2="bcd";
    int m = string1 - string2;
}
```

**示例1：规范用法之一**

```c
void fun()
{
    char string1="abc";
    char string2=string1+1;
    int m = string1 - string2;
}
```

### MISRA_C_2012_18_03_rule　>、>=、<、<= 不应用在指针类型上，除非指针指向同一数组。
> 等级：**强制**　分类：指针和数组

\>、>=、<、<=不应用在指针类型上，除非指针指向同一数组。
如果两个指针未指向同一对象，则尝试在两个指针之间进行比较将产生不确定的行为。

**示例1：不规范用法**

```c
int fsub(int *a, int *b);
int main()
{
    int sub = 0;
    int a = 1,b = 2;
    sub = fsub(&a, &b);
    return 0;
}
int fsub(int *a, int *b)
{
    int sub = 0;
    if(a > b) //not complaint
    {
        sub = (*a) - (*b);
    }
    else if(a < b) //not complaint
    {
        sub = (*b) - (*a);
    }
    else
    {
        sub = 0;
    }
    return sub;
}
```

**示例1：规范用法之一**

```c
int good_fsub(int *a, int *b)
{
    int sub = 0;
    if((*a) > (*b)) //ok
    {
        sub = (*a) - (*b);
    }
    else if((*a) < (*b)) //ok
    {
        sub = (*b) - (*a);
    }
    else
    {
        sub = 0;
    }
    return sub;
}
第[12]、[16]行对[a]、[b]两个指针的内容进行大于或者小于的逻辑比较。
```

### MISRA_C_2012_18_04_rule　操作符+，-,+=,-=不应该作用在指针上。
> 等级：**强制**　分类：指针和数组

使用数组下标语法ptr[expr]进行数组索引是指针算术的首选形式，因为它通常比指针操作更清晰，因此出错率更低。任何显式计算的指针值都有可能访问意外或无效的内存地址。使用数组索引也可以实现这种行为，但是下标语法可以简化手动检查的任务。
C 语言中的指针算法可能会使新手感到困惑。表达式ptr + 1 可能会错误地解释为ptr 中保存的地址加1。实际上，新的内存地址取决于指针目标的字节大小。如果错误地应用了sizeof，这种误解可能导致意外的行为。
但是，在某些情况下谨慎地使用++进行指针操作可能会更自然。例如，在内存测试期间顺序访问位置，将内存空间视为位置的连续集合更为方便，并且可以在编译时确定地址范围。

**示例1：不规范用法**

```c
typedef unsigned char uint8_t;

void fn1 ( void )
{
uint8_t a[ 10 ];
uint8_t *ptr;
uint8_t index = 0U;
index = index + 1U;
a[ index ] = 0U;
ptr = &a[ 5 ];
ptr = a;
ptr++; /* Compliant - increment operator not + */
*( ptr + 5 ) = 0U; /* Non-compliant */
}
```

**示例1：规范用法之一**

```c
typedef unsigned char uint8_t;

void fn1 ( void )
{
uint8_t a[ 10 ];
uint8_t *ptr;
uint8_t index = 0U;
index = index + 1U;
a[ index ] = 0U;
ptr = &a[ 5 ];
ptr = a;
ptr++; /* Compliant - increment operator not + */
ptr[5] = 0U; /* Compliant */
}
将*(ptr+5)改成ptr[5]
```

### MISRA_C_2012_18_05_rule　对象声明所包含的间接指针不得多于2级。
> 等级：**强制**　分类：指针和数组

一个类型最多允许连续使用两个指针声明符。声明中出现的任何typedef-name 都将被识别为其所表示的类型。
使用多于层的指针嵌套会严重损害理解代码行为的能力，因此应避免使用。

**示例1：不规范用法**

```c
#include <stdlib.h>
int main(void)
{
    unsigned int array[5] = {0, 1, 2, 3, 4};
    unsigned int *p1_ptr = NULL, **p2_ptr = NULL;
    unsigned int ***p3_ptr = NULL; // not-1
    unsigned int data[5];
    unsigned int i;
    p1_ptr = array;
    p2_ptr = &p1_ptr;
    p3_ptr = &p2_ptr;
    for(i = 0; i < 5; i++)
    {
        data[i] = *(**p3_ptr + i);
    }
    return 0;
}
```

**示例1：规范用法之一**

```c
#include <stdlib.h>
int main(void)
{
    unsigned int array[5] = {0, 1, 2, 3, 4};
    unsigned int *p1_ptr = NULL, **p2_ptr = NULL;
    unsigned int **p3_ptr = NULL; // ok-1
    unsigned int data[5];
    unsigned int i;
    p1_ptr = array;
    p2_ptr = &p1_ptr;
    p3_ptr = p2_ptr;
    for(i = 0; i < 5; i++)
    {
        data[i] = *(*p3_ptr + i);
    }
    return 0;
}
```

### MISRA_C_2012_18_06_rule　自动存储对象的地址不应赋值给其他的在第一个对象已经停止存在后仍然保持的对象。
> 等级：**强制**　分类：指针和数组

对象的地址可以通过以下方式复制：
◆ 赋值；
◆ 内存移动或复制功能。
当对象的生命周期结束时，该对象的地址将变得不确定。任何不确定地址的使用都会导致不确定的行为。

**示例1：不规范用法**

```c
int * fun(void)
{
    int a;
    return &a;
}
```

**示例1：规范用法之一**

```c
void fun(int* p)
{
    int a = 10;
    *p = a;
}
通过指针将函数内部变量的值传递出去
```

### MISRA_C_2012_18_07_rule　数组的声明不详细。
> 等级：**强制**　分类：指针和数组

灵活数组成员的存在可能会以程序员无法期望的方式修改sizeof 运算符的行为。将包含灵活数组成员的结构分配给相同类型的另一个结构可能无法按预期的方式执行，因为它所复制的那些元素，只到灵活数组成员的开头，却不包括灵活数组。

**示例1：不规范用法**

```c
void static_p(void)
{
    unsigned int u_array[] = {0,1,2}; //not compliant
    /*...*/
}
```

**示例1：规范用法之一**

```c
void static_p(void)
{
    unsigned int u_array[3] = {0,1,2}; //not compliant
    /*...*/
}
数组声明时同时显示声明数组长度。
```

### MISRA_C_2012_18_08_rule　长度可变的数组不应该被使用
> 等级：**强制**　分类：指针和数组


当在块或函数原型中声明的数组的大小不是整数常量表达式时，将指定可变长度数组类型。它们通常被实现为存储在堆栈中的可变大小的对象。因此，使用它们可能无法静态确定必须为堆栈保留的内存量。
如果可变长度数组的大小为负或零，则行为是未定义的。
如果在要求与另一个数组类型(可能本身是可变长度)兼容的上下文中使用了可变长度数组，则数组类型的大小应相同。 此外，所有大小均应为正整数。 如果不满足这些要求，则行为是不确定的。
如果在sizeof 运算符的操作数中使用了可变长度数组类型，则在某些情况下，不确定是否能正确评估数组大小表达式。<span style="font-size: 0.83em; font-family: Helvetica, Arial, sans-serif; color: rgb(51, 51, 51); background-color: rgb(255, 255, 255);">
</span>

**示例1：不规范用法**

```c
#include<stdio.h>
#include<malloc.h>
void fun2(int n)
{
    int a[n]; //not compliant
    int b[10];
    return;
}
int main(void)
{
    int a = 10;
    fun2(a);
    return 0;
}
```

**示例1：规范用法之一**

```c
#include<stdio.h>
#include<malloc.h>
void fun2(int n)
{
    int a[10]; //compliant
    int b[10];
    return;
}
int main(void)
{
    int a = 10;
    fun2(a);
    return 0;
}
```

---

## 第 19 章 重叠存储（2 条）

### MISRA_C_2012_19_01_rule　对象不能赋值给重叠（overlapping）对象
> 等级：**强制**　分类：重叠存储


当创建两个对象在内存中有一些重叠并且一个对象被赋值或复制给另一个对象时，该行为是不确定的。
例外：
以下情况由于其行为是明确定义的，因此是被允许的：
1.完全重叠且具有兼容类型的两个对象之间的分配(忽略其类型限定符)
2.使用标准库函数在存储在部分或完全重叠的对象之间复制

**示例1：不规范用法**

```c
void fn ( void )
{
  union
  {
    int16_t i;
    int32_t j;
  } a = { 0 }, b = { 1 };
  a.j = a.i; /* Non-compliant */
  a = b; /* Compliant - exception 1 */
}
```

**示例1：规范用法之一**

```c
void fn ( void )
{
  union
  {
    int16_t i;
    int32_t j;
  } a = { 0 }, b = { 1 };
  // a.j = a.i; /* Non-compliant */
  a = b; /* Compliant - exception 1 */
}
```

### MISRA_C_2012_19_02_rule　禁止使用联合。
> 等级：**强制**　分类：重叠存储

一个联合体成员可以被修改，然后可以以明确定义的方式回读同一成员。
但是，如果写入了一个联合体成员，然后又读回了另一个联合体成员，则行为取决于成员的相对大小：
◆ 如果读取的成员比写入的成员宽，则其值不确定。
◆ 否则，其值是由实现定义的(取决于编译环境和其配置)。
C 标准允许通过访问类型为无符号字符数组的另一个成员的方式访问联合体成员的字节。但是，由于未指定值的字节也可以被访问，因此不应使用联合。
如果不遵循此规则，则下面几类行为需要被明确确定：
◆ 填充方式 - 联合体的末尾插入了多少填充；
◆ 对齐方式 - 联合体内的结构体成员如何对齐；
◆ 字节序 - 大端模式还是小端模式；
◆ 位序 - 位在字节内是何顺序，以及如何分配位域。

**示例1：不规范用法**

```c
union //Not compliant
{
    int iu;
    float fu;
}ug1,ug2;
```

**示例1：规范用法之一**

```c
struct //compliant
{
    int iu;
    float fu;
}st1,st2;
```

---

## 第 20 章 预处理命令（14 条）

### MISRA_C_2012_20_01_rule　#include指令之前只能是预处理指令或注释。
> 等级：**强制**　分类：预处理命令

为了提高代码的可读性，应将特定代码文件中的所有#include 伪指令组合在一起，放在文件顶部附近。此外，在声明或定义中使用#include 包含标准头文件，或者在包含相关标准头文件之前使用标准库的部分内容，会导致未定义的行为。

**示例1：不规范用法**

```c
int main_bad(void)
{
#include "..\061\061.h" // not-1
    int ix = 0;
    int iy = 1;
    int iz = 2;
    int idata;
    idata = ix + iy + iz;
    return 0;
}
```

**示例1：规范用法之一**

```c
#include "..\060\060.h" // ok-1
int main_good(void)
{
    int ix = 0;
    int iy = 1;
    int iz = 2;
    int idata;
    idata = ix + iy + iz;
    return 0;
}
将[#include]语句放在可执行代码前，文件最开始的位置。
```

### MISRA_C_2012_20_02_rule　",","/*"或者"//"和反斜杠不能出现在头文件的名称中
> 等级：**强制**　分类：预处理命令

“'”、“"”、“/*”或“//”和反斜杠不能出现在头文件的名称中。
发生下面情况时，行为无法确定：
◆ 引用头文件预处理指令中的“<”和“>”分隔符之间出现“'”、“\”、“"”字符，或者“/*”或“//”字符序列；
◆ 引用头文件预处理指令中的“"”分隔符之间出现“'”、“\”字符，或者“/*”或“//”字符序列；

**示例1：不规范用法**

```c
#include <\ctype.h>

static void static_100(void)
{
  /* ... */
}
```

**示例1：规范用法之一**

```c
#include <ctype.h>

static void static_100(void)
{
  /* ... */
}
在第(1)行去掉[include]语句中非标准字符[\]。
```

### MISRA_C_2012_20_03_rule　在#include 后面的文件名没有使用尖括号或者" "。
> 等级：**强制**　分类：预处理命令

在#include 后面的文件名没有使用尖括号或者""。
\#include 指令必须是下面形式之一，否则其行为不确定：
◆ #include <filename>
◆ #include "filename"

**示例1：不规范用法**

```c
#include <stdio.h>
#include head1.h //Not compliant
```

**示例1：规范用法之一**

```c
#include <stdio.h>
#include "head1.h"
给#include后面的head1.h加上" "。
```

### MISRA_C_2012_20_04_rule　禁止通过宏定义改变关键字和基本类型的含义
> 等级：**强制**　分类：预处理命令

禁止通过宏定义改变关键字和基本类型的含义。

**示例1：不规范用法**

```c
#define long 10 // not compliant
int main_bad(void)
{
    int i = 0;
    i = long;
    return 0;
}
```

**示例1：规范用法之一**

```c
#define LONG_NUM 100 // ok
int main_good(void)
{
    int i;
    i = LONG_NUM;
    return 0;
}
在第(1)行宏定义了[LONG_NUM]，其中[LONG_NUM]不是关键字也不是基本类型
```

### MISRA_C_2012_20_05_rule　禁止使用#undef
> 等级：**强制**　分类：预处理命令

禁止使用#undef

**示例1：不规范用法**

```c
#define A
#undef A //Not compliant

int main()
{
	# undef B //Not compliant
	return 0;
}
```

**示例1：规范用法之一**

```c
#define A
//#undef A //Not compliant

int main()
{
//	# undef B //Not compliant
	return 0;
}
不要使用#undef。
```

### MISRA_C_2012_20_06_rule　看起来像一个预处理指令不能充当宏参数
> 等级：**强制**　分类：预处理命令

看起来像一个预处理指令不能充当宏参数

**示例1：不规范用法**

```c
#define M( A ) printf ( #A )
#include <stdio.h>
void main ( void )
{
M ( //not compliant
#ifdef SW
"Message 1"
#else
"Message 2"
#endif
);
}
```

**示例1：规范用法之一**

```c
#define M( A ) printf ( #A )
#include <stdio.h>
void main ( void )
{
#ifdef SW
 M( "Message 1");
#else
 M( "Message 2");
#endif
}
```

### MISRA_C_2012_20_07_rule　宏参数必须带括号。
> 等级：**强制**　分类：预处理命令

宏参数必须带括号。

**示例1：不规范用法**

```c
#define static_p(x) x>=0?x:-x
void test_p(void)
{
    unsigned int result;
    int a = 6, b = 5;
    /*...*/
    result = static_p(a-b);
    result = static_p(a)+1;
    /*...*/
}
```

**示例1：规范用法之一**

```c
#define static_p(x) (x)>=0?(x):-(x)
void test_p(void)
{
    unsigned int result;
    int a = 6, b = 5;
    /*...*/
    result = static_p(a-b);
    result = static_p(a)+1;
    /*...*/
}
第(1)行函数宏[static_p]的参数[x]，在函数宏实现中用()括起来。
```

### MISRA_C_2012_20_08_rule　在#if或#elif预处理指令的控制表达式应计算为0或1
> 等级：**强制**　分类：预处理命令

在#if或#elif预处理指令的控制表达式应计算为0或1

**示例1：不规范用法**

```c
#define FALSE 0
#define TRUE 1
#if FALSE /* Compliant */
#endif
#if 10 /* Non-compliant */
#endif

#if !defined ( X ) /* Compliant */
#endif
#if A > B /* Compliant */
#endif
```

**示例1：规范用法之一**

```c
#define FALSE 0
#define TRUE 1
#if FALSE /* Compliant */
#endif
#if 1 /* Compliant */
#endif

#if !defined ( X ) /* Compliant */
#endif
#if A > B /* Compliant */
#endif
将第(5)行预处理指令[#if]的控制表达式改为[1]。
```

### MISRA_C_2012_20_09_rule　#if 或#elif 预处理指令的控制表达式中使用的所有标识符应在其评估前被#define 定义
> 等级：**强制**　分类：预处理命令

\#if 或#elif 预处理指令的控制表达式中使用的所有标识符应在其评估前被#define 定义。

**示例1：不规范用法**

```c
#if M == 0 /* Non-compliant */
#endif
```

**示例1：规范用法之一**

```c
// 第一种修复方案
#if defined ( M ) /* Compliant - M is not evaluated */
#if M == 0 /* Compliant - M is known to be defined */
#endif
#endif

// 第二种修复方案
#if defined ( M ) && ( M == 0 )
#endif
```

### MISRA_C_2012_20_10_rule　不要使用# 或## 预处理操作符。
> 等级：**强制**　分类：预处理命令

多个“#”运算符，多个“##”运算符或者“#”运算符与“##”运算符混合出现的预处理程序中，其运算符评估顺序在C 语言中未明确指定。因此，在某些情况下，我们无法预测宏展开的结果。
使用“##”运算符可能会导致代码晦涩难懂。

**示例1：不规范用法**

```c
#include <stdio.h>

typedef unsigned int UINT_32;
typedef unsigned char UCHAR;
UCHAR string[50];
#define cat(x) (&string[##(x)]) // not-1

void static_125( UCHAR string[50], UINT_32 n)
{

   UCHAR *token1;

   token1=cat(n);
}
```

**示例1：规范用法之一**

```c
#include <stdio.h>

typedef unsigned int UINT_32;
typedef unsigned char UCHAR;
UCHAR string[50];
#define cat(x) (&string[(x)]) // ok-1

void static_125( UCHAR string[50], UINT_32 n)
{

   UCHAR *token1;

   token1=cat(n);
}
去掉第(6)行宏定义中的##。
```

### MISRA_C_2012_20_11_rule　宏参数紧跟在＃操作符后不得立即跟着一个##操作数
> 等级：**强制**　分类：预处理命令


C 语言未指定多个“#”运算符，多个“##”运算符或者“#”与“##”混合出现的预处理程序的评估顺序。Rule 20.10 不建议使用“#”和“##”。特别是，“#”运算符的结果是字符串，将其粘贴到任何其他预处理令牌中都极可能产生无效的令牌。

**示例1：不规范用法**

```c
#define A( x ) #x /* Compliant */
#define B( x, y ) x ## y /* Compliant */
#define D(x,y) (#x)+x##y /* Compliant */
#define C( x, y ) #x ## y /* Non-compliant */
```

**示例1：规范用法之一**

```c
#define A( x ) #x /* Compliant */
#define B( x, y ) x ## y /* Compliant */
#define D(x,y) (#x)+x##y /* Compliant */
#define C( x, y ) #x+ y## y /* Compliant */
```

### MISRA_C_2012_20_12_rule　作为＃或##操作符的一个宏参数，本身有待进一步宏替换，只能是用作这些运算符的操作数
> 等级：**强制**　分类：预处理命令


用作“#”或“##”运算符的操作数的宏参数在使用前不会展开。替换文本中其他位置出现的相同参数则会被展开。如果宏参数本身需要进行宏替换，则在宏替换内的混合上下文中使用它可能无法满足开发人员的期望。

**示例1：不规范用法**

```c
#define AA 0xffff
#define BB( x ) ( x ) + wow ## x /* Non-compliant */
void f ( void )
{
	int wowAA = 0;
/* Expands as wowAA = ( 0xffff ) + wowAA; */
	wowAA = BB ( AA );
}
```

**示例1：规范用法之一**

```c
#define AA 0xffff
#define BB( x， y ) ( x ) + ( y ) /* compliant */
void f ( void )
{
	int wowAA = 0;
/* Expands as wowAA = ( 0xffff ) + wowAA; */
	wowAA = BB ( AA， wowAA );
}
根据具体情况，适当改写宏函数。
```

### MISRA_C_2012_20_13_rule　第一个字符为#的行应是一个有效的预处理指令
> 等级：**强制**　分类：预处理命令

第一个字符为#的行应是一个有效的预处理指令。

**示例1：不规范用法**

```c
#define AAA 2
int32_t foo ( void )
{
int32_t x = 0;
#ifndef AAA
x = 1;
#else1 /* Non-compliant */
x = AAA;
#endif
return x;
}
```

**示例1：规范用法之一**

```c
#define AAA 2
int32_t foo ( void )
{
int32_t x = 0;
#ifndef AAA
x = 1;
#else /* Non-compliant */
x = AAA;
#endif
return x;
}
使用有效的预处理指令。
```

### MISRA_C_2012_20_14_rule　所有#else，#elif 和#endif 预处理程序指令都应和与其相关的#if，#ifdef 或#ifndef 指令 位于同一文件中
> 等级：**强制**　分类：预处理命令

所有#else，#elif 和#endif 预处理程序指令都应和与其相关的#if，#ifdef 或#ifndef 指令位于同一文件中。

**示例1：不规范用法**

```c
#define MISMATCHEDIF 1

#if MISMATCHEDIF == 1

void static_126(void)
{
   /* ... */
}
```

**示例1：规范用法之一**

```c
#define MISMATCHEDIF 1

#if MISMATCHEDIF == 1

void static_126(void)
{
   /* ... */
}

#endif // MISMATCHEDIF
在同文件第(10)行添加#endif，与#if配对使用。
```

---

## 第 21 章 标准库（12 条）

### MISRA_C_2012_21_01_rule　所有的#define和#undef不得用于保留标识符或保留的宏名。
> 等级：**强制**　分类：标准库

所有的#define和#undef不得用于保留标识符或保留的宏名。

**示例1：不规范用法**

```c
#define FILE unsigned int // not
void dummy(void)
{
    /*...*/
}
```

**示例1：规范用法之一**

```c
#define FILE_123 unsigned int // ok
void dummy(void)
{
    /*...*/
}
在第(1)行将[FILE]改为[FILE_123]，解决重定义保留字问题。
```

### MISRA_C_2012_21_02_rule　不得声明保留的标识符或宏名称
> 等级：**强制**　分类：标准库


C 标准允许实现依赖于保留标识符的行为，并且可以对其进行特殊对待。如果保留的标识符被重用，则程序可能会表现出不确定的行为。

**示例1：不规范用法**

```c
/*
* 包含 <stddef.h> 以定义 size_t
*/
#include <stddef.h>
extern void *memcpy (void *restrict s1, const void *restrict s2, size_t n);
```

**示例1：规范用法之一**

```c
#include <stddef.h>
#include <string.h>

声明此[memcpy]方法的合规做法是包含[string.h]
```

### MISRA_C_2012_21_03_rule　禁止使用stdlib.h的动态分配内存与释放函数
> 等级：**强制**　分类：标准库


使用标准库提供的动态内存分配和释放例程很容易导致不确定的行为，例如：
◆ 释放未被动态分配的内存；
◆ 以任何方式使用指向已释放的内存的指针；
◆ 在将值存储到分配的内存之前访问该内存。

**示例1：不规范用法**

```c
int main()
{
  char *p;
  p = (char *)malloc(10);
  //....
  free(p);
  return 0;
}
```

**示例1：规范用法之一**

```c
int main()
{
  char *p;
  p = new char[100];
  //....
  delete(p);
  return 0;
}
可以使用new、delete替代malloc、free。
```

### MISRA_C_2012_21_04_rule　禁用setjmp.h
> 等级：**强制**　分类：标准库


<setjmp.h>中指定的任何功能均不得使用。
setjmp 和longjmp 允许绕过正常的函数调用机制。使用它们可能导致不确定的行为。

**示例1：不规范用法**

```c
#include <setjmp.h>
#include <stdio.h>

int main(){
     return 0;
}
```

**示例1：规范用法之一**

```c
//#include <setjmp.h>
#include <stdio.h>

int main(){
     return 0;
}
将#include <setjmp.h>注释掉。
```

### MISRA_C_2012_21_05_rule　禁用signal.h
> 等级：**强制**　分类：标准库

禁用signal.h。

**示例1：不规范用法**

```c
#include<signal.h> //not compliant
int main()
{
  /* ... */
}
```

**示例1：规范用法之一**

```c
//#include<signal.h> //not compliant
int main()
{
  /* ... */
}
将第(1)行的#include<signal.h>注释掉。
```

### MISRA_C_2012_21_06_rule　禁用input, output 函数
> 等级：**强制**　分类：标准库


此规则适用于<stdio.h>指定的功能，以及在C99 标准的第4.24.2 和7.24.3 节描述的<wchar.h>指定的宽字符等效项。
这些文件里的标识符均不得使用，并且不得展开含有这些标识符的宏。
文件和文件流的I/O 操作具有未指定，未定义和实现定义的行为。

**示例1：不规范用法**

```c
#include <stdio.h>

int main(){
     int i, j;
     scanf("%d%d", &i, &j);
     printf("输入的数为：%d，%d", i, j);
     return 0;
}
```

**示例1：规范用法之一**

```c
#include <iostream>

using namespace std;

int main(){
    int i, j;
    cin >> i;
    cin >> j;
    cout << "输入的数为：" << i << ", " << j << endl;
    return 0;
}
减少<stdio.h>等输入输出函数；或者用<iostream>替代。
```

### MISRA_C_2012_21_07_rule　不应使用库<stdlib.h>中的函数 atof、atoi 和 atol 。
> 等级：**强制**　分类：标准库

不应使用库<stdlib.h>中的函数atof、atoi、atol 和atoll。

**示例1：不规范用法**

```c
int main()
{
    char *a="-100.23";
    char *b="200e-2";
    float c;
    c=atof(a)+atof(b); //not compliant
    printf("c=%.2f\n",c);
}
```

**示例1：规范用法之一**

```c
int main()
{
    char *a="-100.23";
    char *b="200e-2";
    float c;
    //c=atof(a)+atof(b); //not compliant
    //printf("c=%.2f\n",c);
}
减少atof等函数的使用。
```

### MISRA_C_2012_21_08_rule　禁止使用abort、exit、getenv 和 system 等函数。
> 等级：**强制**　分类：标准库

禁止使用abort、exit、getenv 和 system 等函数。

**示例1：不规范用法**

```c
#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    char *s;
    abort(); //not compliant
    exit( EXIT_SUCCESS ); //not compliant
}
```

**示例1：规范用法之一**

```c
#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    return 0;
}
去掉[abort]、[exit]函数，使用return语句退出函数。
```

### MISRA_C_2012_21_09_rule　禁止使用<stdlib.h>中库函数bsearch和qsort
> 等级：**强制**　分类：标准库

禁止使用<stdlib.h>中库函数bsearch和qsort。

**示例1：不规范用法**

```c
/*
 *20_标准库
 *禁止使用<stalib.h>中库函数bsearch和qsort
*/

#include <stdio.h>
#include <stdlib.h>
#define NUM 8
int compare(const void *p, const void *q)
{
  return (*(int *)p - *(int *)q);
}
int main(int argc, char *argv[])
{
  int array[NUM] = {9, 2, 7, 11, 3, 87, 34, 6};
  int key = 3;
  int *p;
  qsort(array, NUM, sizeof(int), compare); //not
  p = (int *)bsearch(&key, array, NUM, sizeof(int), compare); //not
  (p == NULL) ? puts("not found") : puts("found");
  return 0;
}
```

**示例1：规范用法之一**

```c
可以选择用功能相同的其他排序方法替代快速排序qsort。
```

### MISRA_C_2012_21_10_rule　标准库中的时间和日期函数禁止被使用
> 等级：**强制**　分类：标准库

标准库中的时间和日期函数禁止被使用。

**示例1：不规范用法**

```c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main( void )
{
    long i = 10000000L;
    clock_t start, finish;
    double duration;
    /* 测量一个事件持续的时间*/
    printf( "Time to do %ld empty loops is ", i );
    start = clock(); // not
    while( i-- ) ;
    finish = clock(); // not
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    printf( "%f seconds\n", duration );
    system("pause");
    return 0;
}
```

### MISRA_C_2012_21_11_rule　禁用头文件tgmath.h
> 等级：**强制**　分类：标准库

禁用头文件tgmath.h

**示例1：不规范用法**

```c
#include <tgmath.h>

float f1,f2;
void f(void)
{
	f1=sqrt(f2); //not
}
```

**示例1：规范用法之一**

```c
#include <math.h>

float f1,f2;
void f(void)
{
	f1=sqrtf(f2); //not
}
用<math.h>替换<tgmath.h>。
```

### MISRA_C_2012_21_12_rule　不应该使用<fenv.h>的异常处理功能
> 等级：**强制**　分类：标准库

不应该使用<fenv.h>的异常处理功能。

**示例1：不规范用法**

```c
#include <fenv.h>

void f(float32_t x,float32_t y)
{
	float32_t z;
    feclearexcept(FE_DIVBYZERO); //
}
```

**示例1：规范用法之一**

```c
//#include <fenv.h>

void f(float32_t x,float32_t y)
{
	float32_t z;
   // feclearexcept(FE_DIVBYZERO); //
}
减少对<fenv.h>库及其相关函数的使用。
```

---

## 第 22 章 资源（6 条）

### MISRA_C_2012_22_01_rule　所有通过标准库动态分配的资源应该被显示的释放
> 等级：**强制**　分类：资源

所有通过标准库函数动态获取的资源都应被显式释放。
标准库中分配资源的函数包括 malloc、calloc、realloc 和 fopen。若资源未被显式释放，则可能因资源耗尽而发生故障。尽早释放资源可降低耗尽的可能。

**示例1：不规范用法**

```c
#include <stdlib.h>
#include <stdio.h>
int misra2012_22_1_01 ( void )
{
    void *b = malloc ( 40 );
    /* Non-compliant - dynamic memory not released */
    return 1;
}
int misra2012_22_1_02 ( void )
{
    FILE *fp = fopen ( "tmp", "r" );
    /* Non-compliant - file not closed */
    return 1;
}
int misra2012_22_1_03 ( void )
{
    FILE *fp;
    fp = fopen ( "tmp-1", "w" );
    fprintf ( fp, "*" );
    /* File "tmp-1" should be closed here, but stream 'leaks'. */
    fp = fopen ( "tmp-2", "w" );
    fprintf ( fp, "!" );
    fclose ( fp );
    return ( 0 );
}
```

**示例1：规范用法之一**

```c
#include <stdlib.h>
#include <stdio.h>
int good_misra2012_22_1_01 ( void )
{
    void *b = malloc ( 40 );
    free(b);
    return 1;
}
int good_misra2012_22_1_02 ( void )
{
    FILE *fp = fopen ( "tmp", "r" );
    fclose(fp);
    return 1;
}
int good_misra2012_22_1_03 ( void )
{
    FILE *fp;
    fp = fopen ( "tmp-1", "w" );
    fprintf ( fp, "*" );
    fclose ( fp );
    fp = fopen ( "tmp-2", "w" );
    fprintf ( fp, "!" );
    fclose ( fp );
    return ( 0 );
}
```

### MISRA_C_2012_22_02_rule　只能释放通过标准库动态分配的资源内存
> 等级：**强制**　分类：资源

只有通过标准库函数分配的内存块才可被释放。
释放非已分配的内存，或对同一块已分配内存重复释放，都会导致未定义行为。

**示例1：不规范用法**

```c
#include <stdlib.h>
int main()
{
    char* a=malloc(sizeof(a));
    free(a); //释放内存地址
    free(a); //因为之前已经释放过了，所以这行代码属于重复释放
}
```

**示例1：规范用法之一**

```c
#include <stdlib.h>
int main()
{
    char* a=malloc(sizeof(a));
    free(a); //释放内存地址

}
去掉第二次释放。
```

### MISRA_C_2012_22_03_rule　不得在不同的数据流上同时打开同一文件以进行读写访问
> 等级：**强制**　分类：资源

不得在不同的数据流上同时打开同一文件以进行读写访问。

**示例1：不规范用法**

```c
#include <stdio.h>
void fn(void)
{
    FILE *fw = fopen("tmp", "r+"); /* "r+" 以读/写打开 */
    FILE *fr = fopen("tmp", "r"); /* 违规 */
}
```

**示例1：规范用法之一**

```c
#include <stdio.h>
void fn(void)
{
    FILE *fw = fopen("tmp", "r+"); /* "r+" 以读/写打开 */
    fclose(fw);
    FILE *fr = fopen("tmp", "r"); /* 合法 */
}
```

### MISRA_C_2012_22_04_rule　禁止尝试对以只读方式打开的流执行写操作
> 等级：**强制**　分类：资源

禁止尝试对以只读方式打开的流执行写操作。

**示例1：不规范用法**

```c
#include <stdio.h>
void fn(void)
{
    FILE *fp = fopen("tmp", "r");
    (void)fprintf(fp, "What happens now?"); /* 违规 */
    (void)fclose(fp);
}
```

**示例1：规范用法之一**

```c
#include <stdio.h>
void fn(void)
{
    FILE *fp = fopen("tmp", "r+"); /* 以 读/写 打开文件 */
    (void)fprintf(fp, "What happens now?"); /* 合法 */
    (void)fclose(fp);
}
```

### MISRA_C_2012_22_05_rule　禁止解引用指向FILE 对象的指针
> 等级：**强制**　分类：资源

禁止解引用指向FILE 对象的指针。

**示例1：不规范用法**

```c
#include <stdio.h>
FILE *pf1;
FILE *pf2;
FILE f3;
f3 = *pf2; /* 违规 */
```

**示例1：规范用法之一**

```c
#include <stdio.h>
FILE *pf1;
FILE *pf2;
FILE f3;
pf2 = pf1; /* 合规 */
```

### MISRA_C_2012_22_06_rule　关联的流关闭后，禁止再使用FILE 的指针值
> 等级：**强制**　分类：资源

关联的流关闭后，禁止再使用FILE 的指针值。

**示例1：不规范用法**

```c
void fn(void)
{
    FILE *fp;
    void *p;
    fp = fopen("tm p", "w");
    if(fp == NULL)
    {
        error_action();
    }
    fclose(fp);
    fprintf(fp, "?"); /* 违规 */
    p = fp; /* 违规 */
}
```

**示例1：规范用法之一**

```c
void fn(void)
{
    FILE *fp;
    void *p;
    fp = fopen("tm p", "w");
    if(fp == NULL)
    {
        error_action();
    }
    fprintf(fp, "?"); /* 合规 */
    p = fp; /* 合规 */
}
```

---

## 指令（Directives）（16 条）

### MISRA_C_2012_Dir_01_01_rule　程序所依赖的任何实现定义行为都应被记录并理解
> 等级：**强制**　分类：环境

实现定义行为是指编译器可以选择如何实现、但必须在文档中说明的方面。若程序输出依赖某一实现定义行为，而该行为未被记录，则代码在不同编译器或不同版本上的行为就无法预期。因此必须识别出所有此类行为，记录其在本项目中的具体表现，并确保开发与维护人员理解这些假设。

> 原文未给出该条的代码示例。

### MISRA_C_2012_Dir_02_01_rule　所有源文件都应编译，不得有任何编译错误
> 等级：**强制**　分类：环境

编译错误意味着代码不满足语言标准的语法或约束要求，此时程序的行为完全不可预期，严格来说已不是一个合法的 C 程序。凡纳入项目的源文件都必须能通过编译，不能以"该文件不参与构建"为由保留无法编译的代码。

> 原文未给出该条的代码示例。

### MISRA_C_2012_Dir_03_01_rule　所有代码应可追溯到已文档化的需求
> 等级：**强制**　分类：环境

代码若无法追溯到任何需求，就无法判断其是否必要、是否正确，也无法在需求变更时评估影响范围，属于不可维护的冗余或遗漏需求。项目应建立需求与代码之间的双向追溯关系，并能通过评审或工具予以验证。

> 原文未给出该条的代码示例。

### MISRA_C_2012_Dir_04_01_rule　应将运行时故障减到最少
> 等级：**强制**　分类：环境

C 语言内建的运行时检查非常有限，这使得生成的代码紧凑高效，但也把运行时检查的责任转移给了程序员。为达到所要求的健壮性水平，凡有可能发生运行时错误之处，都应审慎地增加动态检查。若能够证明操作数的取值范围排除了出错的可能，则可不加动态检查，但必须记录支撑该结论的假设，以便后续修改代码时该结论仍然有效。常用的技术包括静态分析、动态分析以及显式编码检查。

**示例1：规范用法之一**

```c
static int32_t scale(int32_t v)
{
    /* 若不能证明 v 的取值范围，则应显式检查 */
    if ((v < 0) || (v > 1000))
    {
        return 0;
    }
    return v * 10;
}
```

### MISRA_C_2012_Dir_04_02_rule　所有汇编语言的使用都应被记录
> 等级：**推荐**　分类：环境

汇编语言代码依赖于具体的处理器与工具链，既不可移植，也难以被静态分析工具完整理解。因此凡使用汇编之处都必须记录其用途、依赖的硬件特性以及可移植性上的限制，以便后续移植与评审时评估影响。

> 原文未给出该条的代码示例。

### MISRA_C_2012_Dir_04_03_rule　汇编语言应被封装并隔离
> 等级：**强制**　分类：环境

将汇编代码集中封装在少量明确定义的接口之后，可以把与硬件相关的不可移植部分限制在可控范围内，避免其分散到业务逻辑中。这样既能降低评审与移植成本，也便于对汇编部分做针对性验证。

**示例1：规范用法之一**

```c
/* asm_port.h */
void port_disable_interrupts(void);

/* asm_port.c - 唯一允许出现内联汇编的文件 */
void port_disable_interrupts(void)
{
    __asm(" di ");
}

/* 业务代码只调用接口，不直接写汇编 */
void critical_task(void)
{
    port_disable_interrupts();
    /* ... */
}
```

### MISRA_C_2012_Dir_04_04_rule　代码段不应被“注释掉”
> 等级：**推荐**　分类：注释

代码段不应被"注释掉"。（Dir 4.4，Advisory）。

用注释符屏蔽代码是一种危险的做法：C 风格注释不支持嵌套，若被注释的代码本身含有注释，会导致注释范围被意外截断，从而改变程序语义。此外被注释的代码会迅速过期，误导后续维护者。若确实需要保留旧实现，应使用版本控制系统，而不是注释。

> 原文未给出该条的代码示例。

### MISRA_C_2012_Dir_04_05_rule　同一命名空间中可见性重叠的标识符在排版上应无歧义
> 等级：**推荐**　分类：标识符

在所用字体下看似相同的字符可能实际不同（如字母 O 与数字 0、字母 I 与数字 1 或字母 l、字母 S 与数字 5、字母 Z 与数字 2）。若两个标识符仅靠这些易混淆字符区分，阅读者极易看错，进而误用。标识符之间不应仅在这些方面存在差异。

> 原文未给出该条的代码示例。

### MISRA_C_2012_Dir_04_06_rule　应使用指示大小和符号的 typedef 代替基本数值类型
> 等级：**推荐**　分类：类型

基本数值类型（char、short、int、long 等）在不同平台上的宽度和符号性并不一致，直接使用会使代码的存储占用与取值范围随实现而变。改用明确表示宽度与符号性的 typedef（如 int32_t、uint16_t），可以在代码中直接体现设计意图，便于评审时发现溢出与截断风险。

> 原文未给出该条的代码示例。

### MISRA_C_2012_Dir_04_07_rule　如果函数返回错误信息，则该错误信息应被测试
> 等级：**强制**　分类：环境

函数通过返回值、全局错误标志或输出参数等方式报告错误时，调用方若不检查该信息，错误就会被静默忽略，程序可能带着已损坏的状态继续运行。凡提供了错误报告机制的调用，都应在函数返回后尽快检查，并采取相应处置。

**示例1：规范用法之一**

```c
int32_t rc = do_something();
if (rc != 0)
{
    return rc; /* 必须检查并处理错误信息 */
}
```

### MISRA_C_2012_Dir_04_08_rule　如果指向结构体或联合体的指针在翻译单元内从未被解引用，则该对象的实现应被隐藏
> 等级：**推荐**　分类：声明与定义

若某结构体或联合体仅在翻译单元内以指针形式传递而从不被解引用，说明该翻译单元并不依赖其内部布局。此时把其定义隐藏起来（例如只在实现文件中定义），可以降低编译依赖、加快构建，并防止其他代码误用其内部成员。

> 原文未给出该条的代码示例。

### MISRA_C_2012_Dir_04_09_rule　在功能可互换的情况下，应优先使用函数而不是类函数宏
> 等级：**推荐**　分类：预处理命令

类函数宏在预处理阶段做文本替换，不进行类型检查，参数可能被多次求值，也容易因缺少括号而产生优先级错误。若用函数或内联函数即可实现相同功能，则应优先采用，以获得参数类型检查与单次求值的保障。

**示例1：规范用法之一**

```c
/* 不推荐 */
#define SQUARE(x) ((x) * (x))

/* 推荐 */
static inline int32_t square(int32_t x)
{
    return x * x;
}
```

### MISRA_C_2012_Dir_04_10_rule　应采取预防措施以防止头文件的内容被多次包含
> 等级：**强制**　分类：预处理命令

当翻译单元中存在复杂的嵌套包含层次时，同一头文件可能被包含多次，轻则造成混乱，重则导致重复定义或相互冲突的定义，从而产生未定义或错误的行为。应采用包含保护（#ifndef/#define/#endif 或 #pragma once）确保头文件内容只被展开一次。

**示例1：规范用法之一**

```c
/* file.h */
#ifndef FILE_H
#define FILE_H

/* 头文件内容 */

#endif /* FILE_H */
```

### MISRA_C_2012_Dir_04_11_rule　传递给库函数的值的有效性应被检查
> 等级：**强制**　分类：标准库

标准库函数对参数的合法范围有明确要求，越界参数会导致未定义行为。例如传给某些函数的长度、索引、字符值等若超出允许范围，运行时可能直接崩溃或产生不可预期结果。凡可能超出合法范围的实参，都应在调用前检查。

**示例1：规范用法之一**

```c
int32_t idx = get_index();
/* C 标准规定 tolower 的实参必须是 EOF 或可表示为 unsigned char 的值 */
if ((idx < 0) || (idx > 255))
{
    idx = 0;
}
char c = (char)tolower(idx);
```

### MISRA_C_2012_Dir_04_12_rule　不得使用动态内存分配
> 等级：**强制**　分类：资源

标准库的动态内存分配与释放函数可能导致未定义行为（参见规则 21.3）；其他动态内存分配机制往往也存在类似的未定义行为。嵌入式系统通常缺乏可靠的内存耗尽处理手段，一旦分配失败便难以安全恢复。若确需使用动态内存，必须确保软件在分配失败等情况下行为可预期。

**示例1：规范用法之一**

```c
/* 使用静态分配代替 malloc */
static uint8_t buffer[256];

void use_buffer(void)
{
    /* 直接使用静态缓冲区，避免动态分配 */
    buffer[0] = 0u;
}
```

### MISRA_C_2012_Dir_04_13_rule　对资源提供操作的一组函数应按适当的顺序调用
> 等级：**推荐**　分类：资源

针对某类资源（如文件、锁、外设）的一组操作通常包含获取、使用与释放三个环节。若调用顺序不当（例如未释放即再次获取、释放后继续使用），会造成资源泄漏或未定义行为。静态分析工具可通过路径分析发现此类问题，因此建议把成对的获取/释放函数以清晰的方式声明，便于工具检查。

> 原文未给出该条的代码示例。

---
