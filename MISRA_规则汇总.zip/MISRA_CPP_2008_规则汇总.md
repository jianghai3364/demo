# MISRA C++:2008 全部规则汇总

来源：`/data2/lgf/MISRA/MISRA_CPP_2008.pdf`　｜　生成自 ValiantSec 规则库（xls 元数据 + desc 规则详情）

共 **228** 条规则。等级分布：强制 195 条、推荐 21 条、文档 12 条。

---

> **阅读约定**
> 
> - 等级：**强制**（Required/Mandatory）、**推荐**（Advisory）、**文档**（Document，指需以文档形式满足的要求）
> - 「例外」条款直接决定规则是否适用于当前代码，务必先读例外再看规则
> - 标注「原文未给出该类型的独立示例」的条目，表示标准原文仅有另一类示例或仅有文字说明，未作补充创作
> - 小节标题为「原文示例（合规与不合规写法混排）」时，表示标准原文把两类写法放在同一段代码里，`// Compliant` 标记合规写法、`// Non-compliant` 标记不合规写法，本汇总未擅自拆分

---

## 目录

- [第 0 章 语言无关问题](#第-0-章-语言无关问题18-条)　（18 条）
- [第 1 章 通用（语言）](#第-1-章-通用语言3-条)　（3 条）
- [第 2 章 词法约定](#第-2-章-词法约定17-条)　（17 条）
- [第 3 章 基本概念](#第-3-章-基本概念13-条)　（13 条）
- [第 4 章 标准转换](#第-4-章-标准转换5-条)　（5 条）
- [第 5 章 表达式](#第-5-章-表达式42-条)　（42 条）
- [第 6 章 语句](#第-6-章-语句23-条)　（23 条）
- [第 7 章 声明](#第-7-章-声明16-条)　（16 条）
- [第 8 章 声明符](#第-8-章-声明符9-条)　（9 条）
- [第 9 章 类](#第-9-章-类8-条)　（8 条）
- [第 10 章 派生类](#第-10-章-派生类7-条)　（7 条）
- [第 11 章 成员访问控制](#第-11-章-成员访问控制1-条)　（1 条）
- [第 12 章 特殊的成员函数](#第-12-章-特殊的成员函数5-条)　（5 条）
- [第 14 章 模板](#第-14-章-模板10-条)　（10 条）
- [第 15 章 异常处理](#第-15-章-异常处理17-条)　（17 条）
- [第 16 章 预处理指令](#第-16-章-预处理指令19-条)　（19 条）
- [第 17 章 库介绍](#第-17-章-库介绍5-条)　（5 条）
- [第 18 章 语言支持库](#第-18-章-语言支持库8-条)　（8 条）
- [第 19 章 诊断库](#第-19-章-诊断库1-条)　（1 条）
- [第 27 章 输入输出库](#第-27-章-输入输出库1-条)　（1 条）

---

## 第 0 章 语言无关问题（18 条）

### MISRA_CPP_2008_00_01_01_rule　项目中不能包含不可达的代码
> 等级：**强制**　分类：未使用的代码

如果没有语法（控制流）路径到达代码，则该代码是不可达的。编译器可能选择不为这些结构生成代码，这意味着即使不可达代码是有意的，它也可能不存在于最终可执行代码中。由编辑活动引起的语句缺失的通常是无法到达代码的常见来源。

**示例1：不规范用法**

```cpp
int16_t with_unreach(int16_t para)
{
    int16_t local;
    local = 0;
    switch (para)
    {
        local = para; // 不可达 – Non-compliant
    case 1:
    {
        break;
    }
    default:
    {
        break;
    }
    }
    return para;
    para++; // 不可达 – Non-compliant
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_00_01_02_rule　项目中不能包含不被执行的路径
> 等级：**强制**　分类：未使用的代码

不可行路径发生在语法路径存在但语义确保任何输入数据无法执行控制流路径的情况下。这里面遇到的主要问题是由以下因素引起的：
• if … else 语句序列；
• 错误的循环结构序列；
这类错误通常由条件错误和逻辑设计不当导致，可以经过重写代码来消除这些结构。

**示例1：不规范用法**

```cpp
#define defval 0

void static_p(void)
{
    if (0)
    {
        /*...*/
    }
    if (defval)
    {
        /*...*/
    }
}
```

**示例1：规范用法之一**

```cpp
//#define defval 0

void static_p(int x)
{

    if (x)
    {
        /*...*/
    }
    else
   {
        /*...*/
   }
}
```

### MISRA_CPP_2008_00_01_03_rule　项目中不能包含未使用变量
> 等级：**强制**　分类：未使用的代码

在项目中声明但从未使用的变量构成噪音，可能表明在某个地方使用了错误的变量名，删除这些声明可以减少它们后来可能被错误地使用的可能性。

**示例1：不规范用法**

```cpp
class A {
	public:
 void displBalance();
};
void foo( ) {
	A a; // 违规
}
int func(int j) {
	int i = 0; // 违规
	return j;
}
```

**示例1：规范用法之一**

```cpp
class A {
	public:
      void displBalance(){};
};
void foo( ) {
	A a;
   a.displBalance();
}
int func(int j) {
	int i = 0;
   j = i;
	return j;
}
```

### MISRA_CPP_2008_00_01_04_rule　项目中不能包含只使用一次的非易失性POD变量。
> 等级：**强制**　分类：未使用的代码

除了易变变量（volatile variables）外，避免使用仅声明并使用一次的变量，使用可以是赋值（显式初始化）或引用，它们的存在可能表明其他地方使用了错误的变量。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
const int16_t x = 19; // Compliant
const int16_t y = 21; // Non-compliant
void usedonlyonce(void)
{
    int16_t once_1 = 42; // Non-compliant
    int16_t once_2;
    once_2 = x; // Non-compliant
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_00_01_05_rule　项目中不能包含未被使用的类型声明
> 等级：**强制**　分类：未使用的代码

如果一个类型被声明但从未被使用过，对于审阅者来说，无法确定该声明是多余的还是被错误闲置的。

**示例1：不规范用法**

```cpp
#include<iostream>
#include<stdio.h>
using namespace std;
typedef char int_16; //全局暂不考虑
int unusedtype()
{
    typedef int local_Type; // Non-compliant
    typedef float _float;
    _float f = 1.0f;
    return 67;
}
int main()
{
    typedef double _dou; // Non-compliant
    typedef long _long;
    _long a = 1;
    return 0;
}
```

### MISRA_CPP_2008_00_01_06_rule　项目不能包含未被后续使用的非易失变量实例赋值
> 等级：**强制**　分类：未使用的代码

也称为DU数据流异常（DU dataflow anomaly），即过程中一个变量被赋予一个后续从未使用的值。这充其量是低效的，但也可能指示真正的问题。这类结构的存在往往是由于语句聚合的错误选择，例如循环。
例外：循环控制变量（见 6.6.5 节）不受本规则约束。

**示例1：不规范用法**

```cpp
int16_t critical(int16_t i, int16_t j)
{
    int16_t result = 0;
    int16_t k = (3 * i) + (j * j);
    // Should k be checked here?
    if (f2())
    {
        // k will only be tested here if f2 returns true
        // Initialization of k could be moved here
        if (k > 0)
        {
            throw(42);
        }
    }
    // Non-compliant – value of k not used if f2 ( ) returns false
    return (result);
}
void unusedvalue(int16_t arr[20])
{
    int16_t j;
    j = 2;
    for (int16_t i = 1; i < 10; i++)
    {
        arr[i] = arr[j];
        j++; // Non-compliant – the value assigned to j
    } // on the final loop is never used.
}
```

**示例1：规范用法之一**

```cpp
void nounusedvalue(int16_t arr[20])
{
    for (int16_t i = 1; i < 10; i++)
    {
        arr[i] = arr[i + 2];
    }
}
```

### MISRA_CPP_2008_00_01_07_rule　从不是重载运算符函数得到的非 void 类型的返回值应该始终被使用
> 等级：**强制**　分类：未使用的代码

调用一个函数而不使用返回值，这可能是一个错误，函数的返回值应该总是被使用，重载运算符除外。

例外：函数的返回值可通过 (void) 强制转换丢弃。

**示例1：不规范用法**

```cpp
int func(int para)
{
    int stat;
    if(para>=0)
    {
       //…
       stat=1;
    }
    else
    {
       //…
       stat=-1;
    }
    return(stat);
}
int main(void)
{
    int local=0;
    //…
    func(local); //违背1
    //…
    return(0);
}
```

**示例1：规范用法之一**

```cpp
int func(int para)
{
    int stat;
    if(para>=0)
    {
       //…
       stat=1;
    }
    else
    {
       //…
       stat=-1;
    }
    return(stat);
}
int main(void)
{
    int local=0;
    //…
    (void)func(local);
    //…
    return(0);
}
第[1]行定义了[int]类型的函数[func]，第[20]行调用函数时，其返回值不被使用，用void进行说明。
```

### MISRA_CPP_2008_00_01_08_rule　所有返回类型为void的函数都应该有其它作用
> 等级：**强制**　分类：未使用的代码

调用一个没有返回值且不具备其它作用的函数只会消耗时间，而不会产生任何输出，这可能不符合开发人员的期望。以下是外部副作用的例子：
 •读取或写入文件、流等；
 •更改非局部变量的值；
 •更改具有引用类型的参数的值；
 •使用易失对象；
 •引发异常。

**示例1：不规范用法**

```cpp
void pointless(void) // Non-compliant – no external side effects
{
    int16_t local;
    local = 0;
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_00_01_09_rule　项目中不得有无效代码(dead code)
> 等级：**强制**　分类：未使用的代码

任何被删除后不影响程序输出的语句构成死代码（也称为冗余代码）。 对于审查人员来说，很难确定这是故意的还是由于错误而导致的。

**示例1：不规范用法**

```cpp
int16_t has_dead_code(int16_t para)
{
    int16_t local = 99;
    para = para + local;
    local = para; // dead code – Non-compliant
    if (0 == local) // dead code – Non-compliant
    { // dead code – Non-compliant
        local++; // dead code – Non-compliant
    } // dead code – Non-compliant
    return para;
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_00_01_10_rule　每个已定义的函数必须至少被调用一次
> 等级：**强制**　分类：未使用的代码

未被调用的函数或过程可能是严重的问题，例如缺失路径。 请注意，未使用的函数声明不违反此规则

**示例1：原文示例（合规与不合规写法混排）**

```cpp
void f1()
{
}
void f2() // Non-compliant
{
}
void f3(); // Compliant prototype
int32_t main()
{
    f1();
    return (0);
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_00_01_11_rule　非虚函数中不得存在未使用的参数（命名或未命名）
> 等级：**强制**　分类：未使用的代码

未使用的函数参数通常是由于设计更改导致的，可能会导致参数列表不匹配。
例外：在用作回调的函数定义中，未命名的参数不违反此规则。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
typedef int16_t (*CallbackFn)(int16_t a, int16_t b);
int16_t Callback_1(int16_t a, int16_t b) // Compliant
{
    return a + b;
}
int16_t Callback_2(int16_t a, int16_t b) // Non-compliant
{
    return a;
}
int16_t Callback_3(int16_t, int16_t b) // Compliant by exception
{
    return b;
}
void Dispatch(int16_t n,
              int16_t a,
              int16_t b,
              int16_t c, // Non-compliant
              int16_t) // Non-compliant if Dispatch not a callback.
{
    CallbackFn pFn;
    switch (n)
    {
    case 0:
        pFn = &Callback_1;
        break;
    case 1:
        pFn = &Callback_2;
        break;
    default:
        pFn = &Callback_3;
        break;
    }
    (*pFn)(a, b);
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_00_01_12_rule　虚函数及其所有覆盖函数的参数集中均不得存在未使用的参数（命名或未命名）
> 等级：**强制**　分类：未使用的代码

未使用的函数参数通常是由于设计更改导致的，可能会导致参数列表不匹配。

**示例1：不规范用法**

```cpp
class A
{
public:
    virtual void withunusedpara(uint16_t *para1,
                                int16_t unusedpara) = 0;
    virtual void withoutunusedpara(uint16_t *para1,
                                   int16_t &para2) = 0;
};
class B1 : public A
{
public:
    virtual void withunusedpara(uint16_t *para1,
                                int16_t unusedpara)
    {
        *para1 = 1U;
    }
    virtual void withoutunusedpara(uint16_t *para1,
                                   int16_t &para2)
    {
        *para1 = 1U;
    }
};
class B2 : public A
{
public:
    virtual void withunusedpara(uint16_t *para1,
                                int16_t unusedpara)
    {
        *para1 = 1U;
    }
    virtual void withoutunusedpara(uint16_t *para1,
                                   int16_t &para2)
    {
        para2 = 0;
    }
};
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_00_02_01_rule　对象不能赋值给重叠（overlapping）对象
> 等级：**强制**　分类：重叠存储

当创建两个对象在内存中有一些重叠并且一个对象被赋值或复制给另一个对象时，该行为是不确定的。

**示例1：不规范用法**

```cpp
struct s
{
    int16_t m1[32];
};
struct t
{
    int32_t m2;
    struct s m3;
};
void fn()
{
    union // Breaks Rule 9–5–1
    {
        struct s u1;
        struct t u2;
    } a;
    a.u2.m3 = a.u1; // Non-compliant
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_00_03_01_rule　使用至少一项以下技术预防运行时故障： (a) 静态分析工具/技术; (b) 动态分析工具/技术; (c) 显式编码检查以处理运行时故障。
> 等级：**文档**　分类：运行时错误

开发人员需要特别注意实时检查， 例如在有可能发生错误的代码中添加动态检查，记录不会发生异常所依赖的假设，并持续关注假设变化下的后续代码修改。以下是需要考虑添加动态检查的地方：
 • 算术错误： 表达式求值中发生的错误，例如溢出、下溢、除以零或位移丢失重要位。
 • 指针算术： 动态计算的指针地址合理且指向某个有意义的地方，如指向结构或数组内部。
 • 数组越界错误： 在使用数组索引之前，请确保数组索引在数组大小范围内。
 • 函数参数： 应对函数参数进行验证。
 • 指针解引用：对外部指针解引用应首先检查该指针是否为NULL。

**示例1：不规范用法**

> 原文未给出该类型的独立示例。

**示例1：规范用法之一**

```cpp
// Given a pointer to a message, check the message header and return
// a pointer to the body of the message or NULL if the message is
// invalid.
const char_t *msg_body(const char_t *msg)
{
    const char_t *body = NULL;
    if (msg != NULL)
    {
        if (msg_header_valid(msg))
        {
            body = &msg[MSG_HEADER_SIZE];
        }
    }
    return (body);
}
... char_t msg_buffer[MAX_MSG_SIZE];
const char_t *payload;
... payload = msg_body(msg_buffer);
if (payload != NULL)
{
    // process the message payload
}
```

### MISRA_CPP_2008_00_03_02_rule　需要对函数执行可能产生的错误信息进行测试和处理
> 等级：**强制**　分类：运行时错误

函数(标准库，第三方库或者用户定义的函数)通常提供一些标识错误发生的检查方法， 例如全局错误标志、参数化错误标志、特殊返回值等。当函数提供这样的机制时，调用程序应在函数返回后立即检查是否存在错误指示。
但请注意，函数的输入值检查是比尝试在函数完成后检测更可靠的错误预防手段。

**示例1：不规范用法**

```cpp
extern void fn3(int32_t i, bool &flag);
int32_t fn1(int32_t i)
{
    int32_t result = 0;
    bool success = false;
    fn3(i, success); // Non-compliant - success not checked
    return result;
}
```

**示例1：规范用法之一**

```cpp
int32_t fn2(int32_t i)
{
    int32_t result = 0;
    bool success = false;
    fn3(i, success); // Compliant - success checked
    if (!success)
    {
        throw 42;
    }
    return result;
}
```

### MISRA_CPP_2008_00_04_01_rule　使用缩放整数或定点浮点运算的应进行文档记录
> 等级：**文档**　分类：算术

在不忽略危险情况的情况下，设计和实现缩放整数或不动点算法的算术包是极其困难的，此规则要求生成文档，以证明实现已覆盖所有问题。

> 原文未给出该条的代码示例。

### MISRA_CPP_2008_00_04_02_rule　使用定点浮点算术的应进行文档记录
> 等级：**文档**　分类：算术

如果要使用定点浮点算术运算，则以下问题需要注意：
 • 解释为什么定点浮点是适当或唯一的解决方案
 • 证明所需的技能可用
 • 证明正在应用适当的处理过程
 • 文档化浮点实现

**示例1：不规范用法**

> 原文未给出该类型的独立示例。

**示例1：规范用法之一**

```cpp
示例：解一元二次方程时需计算 b²-4·a·c。设 a=1.22、b=3.34、c=2.28，计算过程中保留三位有效数字。b²-4·a·c 的精确值为 0.0292，但 b² 被舍入为 11.2、4·a·c 被舍入为 11.1，最终结果为 0.1。该示例演示了灾难性抵消（catastrophic cancellation）：减法本身并不产生误差，但它暴露了在生成其操作数的乘法中已引入的误差。
```

### MISRA_CPP_2008_00_04_03_rule　浮点实现应符合定义的浮点标准
> 等级：**文档**　分类：算术

使用符合公认标准的浮点算法实现，可以克服浮点算法中一些问题。

> 原文未给出该条的代码示例。

---

## 第 1 章 通用（语言）（3 条）

### MISRA_CPP_2008_01_00_01_rule　所有代码应符合ISO/IEC 14882:2003“C++标准
> 等级：**强制**　分类：通用语言

MISRA C ++子集基于ISO/IEC 14882:2003， 本文件中对“C++”的任何引用均指ISO/IEC 14882:2003 标准。

> 原文未给出该条的代码示例。

### MISRA_CPP_2008_01_00_02_rule　当且仅当具有公共，预定义的接口时，才可以使用多个编译器
> 等级：**文档**　分类：通用语言

“编译器”包括用于翻译源代码或链接目标代码的任何工具，“多编译器”包括：
• 混合语言;
• 不同编译器;
• 同一编译器的不同版本;
• 同一编译器的不同配置;

> 原文未给出该条的代码示例。

### MISRA_CPP_2008_01_00_03_rule　应确定和记录所选择编译器中整数除法的实现
> 等级：**文档**　分类：通用语言

当两个有符号整数相除时，ISO兼容的编译器可以执行以下两种操作之一：首先，它可能舍入并保留负余数（例如，-5/3 = -1余数-2），否则，它可能向下舍入并保留正余数（例如，-5/3 = -2余数+ 1）。
重要的是确定编译器实现的哪个，并为开发人员记录它。
请注意，此规则也涵盖模数，因为它是基于除法定义的。

> 原文未给出该条的代码示例。

---

## 第 2 章 词法约定（17 条）

### MISRA_CPP_2008_02_02_01_rule　应记录字符集及其相应的编码
> 等级：**文档**　分类：通用语言

程序可以在多个字符集中执行时应妥善记录使用的所有字符集。
记录所使用的字符集可以提高开发人员的意识，避免由于使用不兼容的字符集而引起的问题。

> 原文未给出该条的代码示例。

### MISRA_CPP_2008_02_03_01_rule　不得使用三元字符
> 等级：**强制**　分类：词法信息

三字符组由两个问号后跟指定的第三个字符表示（例如，??-表示“〜”（波形）字符，??）表示“ ]”）。
它们可能与其他两个问号的用法产生混淆。

**示例1：不规范用法**

```cpp
??=define TEST 1 /* Violation */
void foo() {
const char * s = "(Date should be in the form ??-??-??)"; /* Violation */
}
```

**示例1：规范用法之一**

```cpp
#define TEST 1
void foo() {
    const char * s = "(Date should be in the form ~-~-~)";
}
```

### MISRA_CPP_2008_02_05_01_rule　不应使用二元组（Digraphs）
> 等级：**推荐**　分类：通用语言

二元组（Digraphs）指的是： <% %> <: :> %: %:%:
使用二元组可能与开发人员的期望不符。

**示例1：不规范用法**

```cpp
template <typename T>
class A
{
public:
    template <int32_t i>
    void f2();
};

void f1(A<int32_t> *a<:10:>) // 违规：使用 <: :> 表示 []
{
    <% a<:0:>->f2<20>(); %> // 违规：使用 <% %> 表示 { }
}
```

**示例1：规范用法之一**

```cpp
template <typename T>
class A
{
public:
    template <int32_t i>
    void f2();
};

void f1(A<int32_t> *a[10]) // 合规：直接使用 [ ]
{
    a[0]->f2<20>(); // 合规：直接使用 { }
}
```

### MISRA_CPP_2008_02_07_01_rule　字符序列 /* 不得被用于 C 语言风格的注释中
> 等级：**强制**　分类：词法信息

C++不支持C风格的嵌套注释。
注释以/*开头并将一直持续到遇到第一个*/，任何存在于注释中的“/*”都违反了此规则。

**示例1：不规范用法**

```cpp
/* some comment, end comment marker accidentally omitted
Perform_Critical_Safety_Function(X);
/* this "comment" is Non-compliant */
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_02_07_02_rule　代码部分不得使用 C 语言风格的注释 "注释掉"
> 等级：**强制**　分类：词法信息

C风格的注释不支持嵌套，此操作是危险的，该代码段中已经存在的注释可能会更改其效果，应仅使用注释来解释源代码本身不清楚的方面。

**示例1：不规范用法**

```cpp
void fn(int32_t i)
{
    /*
    ++i; /* We want to increment "i" */
    * /
        for (int32_t j = 0; j != i; ++j)
    {
    }
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_02_07_03_rule　不应使用C ++注释将代码段“注释掉”
> 等级：**推荐**　分类：通用语言

应仅使用注释来解释源代码本身不清楚的方面，注释掉的代码可能会变得过时，这可能会在维护代码时导致混乱。

**示例1：不规范用法**

```cpp
void fn(int32_t i)
{
    // ++i; // We want to increment
    for (int32_t j = 0; j != i; ++j)
    {
    }
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_02_10_01_rule　不同的标识符应在排版上无歧义
> 等级：**强制**　分类：词法信息

根据用于排版的字体，某些显示相近的字符容易引起开发人员将某些标识符与其他标识符混淆，例如：
 • 仅大小写混合；
 • 下划线字符存在或不存在；
 • 字母“O”和数字“0”的调换；
 • 字母“I”和数字“1”的调换；
 • 字母“I”和字母“l”（el）的互换；
 • 字母“l”（el）和数字“1”的互换；
 • 字母“S”和数字“5”的互换；
 • 字母“Z”和数字“2”的互换；
 • 字母“n”和字母“h”的互换；
 • 字母“B”和数字“8”的互换；
 • 字母序列“rn” （r后面跟着n）与字母“m”的互换。

**示例1：不规范用法**

```cpp
int32_t id1_a_b_c;
int32_t id1_abc; // Non-compliant
int32_t id2_abc; // Non-compliant
int32_t id2_ABC; // Non-compliant
int32_t id3_a_bc;
int32_t id3_ab_c; // Non-compliant
int32_t id4_a_bc;
int32_t id4_ab_c; // Non-compliant
int32_t id5_ii;
int32_t id5_11; // Non-compliant
int32_t id6_i0;
int32_t id6_1O; // Non-compliant
int32_t id7_in;
int32_t id7_1h; // Non-compliant
int32_t id8_Z5;
int32_t id8_2S; // Non-compliant
int32_t id9_ZS;
int32_t id9_25; // Non-compliant
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_02_10_02_rule　声明在内部范围的标识符不得掩盖声明在外部范围的标识符
> 等级：**强制**　分类：词法信息

如果在内部作用域中声明标识符并使用与已经存在于外部作用域中的标识符相同的名称，那么最内层声明将“隐藏”外部声明。 这可能会导致开发人员混淆。

**示例1：不规范用法**

```cpp
int16_t i;
{
    int16_t i; // This is a different variable
    // This is Non-compliant
    i = 3; // It could be confusing as to which i this refers
}
void fn(int16_t i) // Non-compliant
{
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_02_10_03_rule　typedef 名称应是唯一标识符
> 等级：**强制**　分类：词法信息

如果多个 typedef 名称命名相同而它们实际指代又是不同的函数、对象或枚举常量时，开发人员会被困扰。
请注意，在头文件中进行类型定义的情况下，并且该头文件包含在多个源文件中时，不违反此规则。

**示例1：不规范用法**

```cpp
void f1()
{
    typedef int32_t TYPE;
}
void f2()
{
    float32_t TYPE; // Non-compliant
}
```

**示例1：规范用法之一**

```cpp
// f1.cc
namespace NS1
{
    typedef int16_t WIDTH;
}
// f2.cc
namespace NS2
{
    float32_t WIDTH; // Compliant -
    // NS2::WIDTH is not the same as NS1::WIDTH
}
```

### MISRA_CPP_2008_02_10_04_rule　类、联合或枚举名称应为唯一标识符
> 等级：**强制**　分类：通用语言

重新使用类、联合或枚举名称作为另一种类型或任何其他目的可能导致开发人员混淆。 项目中不应复制类、联合或枚举名称，即使声明相同。
当定义在头文件中并且该头文件包含在多个源文件中时，不违反此规则。

**示例1：不规范用法**

```cpp
void f1()
{
    class TYPE
    {
    };
}
void f2()
{
    float32_t TYPE; // Non-compliant
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_02_10_05_rule　不应重用具有静态存储期的非成员对象或函数的标识符名称
> 等级：**推荐**　分类：通用语言

项目中任何源文件都不应重新使用具有静态存储属性的任何标识符，包括对象，函数。 这容易引起开发人员的混淆。

**示例1：不规范用法**

```cpp
namespace NS1
{
    static int32_t global = 0;
}
namespace NS2
{
    void fn()
    {
        int32_t global; // Non-compliant
    }
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_02_10_06_rule　如果某一标识符代表类型，则在同一范围内也不得存在同名的对象或函数
> 等级：**强制**　分类：通用语言

C++中的名称可以同时是类型（type）和对象（object），或类型（type）和函数（function），但这可能会导致混淆。

**示例1：不规范用法**

```cpp
typedef struct vector
{
    uint16_t x;
    uint16_t y;
    uint16_t z;
} vector;
// Non-compliant ^^ Non-compliant ^^
struct vector
{
    uint16_t x;
    uint16_t y;
    uint16_t z;
} vector;
// Non-compliant ^^ Non-compliant ^^
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_02_13_01_rule　只得使用那些定义在 ISO/IEC 14882:2003 中的转义序列
> 等级：**强制**　分类：词法信息

使用未定义的转义序列会导致未定义行为，合法的转义序列（ISO/IEC 14882:2003）有: \n, \t, \v, \b, \r, \f, \a, \\, \?, \', \", \<Octal Number>, \x<Hexadecimal Number>

**示例1：不规范用法**

```cpp
void static_176 (void)
{
     char c = 'b';

     switch(c)
     {
     case '\m': /* not compliant */
          break;

     default:
          break;
     }
}

void fn ( )
{
const char_t a[ 2 ] = "\k"; // Non-compliant
const char_t b[ 2 ] = "\b"; // Compliant
}
```

**示例1：规范用法之一**

```cpp
void static_176 (void)
{
     char c = 'b';

     switch(c)
     {
     case 'm': /* compliant */
          break;

     default:
          break;
     }
}
修改第[7]行无效的转义序列
```

### MISRA_CPP_2008_02_13_02_rule　八进制常量和八进制escape序列（&#92;0除外）不应该被使用
> 等级：**强制**　分类：词法信息

以“0”（零）开头的任何整数常量都将被视为八进制。因此，有可能将意图作为十进制数字的零前缀常量错误地输入为八进制数字，与开发者的期望相反。
八进制转义序列也可能会出问题，因为意外引入十进制数字（即“8”或“9”）会结束八进制转义并引入另一个字符。

**示例1：不规范用法**

```cpp
int code[1] = 109;
int code[2] = 100;
int code[3] = 052;
int code[4] = 071;
int code[5] ='\109';
int code[6] ='\100';
```

### MISRA_CPP_2008_02_13_03_rule　后缀 "U" 应该适用于所有无符号类型的八进制或十六进制整型字面量
> 等级：**强制**　分类：词法信息

整数的类型取决于各种复杂的因素，包括： 常量的大小; 整数类型的实现大小; 后缀是否存在; 在其中表示值的数字基数（即十进制、八进制或十六进制）。

**示例1：不规范用法**

```cpp
unsigned long var = 02;
unsigned int u32a = 0x10;
```

**示例1：规范用法之一**

```cpp
unsigned long var = 02U;
unsigned int u32a = 0x10U;
```

### MISRA_CPP_2008_02_13_04_rule　字面量后缀应该是大写
> 等级：**强制**　分类：词法信息

使用大写字母后缀可以消除用于声明文字的数字“1”（数字1）和字母“l”（字母EL）之间的潜在歧义。

**示例1：不规范用法**

```cpp
void foo(long param = 64l) // 违规
{
const long a = 64l; // 违规
const int b=0U;
const int c=0u; // 违规
}
```

**示例1：规范用法之一**

```cpp
void foo(long param = 64L)
{
const long a = 64L;
const int b=0U;
const int c=0U;
}
```

### MISRA_CPP_2008_02_13_05_rule　不得连接窄字符和宽字符字符串字面值
> 等级：**强制**　分类：词法信息

宽字符和窄字符字符串字面值的连接会导致未定义的行为。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
char_t n_array[] = "Hello" "World"; // Compliant
wchar_t w_array[] = L"Hello" L"World"; // Compliant
wchar_t mixed[] = "Hello" L"World"; // Non-compliant
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

---

## 第 3 章 基本概念（13 条）

### MISRA_CPP_2008_03_01_01_rule　头文件可以被多个翻译单元包含，而不违反单一定义规则
> 等级：**强制**　分类：基本概念

头文件用于声明对象、函数、内联函数、函数模板、typedef、宏、类和类模板，不应该包含或产生占用存储的对象或函数（或对象或函数片段）的定义。
无论名称或后缀如何，通过#include指令包含的任何文件都被视为头文件。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
// a.h
void f1(); // Compliant
void f2() {} // Non-compliant
inline void f3() {} // Compliant
template <typename T>
void f4(T) {} // Compliant
int32_t a; // Non-compliant
// a.cpp
#include "a.h"
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_03_01_02_rule　函数不得声明在语句块范围内
> 等级：**强制**　分类：基本概念

在块作用域中声明的函数可能引用封闭命名空间的成员，因此声明应显式放置在命名空间级别。
此外，在声明语句可以声明函数或对象时，编译器将选择声明函数。为避免可能导致开发人员困惑的声明含义，不应在块作用域声明函数。

**示例1：不规范用法**

```cpp
int fun()
{
    int funfun(); //not compliant
}
```

**示例1：规范用法之一**

```cpp
int funfun(); // Compliant
int fun()
{

}
将语句块内的函数声明放到文件开始处。
```

### MISRA_CPP_2008_03_01_03_rule　当一个数组被声明的时候，其大小应该被显式地指定或通过初始化隐式地定义
> 等级：**强制**　分类：基本概念

虽然可以声明一个不完整类型的数组并访问其元素，但在可以明确确定数组大小时，这样做更安全。

**示例1：不规范用法**

```cpp
extern int array2[ ]; //not compliant
extern int array1[ ]; //not compliant

int array2[ ] = { 0, 10, 15 }; //ok
extern int array1[ 10 ];
```

**示例1：规范用法之一**

```cpp
extern int array2[5]; //ok
extern int array1[5]; //ok
int array2[ ] = { 0, 10, 15 }; //ok
extern int array1[ 10 ];
```

### MISRA_CPP_2008_03_02_01_rule　一个对象或函数的所有声明的类型应该兼容
> 等级：**强制**　分类：基本概念

如果两个不同翻译单元中的对象或函数声明没有兼容类型，则该行为是未定义的。 确保对象或函数类型兼容的最简单方法是使声明相同。

**示例1：不规范用法**

```cpp
/* in a.c */
extern int i; // diagnostic required

int f(void)
{
    return ++i;
}

/* in b.c */
short i; // diagnostic required
```

**示例1：规范用法之一**

```cpp
/* in a.c */
extern int i;

int f(void)
{
    return ++i;
}

/* in b.c */
int i; // diagnostic required
```

### MISRA_CPP_2008_03_02_02_rule　不应违背唯一定义原则
> 等级：**强制**　分类：基本概念

违反单一定义规则会导致未定义的行为，每个非内联函数或对象有且仅有一个定义。

**示例1：不规范用法**

```cpp
//file1.c
int a = 0；
//file2.c
int a = 0; //not compliant
int b =1;
```

**示例1：规范用法之一**

```cpp
//file1.c
int a = 0；
//file2.c
int b = 1;
全局变量a有单一的定义，定义在file1.c文件中
```

### MISRA_CPP_2008_03_02_03_rule　一个在多个转换单元使用的类型、对象或者函数应该只能在一个文件中被声明一次
> 等级：**强制**　分类：基本概念

类型、对象或函数的唯一声明允许编译器检测相同实体的不兼容类型。 通常，这将意味着在头文件中声明外部标识符，并将其包含在定义或使用标识符的任何文件中。

**示例1：不规范用法**

```cpp
// header.hpp
extern int16_t a;

// file1.cpp
#include "header.hpp"
extern int16_t b;

// file2.cpp
#include "header.hpp"
extern int32_t b; // not-compliant
int 32_a; // compliant
```

**示例1：规范用法之一**

```cpp
// header.hpp
extern int16_t a;

// file1.cpp
#include "header.hpp"
extern int16_t b;

// file2.cpp
#include "header.hpp"
extern int32_t c; // compliant
int 32_a; // compliant
```

### MISRA_CPP_2008_03_02_04_rule　具有外部链接的标识符应该具有准确唯一的外部定义
> 等级：**强制**　分类：基本概念

如果使用具有多个定义（在不同的翻译单元中）或根本没有定义的标识符，则其行为是未定义的。除了模板和内联函数之外，不允许在不同的翻译单元中进行多次定义，即使这些定义相同。

**示例1：不规范用法**

```cpp
//file1.c
int a = 0；
//file2.c
int a = 0; //not compliant
int b =1;
```

**示例1：规范用法之一**

```cpp
//file1.c
int a = 0；
//file2.c
int b = 1;
全局变量a有单一的定义，定义在file1.c文件中
```

### MISRA_CPP_2008_03_03_01_rule　具有外部链接的对象或函数应该被声明在头文件中
> 等级：**强制**　分类：基本概念

需要将具有外部链接的对象和函数的声明放置在头文件并文档化。
如果不需要外部链接，则对象或函数应在匿名命名空间中声明或声明为静态， 这将减少对象和函数的可见性。

例外：本规则不适用于 main，也不适用于匿名命名空间的成员。

**示例1：不规范用法**

```cpp
// case.h
extern int b;
extern void func1() ;

// case.cpp
#include <iostream>
#include <cstring>
#include "case.h"
using namespace std;
int a; // not
int b; // ok
extern int fun(){ //not
	int m = 0;
	return m;
}
void func(){ // not
	int k = 0;
}
void func1() // ok
{
       return ;
}
static int func2() // ok
{
       return 0;
}
```

**示例1：规范用法之一**

```cpp
// case.h
extern int a;
extern int b;
extern int fun();
extern void func();
extern void func1() ;

// case.cpp
#include <iostream>
#include <cstring>
#include "case.h"
using namespace std;
int a; // ok
int b; // ok
extern int fun(){ //ok
	int m = 0;
	return m;
}
void func(){ // ok
	int k = 0;
}
void func1() // ok
{
       return ;
}
static int func2() // ok
{
       return 0;
}
源文件中定义了具有外部链接的变量和函数，将相应的声明放在头文件中。
```

### MISRA_CPP_2008_03_03_02_rule　如果一个函数有内部链接，那么所有的再声明应该包括静态存储类限定符（static ）
> 等级：**强制**　分类：基本概念

如果函数的声明包含static，为避免隐式转换的，函数的重新声明需要一致应用static关键字。

**示例1：不规范用法**

```cpp
static int fun();
static int fun2();
int fun() //not compliant
{

}

int fun2(); //not compliant
```

**示例1：规范用法之一**

```cpp
static int fun();
static int fun2();
static int fun() //compliant
{

}
static int fun2(); //compliant
```

### MISRA_CPP_2008_03_04_01_rule　一个类型和对象需要声明在一个最小化其作用域的块中
> 等级：**强制**　分类：基本概念

在尽可能小的块作用域内定义变量可减少这些变量的可见性，从而减少了意外使用这些标识符的可能性。

**示例1：不规范用法**

```cpp
int a; //not compliant
int fun()
{
      int b=a;
}
```

**示例1：规范用法之一**

```cpp
int fun()
{
      int a; //compliant
      int b=a;
}
将变量a声明在fun函数中
```

### MISRA_CPP_2008_03_09_01_rule　用于对象、函数返回类型或函数参数的类型在所有声明和重新声明中应完全一致
> 等级：**强制**　分类：基本概念

如果重新声明具有兼容但非标记逐个相同的类型，则可能不清楚该重新声明指的是哪个声明。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
typedef int32_t INT;
INT i;
extern int32_t i; // Non-compliant
INT j;
extern INT j; // Compliant
// The following lines break Rule 3–9–2
extern void f(signed int);
void f(int); // Non-compliant
extern void g(const int);
void g(int); // Non-compliant
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_03_09_02_rule　应使用指示大小和符号的typedef代替基本数值类型
> 等级：**推荐**　分类：基本概念

不应使用char、int、short、long、float、double和long double等基本数值类型，而应使用长度特定的typedef。这有助于澄清存储的大小，但由于整数提升的不对称行为，无法保证可移植性。

例外：wchar_t 不需要 typedef，因为它总是映射到支持宽字符的类型。char_t 这个 typedef 既不表示大小也不表示符号性，它只是为了允许在不使用基本 char 类型的情况下声明 char 对象，从而使分析工具能够检测并报告对（普通）char 的任何使用。

**示例1：不规范用法**

> 原文未给出该类型的独立示例。

**示例1：规范用法之一**

```cpp
typedef char char_t;
typedef signed char int8_t;
typedef signed short int16_t;
typedef signed int int32_t;
typedef signed long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;
typedef float float32_t;
typedef double float64_t;
typedef long double float128_t;
```

### MISRA_CPP_2008_03_09_03_rule　不得使用浮点数值的底层比特表示
> 等级：**强制**　分类：基本概念

用于浮点值的存储布局可能因编译器而异，因此不应进行直接依赖于值存储方式的浮点操作。

**示例1：不规范用法**

```cpp
float32_t My_fabs(float32_t f)
{
    uint8_t *pB = reinterpret_cast<uint8_t *>(&f);
    *(pB + 3) &= 0x7f; // Non-compliant – generate the absolute value
    // of an IEEE-754 float value.
    return (f);
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

---

## 第 4 章 标准转换（5 条）

### MISRA_CPP_2008_04_05_01_rule　布尔类型的表达式不得用作除了赋值运算符 = ，逻辑运算符 &&, ||, ! ，等号运算符 == 和 != ，一元 & 运算符和条件运算符以外的内置运算符的操作数
> 等级：**强制**　分类：标准转换

使用bool操作数与其他运算符不太可能有意义（或有意），这个规则有助于检查逻辑运算符（&&，| | 和！）与位运算符（&，|和〜）混淆用法。

**示例1：不规范用法**

```cpp
int goo();
void foo()
{
int x, y, z;
z = (x > y) & (goo()); // 违规
z = x | (goo() != 0); // 违规
z = ~(x == y); // 违规
}
```

**示例1：规范用法之一**

```cpp
int goo();
void foo()
{
int x, y, z;
z = (y) & (goo()); // ok
z = x | (goo() ); // ok
z = (x == y); // ok
}
```

### MISRA_CPP_2008_04_05_02_rule　枚举类型的表达式不得用作除了 [ ], =, ==, !=, <, <=, >, >=, 和一元 & 运算符以外的内置运算符的操作数
> 等级：**强制**　分类：标准转换

枚举的表示形式取决于具体实现定义，因此不应在算术上下文中使用。

**示例1：不规范用法**

```cpp
enum { COLOUR_0, COLOUR_1, COLOUR_2, COLOUR_3, COLOUR_COUNT } colour;
void foo()
{
   if (COLOUR_0 == colour); // complaint
   if ( ( COLOUR_0 + COLOUR_1 ) == colour ); // not complaint
   if (COLOUR_0 < colour); // complaint

}
```

**示例1：规范用法之一**

```cpp
enum { COLOUR_0, COLOUR_1, COLOUR_2, COLOUR_3, COLOUR_COUNT } colour;
void foo()
{
   if (COLOUR_0 == colour); // complaint
   if ( (COLOUR_1 ) == colour ); // complaint
   if (COLOUR_0 < colour); // complaint

}
```

### MISRA_CPP_2008_04_05_03_rule　普通的 char 类型和 wchar_t 型的表达式不得用作除了赋值运算符 = ， 等号运算符 == 和 !=， 一元 & 运算符以外的内置运算符的操作数
> 等级：**强制**　分类：标准转换

操纵字符数据可能会生成与开发人员预期相违背的结果。

例外：特殊情况下，如果遵守相关限制，可以使用以下运算符：· 二元 + 运算符可用于将 0 到 9 范围内的整数值加到 '0' 上；
· 二元 - 运算符可用于减去字符 '0'；
· 关系运算符 <、<=、>、>= 可用于确定某字符（或宽字符）是否表示数字。

**示例1：不规范用法**

```cpp
void foo()
{
char ch = 't'; // OK
if ( ( ch >= 'a' ) && ( ch <= 'z' ) ) // 违规
{
//...
}
}
```

**示例1：规范用法之一**

```cpp
void foo()
{
char ch = 't'; // OK
if ( ( ch != 'a' ) && ( ch != 'z' ) ) // ok
{
//...
}
}
```

### MISRA_CPP_2008_04_10_01_rule　不得将NULL用作整数值
> 等级：**强制**　分类：标准转换

在C++中，字面量0既是整数类型，又是空指针常量。为了满足开发人员的期望，应使用NULL作为空指针常量，而使用0代替整数零。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
#include <cstddef>
void f1(int32_t);
void f2(int32_t *);
void f3()
{
    f1(NULL); // Not-compliant, NULL used as an integer
    f2(NULL); // Compliant
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_04_10_02_rule　字面零(0)不得用作空指针常量
> 等级：**强制**　分类：标准转换

在C++中，字面量0既是整数类型，又是空指针常量。为了满足开发人员的期望，应使用NULL作为空指针常量，而使用0代替整数零。

**示例1：不规范用法**

```cpp
#include <cstddef>
void f1(int*);
void foo()
{
	f1(0); //not complaint
}
```

**示例1：规范用法之一**

```cpp
#include <cstddef>
void f1(int*);
void foo()
{
	f1(NULL); //complaint
}
```

---

## 第 5 章 表达式（42 条）

### MISRA_CPP_2008_05_00_01_rule　在标准允许的任何计算顺序下，表达式的值应相同
> 等级：**推荐**　分类：表达式

除了一些运算符（特别是&&，||，？：和，（逗号）），子表达式计算的顺序是未指定的且可能会变化。这意味着不能依赖子表达式计算顺序，并且特别不能依赖副作用发生的顺序。
请注意，“计算顺序”问题不能通过使用括号来解决，因为这不是优先级问题。

**示例1：不规范用法**

```cpp
x = b[ i ] + i++;
x = func( i++, i );
p->task_start_fn (p++);
x = f(a) + g(a);
push( pop() - pop() );
y = 4;
x = y = y++; // It is undefined whether the final value of y is 4 or 5
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_05_00_02_rule　在表达式中，不应过于依赖C++运算符的优先级规则
> 等级：**推荐**　分类：表达式

除了使用括号覆盖默认运算符优先级外，还应使用括号来强调它。
在C++相当复杂的优先级规则中很容易犯错误，此方法有助于避免此类错误并使代码更易于阅读。
但是，太多的括号可以使代码混乱并使其难以阅读。

**示例1：不规范用法**

```cpp
x = a + b; // acceptable
x = (a + b); // () not required
x = a * -1; // acceptable
x = a * (-1); // () not required
x = a + b + c; // acceptable, but care needed
x = f ( a + b, c ); // no () required for a + b
x = ( a == b ) ? a : ( a – b );
if ( a && b && c ) // acceptable
x = ( a + b ) – ( c + d );
x = ( a * 3 ) + c + d;
x = static_cast< uint16_t > ( a ) + b; // no need for cast
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_05_00_03_rule　cvalue 表达式不得隐式地转换成不同的原始类型
> 等级：**强制**　分类：表达式

cvalue 表达式不得隐式地转换成不同的原始类型

**示例1：不规范用法**

```cpp
#include<iostream>
#include<stdio.h>
using namespace std;

void Conv1_int( )
{
	unsigned short u16a,u16b;
	unsigned int u32a, u32b;
  	unsigned long u64a;
	u32a = u16b + u16a ; /* Violation */
	u32a = u64a + (u16a + u16b); /* Violation */
}
int main()
{
  	return 0;
}
```

**示例1：规范用法之一**

```cpp
#include<iostream>
#include<stdio.h>
using namespace std;

void Conv1_int( )
{
	unsigned short u16a,u16b;
	unsigned int u32a, u32b;
  	unsigned long u64a;
	u32a = u32b + u16b + u16a ; /* ok */
	u32a = u16b + (u16a + u32b); /* ok */
}
int main()
{
  	return 0;
}
```

### MISRA_CPP_2008_05_00_04_rule　整型的隐式转换不得改变原始类型的符号属性
> 等级：**强制**　分类：表达式

有符号到无符号的转换可能导致实现定义行为，与开发人员的期望可能不一致。

**示例1：不规范用法**

```cpp
void Conv1_int( ) {
unsigned int u32a, u32b;
signed int s32a, s32b;
s32a = u32a; /* Violation */
s32b = s32a + u32a; /* Violation */
}
```

**示例1：规范用法之一**

```cpp
void Conv1_int( ) {
unsigned int u32a, u32b;
signed int s32a, s32b;
s32a = (signed int)u32a; /* ok */
s32b = s32a + (signed int)u32a; /* ok */
}
```

### MISRA_CPP_2008_05_00_05_rule　不应存在隐式浮点数和整数之间的转换
> 等级：**强制**　分类：表达式

从浮点数到整数类型的转换会丢失信息，如果浮点值无法表示为整数类型，则可能导致未定义行为。 从整数类型到浮点类型的转换可能不会得到精确的表示，这可能与开发人员的期望不一致。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
void f()
{
    float32_t f32;
    int32_t s32;
    s32 = f32; // Non-compliant
    f32 = s32; // Non-compliant
    f32 = static_cast<float32_t>(s32); // Compliant
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_00_06_rule　整型或浮点型的隐式转换不得减少原始类型的长度
> 等级：**强制**　分类：表达式

导致类型大小减小的隐式转换可能导致信息丢失。

**示例1：不规范用法**

```cpp
void Conv1_int( ) {
  unsigned char u8a;
  unsigned short u16a;
  unsigned int u32a;
  u16a = u32a; //not compliant
  u8a = u32a; //not compliant
}
int main()
{
   double dData = 0.0;
   float fData;
   fData = dData; //not compliant
   return 0;
}
```

**示例1：规范用法之一**

```cpp
#include <stdio.h>

int main() {
    int num1 = 10;
    long num2 = num1; // compliant 正确的隐式转换，将int类型转换为long类型
    printf("Number: %ld\n", num2);
    return 0;
}
```

### MISRA_CPP_2008_05_00_07_rule　cvalue表达式不应明确进行浮点-整数转换
> 等级：**强制**　分类：表达式

应用于表达式结果的强制转换不会更改计算表达式的类型，这可能与开发人员的期望相矛盾。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
// Integral to Float
void f1()
{
    int16_t s16a;
    int16_t s16b;
    int16_t s16c;
    float32_t f32a;
    // The following performs integer division
    f32a = static_cast<float32_t>(s16a / s16b); // Non-compliant
    // The following also performs integer division
    s16c = s16a / s16b;
    f32a = static_cast<float32_t>(s16c); // Compliant
    // The following performs floating-point division
    f32a = static_cast<float32_t>(s16a) / s16b; // Compliant
}


// Float to Integral
void f2()
{
    float32_t f32a;
    float32_t f32b;
    float32_t f32c;
    int16_t s16a;
    // The following performs floating-point division
    s16a = static_cast<int16_t>(f32a / f32b); // Non-compliant
    // The following also performs floating-point division
    f32c = f32a / f32b;
    s16a = static_cast<int16_t>(f32c); // Compliant
    // The following performs integer division
    s16a = static_cast<int16_t>(f32a) / f32b; // Compliant
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_00_08_rule　整型或浮点型的显式转换不得增加 cvalue 表达式的原始类型的长度
> 等级：**强制**　分类：表达式

应用于表达式结果的强制转换不会更改计算表达式的类型，这可能与开发人员的期望相矛盾。

**示例1：不规范用法**

```cpp
void myFunction()
{
unsigned int ui1, ui2;
signed int si1, si2;
unsigned short us1, us2;
double d;

ui1 = (unsigned int)(us1 - us2); /* 违规-有符号类型强制转换成无符号类型 */
d = (double)(ui1 * ui2); /* 违规-有符号类型强制转换成无符号类型 */
}
```

**示例1：规范用法之一**

```cpp
void myFunction()
{
unsigned int ui1, ui2;
signed int si1, si2;
unsigned short us1, us2;
double d;

ui1 = (unsigned int)us1 - (unsigned int)us2; /* ok */
d = (double)ui1 * (double)ui2; /* ok */
}
```

### MISRA_CPP_2008_05_00_09_rule　整型的显式转换不得改变复杂表达式的原始类型的符号
> 等级：**强制**　分类：表达式

有符号到无符号的转换可能导致表达式具有与开发人员的预期不一致的值。

**示例1：不规范用法**

```cpp
void myFunction()
{
unsigned int ui1, ui2;
signed int si1, si2;
unsigned short us1, us2;
double d;
ui1 = (unsigned int)(si1 + si2); /* 违规-有符号类型强制转换成无符号类型 */
si1 = (signed int)(ui1 / ui2); /* 违规-有符号类型强制转换成无符号类型 */
}
```

**示例1：规范用法之一**

```cpp
void myFunction()
{
unsigned int ui1, ui2;
signed int si1, si2;
unsigned short us1, us2;
double d;
ui1 = (unsigned int)si1 + (unsigned int)si2; /* ok */
si1 = (signed int)ui1 / (signed int)ui2; /* ok */
}
```

### MISRA_CPP_2008_05_00_10_rule　如果按位运算符 ~ 和 << 适用于无符号字符型或无符号短整型的操作数，其结果应该立即强制转换成相应的原始类型
> 等级：**强制**　分类：表达式

当对小整数类型（unsigned char或unsigned short）应用运算符〜和<<时，操作之前会进行整数提升，结果可能意外包含高位比特。

例外：对操作数使用 ~ 或 << 所得结果的立即赋值（包括作为函数实参或函数返回值使用），即使该转换是隐式的。

**示例1：不规范用法**

```cpp
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
void foo()
{
uint8_t port = 0x5aU;
uint8_t result_8;
uint16_t result_16;
uint16_t mode;
result_8 = (~port) >> 4; /* 违规 */
result_16 = ((port << 4) & mode) >> 6; /* 违规 */
}
```

**示例1：规范用法之一**

```cpp
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
void foo()
{
uint8_t port = 0x5aU;
uint8_t result_8;
uint16_t result_16;
uint16_t mode;
result_8 =((uint8_t)(~port)) >> 4; /* ok */
result_16 = ((uint16_t)((uint16_t)port << 4) & mode) >> 6; /* ok */
}
```

### MISRA_CPP_2008_05_00_11_rule　普通的 char 类型应该只能用于字符值的存储和使用
> 等级：**强制**　分类：表达式

C++中的char类型定义用于与实施字符集一起使用。 char是有符号还是无符号是在实现中定义的，因此不适用于数字数据。

**示例1：不规范用法**

```cpp
#include <stdio.h>
int main()
{
   char a = 1; //not compliant
   if(a == 2) //not compliant
       {
           printf("XXX");
       }
   return 0;
}
```

**示例1：规范用法之一**

```cpp
#include <stdio.h>
int main()
{
   char a = 'a'; //compliant
   if(a == 'b') // compliant
       {
           printf("XXX");
       }
   return 0;
}
使单纯的字符变量a存储使用字符值。
```

### MISRA_CPP_2008_05_00_12_rule　signed char 和 unsigned char 类型应该只能用于数值的存储和使用
> 等级：**强制**　分类：表达式

有三种不同的char类型，（plain）char，signed char和unsigned char。 signed char和unsigned char应该只用于数字数据，而plain char应该只用于字符数据。由于是实现定义的，不能假设plain char类型的符号性。

**示例1：不规范用法**

```cpp
#include <stdio.h>
int main()
{
   unsigned char a = 'a'; //not compliant
   if(a == 2)
       {
           a = a + 'b'; //not compliant
       }
   return 0;
}
```

**示例1：规范用法之一**

```cpp
#include <stdio.h>
int main()
{
   unsigned char a = 1; //compliant
   if(a == 2)
       {
           a = a +2; //compliant
       }
   return 0;
}
使unsigned char变量a存储使用数字值
```

### MISRA_CPP_2008_05_00_13_rule　if语句和迭代语句的条件应为bool类型
> 等级：**强制**　分类：表达式

如果在if语句或迭代语句的条件中使用了除bool以外的类型的表达式，则其结果将被隐式转换为bool。条件表达式应包含一个明确的测试（产生bool类型的结果），以澄清开发人员的意图。

例外：形如 type-specifier-seq declarator 的条件不要求具有 bool 类型。引入此例外是因为实现同样效果的其他机制繁琐且易错。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
extern int32_t *fn();
extern int32_t fn2();
extern bool fn3();
while (int32_t *p = fn()) // Compliant by exception
{
    // Code
}
// The following is a cumbersome but compliant example
do
{
    int32_t *p = fn();
    if (NULL == p)
    {
        break;
    }
    // Code...
} while (true); // Compliant
while (int32_t length = fn2()) // Compliant by exception
{
    // Code
}
while (bool flag = fn3()) // Compliant
{
    // Code
}
if (int32_t *p = fn()) // Compliant by exception
    if (int32_t length = fn2()) // Compliant by exception
        if (bool flag = fn3()) // Compliant
            if (u8) // Non-compliant
                if (u8 && (bool_1 <= bool_2)) // Non-compliant
                    for (int32_t x = 10; x; --x) // Non-compliant
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_00_14_rule　条件运算符的第一个操作数应该是布尔类型
> 等级：**强制**　分类：表达式

如果将类型为bool以外的表达式用作条件运算符的第一个操作数，则其结果将被隐式转换为bool。第一个操作数应包含一个明确的测试（产生类型为bool的结果），以澄清开发人员的意图。

**示例1：不规范用法**

```cpp
void foo(int i, int j, int k, int l)
{
i = j ? k : l; // 违规
}
```

**示例1：规范用法之一**

```cpp
void foo(int i, int j, int k, int l)
{
i = (j!=0) ? k : l; // ok
}
```

### MISRA_CPP_2008_05_00_15_rule　数组索引应该是指针运算的唯一形式
> 等级：**强制**　分类：表达式

数组索引是指针算术运算的唯一可接受形式，因为它比指针操作更清晰且更不容易出错。
此规则禁止显式计算指针值，仅将数组索引应用于定义为数组类型的对象， 任何明确计算的指针值都有可能访问意外或无效的内存地址， 指针可能超出数组或结构的边界，甚至可能指向有效的任意位置。
 例外情况： 递增/递减运算符可以用于指向数组的指针实现的迭代器上。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
template <typename IterType>
uint8_t sum_values(IterType iter, IterType end)
{
    uint8_t result = 0;
    while (iter != end)
    {
        result += *iter;
        ++iter; // Compliant by exception
    }
    return result;
}
void my_fn(uint8_t *p1, uint8_t p2[])
{
    uint8_t index = 0;
    uint8_t *p3;
    uint8_t *p4;
    *p1 = 0;
    ++index;
    index = index + 5;
    p1 = p1 + 5; // Non-compliant – pointer increment
    p1[5] = 0; // Non-compliant – p1 was not declared as array
    p3 = &p1[5]; // Non-compliant – p1 was not declared as array
    p2[0] = 0;
    p2[index] = 0; // Compliant
    p4 = &p2[5]; // Compliant
}
uint8_t a1[16];
uint8_t a2[16];
my_fn(a1, a2);
my_fn(&a1[4], &a2[4]);
uint8_t a[10];
uint8_t *p;
p = a;
*(p + 5) = 0; // Non-compliant
p[5] = 0; // Compliant
sum_values(&a1[0], &a1[16]);
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_00_16_rule　指针算术运算得出的任何指针都应寻址相同数组的元素
> 等级：**强制**　分类：表达式

此规则适用于以下形式的表达式：
 •整数表达式+指针表达式
 •指针表达式+整数表达式
 •指针表达式-整数表达式
 •++指针表达式
 •指针表达式++
 •--指针表达式
 •指针表达式--
 •指针表达式[整数表达式]
 如果从上述指针表达式获得的结果指向数组元素之外，则其具有未定义的行为。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
void f1(const int32_t *a1)
{
    int32_t a2[10];
    const int32_t *p1 = &a1[1]; // Non-compliant – a1 not an array
    int32_t *p2 = &a2[10]; // Compliant
    int32_t *p3 = &a2[11]; // Non-compliant
}
void f2()
{
    int32_t b;
    int32_t c[10];
    f1(&b);
    f1(c);
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_00_17_rule　指针之间的减法操作应该只能适用于指向相同数组元素的指针
> 等级：**强制**　分类：表达式

此规则适用于以下形式的表达式： pointerexpression1 - pointerexpression2， 其中pointerexpression1和pointerexpression2是指向数组元素的指针。
如果指针表达式没有指向相同数组的元素或该数组的末尾之外的元素，则其具有未定义的行为。

**示例1：不规范用法**

```cpp
void fun()
{
  int a1[10];
  int a2[10];
  int *p1;
  int *p2;

  p1=&a1[0];
  p2=&a2[0];
  int diff;
  diff = p2-p1; // not
}
```

**示例1：规范用法之一**

```cpp
void fun()
{
  int a1[10];
  int a2[10];
  int *p1;
  int *p2;

  p1=&a1[0];
  p2=&a1[2];
  int diff;
  diff = p2-p1; // ok
}
指针p1、p2指向同一区域
```

### MISRA_CPP_2008_05_00_18_rule　>, >=, <, <不得适用于指针类型的对象，除非它们指向同一个数组
> 等级：**强制**　分类：表达式

如果两个指针没有指向同一个对象，则尝试对指针进行比较将导致未定义的行为。
注意：可以寻址数组末尾之外的下一个元素，但不允许访问此元素。

**示例1：不规范用法**

```cpp
int fsub(int *a, int *b);
int main()
{
    int sub = 0;
    int a = 1,b = 2;
    sub = fsub(&a, &b);
    return 0;
}
int fsub(int *a, int *b)
{
    int sub = 0;
    if(a > b) //not complaint
    {
        sub = (*a) - (*b);
    }
    else if(a < b) //not complaint
    {
        sub = (*b) - (*a);
    }
    else
    {
        sub = 0;
    }
    return sub;
}
```

**示例1：规范用法之一**

```cpp
int good_fsub(int *a, int *b)
{
    int sub = 0;
    if((*a) > (*b)) //ok
    {
        sub = (*a) - (*b);
    }
    else if((*a) < (*b)) //ok
    {
        sub = (*b) - (*a);
    }
    else
    {
        sub = 0;
    }
    return sub;
}
第[12]、[16]行对[a]、[b]两个指针的内容进行大于或者小于的逻辑比较。
```

### MISRA_CPP_2008_05_00_19_rule　对象的声明应包含不超过两级的间接指针。
> 等级：**强制**　分类：表达式

使用超过两级间接引用可能会严重影响了解代码行为的能力，因此应避免。

**示例1：不规范用法**

```cpp
#include <stdlib.h>
int main(void)
{
    unsigned int array[5] = {0, 1, 2, 3, 4};
    unsigned int *p1_ptr = NULL, **p2_ptr = NULL;
    unsigned int ***p3_ptr = NULL; // not-1
    unsigned int data[5];
    unsigned int i;
    p1_ptr = array;
    p2_ptr = &p1_ptr;
    p3_ptr = &p2_ptr;
    for(i = 0; i < 5; i++)
    {
        data[i] = *(**p3_ptr + i);
    }
    return 0;
}
```

**示例1：规范用法之一**

```cpp
#include <stdlib.h>
int main(void)
{
    unsigned int array[5] = {0, 1, 2, 3, 4};
    unsigned int *p1_ptr = NULL, **p2_ptr = NULL;
    unsigned int **p3_ptr = NULL; // ok-1
    unsigned int data[5];
    unsigned int i;
    p1_ptr = array;
    p2_ptr = &p1_ptr;
    p3_ptr = p2_ptr;
    for(i = 0; i < 5; i++)
    {
        data[i] = *(*p3_ptr + i);
    }
    return 0;
}
```

### MISRA_CPP_2008_05_00_20_rule　二进制位运算符的非常量的操作数应该具有相同的原始类型
> 等级：**强制**　分类：表达式

需要保障参与位运算的非常量的操作数具有相同基础类型。

**示例1：不规范用法**

```cpp
void foo()
{
unsigned char mask = ~(0x10);
unsigned short ushort;
ushort ^= mask; // 违规
}
```

**示例1：规范用法之一**

```cpp
void foo()
{
unsigned char mask = ~(0x10);
unsigned short ushort;
ushort ^= (unsigned short)mask; // ok
}
```

### MISRA_CPP_2008_05_00_21_rule　位运算符仅适用于无符号基础类型的操作数
> 等级：**强制**　分类：表达式

按位操作（〜、<<，<< =，>>，>> =，＆，＆=，^，^ =，|和| =）通常不适用于带符号整数或枚举常量。此外，如果对负值应用右移，则会获得实现定义的结果。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
if ( ( uint16_a & int16_b ) == 0x1234U ) // Non-compliant
if ( ( uint16_a | uint16_b ) == 0x1234U ) // Compliant
if ( ~int16_a == 0x1234U ) // Non-compliant
if ( ~uint16_a == 0x1234U ) // Compliant
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_02_01_rule　逻辑&&或||的每个操作数都应是后缀表达式
> 等级：**强制**　分类：表达式

此规则的效果是要求适当地括号化操作数。 在这种情况下，括号对于代码的可读性和确保行为符合开发人员预期而言非常重要。
例外：如果表达式由仅为逻辑&&的序列或仅为逻辑||的序列组成，则不需要额外的括号。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
if ( x == 0 && ishigh ) // Non-compliant
if ( ( x == 0 ) && ishigh ) // Compliant
if ( x || y || z ) // Compliant by exception,
// if x, y and z bool
if ( x || y && z ) // Non-compliant
if ( x || ( y && z ) ) // Compliant
if ( x && !y ) // Non-compliant
if ( x && ( !y ) ) // Compliant
if ( is_odd( y ) && x ) // Compliant
if ( ( x > c1 ) && ( y > c2 ) && ( z > c3 ) ) // Compliant -
// exception
if ( ( x > c1 ) && ( y > c2 ) || ( z > c3 ) ) // Non-compliant
if ( ( x > c1 ) && ( ( y > c2 ) || ( z > c3 ) ) ) // Compliant as
// extra() used
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_02_02_rule　指向虚基类的指针应该只能通过 dynamic_cast 的方式强制类型转换为指向派生类的指针
> 等级：**强制**　分类：表达式

使用除dynamic cast以外的任何方式从虚基类到派生类进行转换具有未定义的行为。

**示例1：不规范用法**

```cpp
#include <iostream>
using namespace std;
class B
{
public:
    int a;
    B(void);
    virtual~B(void);
    virtual int g(int a=0);
private:
    int b;
};
B::B(void) : b(1){}
B::~B(void){}
int B::g(int a){
    return (a+b);
}

class D : public virtual B
{
public:
    D(void);
    virtual~D(void);
    virtual int g(int a=0);
private:
    int d;
};
D::D(void) : B(),d(2){}
D::~D(void){}
int D::g(int a){
    return (a+d);
}

int main()
{
  D d;
  B &b=d;
  B *pb=&d;
  D *pd1 = reinterpret_cast<D*>(pb); //not complaint
  D &pd2 = reinterpret_cast<D&>(*pb); //not complaint
  return 0;
}
```

**示例1：规范用法之一**

```cpp
#include <iostream>
using namespace std;
class B
{
public:
    int a;
    B(void);
    virtual~B(void);
    virtual int g(int a=0);
private:
    int b;
};
B::B(void) : b(1){}
B::~B(void){}
int B::g(int a){
    return (a+b);
}

class D : public virtual B
{
public:
    D(void);
    virtual~D(void);
    virtual int g(int a=0);
private:
    int d;
};
D::D(void) : B(),d(2){}
D::~D(void){}
int D::g(int a){
    return (a+d);
}

int main()
{
  D d;
  B &b=d;
  B *pb=&d;
  D *pd3 = dynamic_cast<D*>(pb); //ok
  D &pd4 = dynamic_cast<D&>(*pb); //ok
  return 0;
}
第[39]、[40]行的虚基类的指针或引用[pb]使用dynamic_cast 的方式强制类型转换为指向派生类的指针或引用。
```

### MISRA_CPP_2008_05_02_03_rule　不应对多态类型执行基类到派生类的转换
> 等级：**推荐**　分类：表达式

多态实现了接口和层次结构之间的抽象化， 显式转换绕过了这个抽象化层，导致更高级别的耦合和依赖。

**示例1：不规范用法**

```cpp
class Colour
{ /* ... */
};
void setColour(Colour const &);
class Obj
{
public:
    virtual bool hasColour() const = 0;
    virtual Colour getColour() const = 0;
};
class ObjWithColour : public Obj
{
public:
    virtual bool hasColour() const
    {
        return true;
    }
    virtual Colour getColour() const
    {
        return m_colour;
    }


private:
    Colour m_colour;
};
void badPrintObject(Obj const &obj)
{
    ObjWithColour const *pObj =
        dynamic_cast<ObjWithColour const *>(&obj); // Non-compliant
    if (0 != pObj)
    {
        setColour(pObj->getColour());
    }
}
void goodPrintObject(Obj const &obj)
{
    if (obj.hasColour())
    {
        setColour(obj.getColour());
    }
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_05_02_04_rule　不得使用 C 语言风格的强制类型转换(除 void 强制类型转换)和函数符号式强制类型转换(除了显式的构造函数调用)
> 等级：**强制**　分类：表达式

不建议在没有关联性的类型之间执行C-style（cast notation）和函数标记（static_cast，const_cast，dynamic_cast和reinterpret_cast）的强制类型转换。
例外：可以使用void 类型转换忽略非void函数调用的返回值（请参见规则0-1-7）。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
class A
{
public:
    explicit A(int32_t);
};
int32_t g()
{
    return 7;
}
void f()
{
    A const a1 = A(10); // Compliant
    A *a2 = (A *)(&a1); // Non-compliant
    A *a3 = const_cast<A *>(&a1); // Compliant, but breaks Rule 5–2–5
    (void)g(); // Compliant by exception
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_02_05_rule　强制类型转换不得从指针或引用类型中移除任何 const 或 volatile 的修饰
> 等级：**强制**　分类：表达式

删除const或volatile限定可能不符合开发人员的预期，因为它可能会导致未定义的行为。

**示例1：不规范用法**

```cpp
#include <iostream>
using namespace std;
class A
{
public:
  A(void);
  ~A(void);
  explicit A(int);
  int ma;
};

A::A(void)
{
	ma=0;
}

A::A(int a)
{
	ma=a;
}

A::~A(void)
{}

int main(void)
{
    A const a1=A(10);
    A *a2=const_cast<A*>(&a1); //not
    a2->ma=11;
    A &a3=const_cast<A&>(a1); //not
    a3.ma=12;
    return 0;

}
```

**示例1：规范用法之一**

```cpp
#include <iostream>
using namespace std;
class A
{
public:
  A(void);
  ~A(void);
  explicit A(int);
  int ma;
};

A::A(void)
{
	ma=0;
}

A::A(int a)
{
	ma=a;
}

A::~A(void)
{}

int main(void)
{
    A const a1=A(10);
    a2 = const_cast<A* const>(&a1); //ok
    a2->ma=12;
    return 0;

}
第[28]行将引用类型的[&a1]强制转换成[A*const]指针类型
```

### MISRA_CPP_2008_05_02_06_rule　强制类型转换不得转换指向函数的指针为任何其他类型的指针，包括指向函数的指针
> 等级：**强制**　分类：表达式

将函数指针转换为非函数指针类型会导致未定义的行为。 如果使用函数指针转换获得结果的指针进行函数调用，则可能出现未定义的行为。

**示例1：不规范用法**

```cpp
typedef void (*FUN)(int *);
void f ( int )
{
     FUN p =reinterpret_cast< FUN>( &f ); // 违规
    void * fp = reinterpret_cast< void * >( &f ); // 违规
}
```

**示例1：规范用法之一**

```cpp
typedef void (*FUN)(int *);
void f ( int )
{
     FUN p = &f; // ok
    void * fp = &f; // ok
}
```

### MISRA_CPP_2008_05_02_07_rule　带有指针类型的对象不应直接或间接地转换为与其无关的指针类型
> 等级：**强制**　分类：表达式

从指针转换为不相关类型的结果是不确定的。

**示例1：不规范用法**

```cpp
void f(int32_t)
{
    reinterpret_cast<void (*)()>(&f); // Non-compliant
    reinterpret_cast<void *>(&f); // Non-compliant
}
```

**示例1：规范用法之一**

```cpp
// 原文中不违反本规则的转换（原文仅给出这两行片段）：
int32_t i = reinterpret_cast<int32_t>(s); // Compliant, but breaks Rule 5-2-9
e = reinterpret_cast<s *>(i); // Compliant, but breaks Rule 5-2-8
```

### MISRA_CPP_2008_05_02_08_rule　整数类型的对象或指向 void 类型的指针的对象不得被转换为指针类型的对象
> 等级：**强制**　分类：表达式

通常，将整数类型或void类型指针转换为对象的指针会导致未指定的行为。

**示例1：不规范用法**

```cpp
struct S
{
int i;
int j;
};
void f ( void * v, int i )
{
S * s1 = reinterpret_cast< S * >( v ); // 违规
S * s2 = reinterpret_cast< S * >( i ); // 违规
}
```

**示例1：规范用法之一**

```cpp
struct S
{
int i;
int j;
};
void f ( void * v, int i )
{
S * s1 = v; // ok
S * s2 = &i; // ok
}
```

### MISRA_CPP_2008_05_02_09_rule　强制类型转换不得转换一个指针类型为整型
> 等级：**推荐**　分类：表达式

将指针转换为整数时所需的整数大小是与实现相关的。 在可能的情况下，应避免在指针和整型之间进行强制类型转换，但在寻址内存映射寄存器或其他硬件特定功能时可能无法避免。

**示例1：不规范用法**

```cpp
void foo( ) {
int* pi;
int i;
i = (int) pi; // 违规
}
```

**示例1：规范用法之一**

```cpp
void foo( ) {
int* pi;
int i;
i = *pi; // ok
}
```

### MISRA_CPP_2008_05_02_10_rule　递加 (++) 和递减 (--) 运算符不得在表达式中和其他运算符混合使用
> 等级：**推荐**　分类：表达式

用增量和减量运算符与其他算术运算符结合使用是不推荐的，因为：
 • 它会显着影响代码的可读性。
 • 它会在语句中引入附加的副作用，可能会出现未定义行为。

**示例1：不规范用法**

```cpp
int fun(int p);
int main(void)
{
    int x = 1, y = 2, z = 3l;
    int r;
    y = y + (x++); // not-1
    z = z + (++y); // not-2
    z = fun(--z); // not-3
    r = fun(z--); // not-4
    return 0;
}
int fun(int p)
{
    int ret;
    ret = 2*p;
    return ret;
}
```

**示例1：规范用法之一**

```cpp
int fun(int p);
int main(void)
{
    int x = 1, y = 2, z = 3l;
    int r;
    y = y + x;
    x++; // ok-1
    y++; // ok-2
    z = z + y;
    z--; // ok-3
    z = fun(z);
    r = fun(z);
    z--; // ok-4
    return 0;
}
int fun(int p)
{
    int ret;
    ret = 2*p;
    return ret;
}
将自增（++）和自减（--）同其他算术操作隔离开。
```

### MISRA_CPP_2008_05_02_11_rule　逗号运算符, && 运算符和 || 运算符不得被重载
> 等级：**强制**　分类：表达式

重载逗号和逻辑连接运算符在语义上等同于内置版本具有不同的顺序和顺序语义的函数调用。 在使用时可能不清楚这些操作符已被重载，因此开发人员可能不知道哪个语义适用。

**示例1：不规范用法**

```cpp
#include <iostream>
using namespace std;
class A {
public:
	A( int i ) : _i( i ) {};
	~A( ){};
	int value( ) { return _i; }
private:
	int _i;
};
bool operator&&( A& lhs, A& rhs ) //not complaint
{
	return lhs.value( ) && rhs.value( );
}
bool operator||( A& lhs, A& rhs ) //not complaint
{
	return lhs.value( ) || rhs.value( );
}
int operator,( A& lhs, A& rhs)	//not complaint,重载易产生歧义
{
	return lhs.value( );
}

int main()
{
	A a(1);
	A b(0);
	bool f = a && b;
}
```

**示例1：规范用法之一**

```cpp
#include <iostream>
using namespace std;
class A { // complaint
public:
	A( int i ) : _i( i ) {};
	~A( ){};
	int value( ) { return _i; }
private:
	int _i;
};
```

### MISRA_CPP_2008_05_02_12_rule　作为函数参数传递的数组标识符不得降级为指针
> 等级：**强制**　分类：表达式

数组类型的变量降级为指针时，会丢失其范围。 如果设计要求具有不同长度的数组，则应使用类来封装数组对象，并维护数组大小。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
void f1(int32_t p[10]);
void f2(int32_t *p);
void f3(int32_t (&p)[10]);
void b()
{
    int32_t a[10];
    f1(a); // Non-compliant - Dimension "10" lost due to array to
    // pointer conversion.
    f2(a); // Non-compliant - Dimension "10" lost due to array to
    // pointer conversion.
    f3(a); // Compliant - Dimension preserved.
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_03_01_rule　!运算符，逻辑&&或逻辑||运算符的每个操作数都需要是bool类型
> 等级：**强制**　分类：表达式

将bool以外的类型与这些运算符一起使用不太可能是有意义的。
此规则可以检测逻辑运算符（&&，||和！）与位运算符（＆，|和〜）的混淆使用。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
if ( ( a < b ) && ( c < d ) ) // Compliant
if ( 1 && ( c < d ) ) // Non-compliant
if ( ( a < b ) && ( c + d ) ) // Non-compliant
if ( u8_a && ( c + d ) ) // Non-compliant
if ( !0 ) // Non-compliant – also breaks other rules
if ( !ptr ) // Non-compliant
if ( !false ) // Compliant with this rule, but breaks others
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_05_03_02_rule　一元减法运算符不得适用于其原始类型是无符号型的表达式
> 等级：**强制**　分类：表达式

将单目减运算符应用于unsigned int，unsigned long或unsigned long long类型的表达式会生成相应的unsigned int，unsigned long或unsigned long long类型的结果，并且不是一项有意义的操作。

**示例1：不规范用法**

```cpp
void static_p(void)
{
    unsigned int x = 1u;
    unsigned int y = 2u;
    /*...*/
    y = -x;
}
```

**示例1：规范用法之一**

```cpp
void static_p(void)
{
    unsigned int x = 1u;
    unsigned int y = 2u;
    /*...*/
    y = x;
}
第(6)行将[unsigned int]类型的变量[x]赋给[unsigned int]类型的变量[y]。
```

### MISRA_CPP_2008_05_03_03_rule　不应重载&运算符
> 等级：**强制**　分类：表达式

当包含用户声明的operator & 的类型对象被取地址时，会导致未定义的行为。

**示例1：不规范用法**

```cpp
// A.h
class A
{
public:
    A *operator&(); // Non-compliant
};
// f1.cc
class A;
void f(A &a)
{
    &a; // uses built-in operator &
}
// f2.cc
#include "A.h"
void f2(A &a)
{
    &a; // use user-defined operator &
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_05_03_04_rule　sizeof 运算符的操作数求值不得包含副作用
> 等级：**强制**　分类：表达式

sizeof仅针对表达式的类型，不会计算表达式。
如果表达式包含其它副作用，这些副作用不能发生。

例外：形如 sizeof(i) 且 i 为 volatile 的操作数是允许的。

**示例1：不规范用法**

```cpp
void static_p(void)
{
    unsigned int x = 1u;
    unsigned int y = 2u;
    int a = 3;
    /*...*/
    a = sizeof(x=y);
}
```

**示例1：规范用法之一**

```cpp
void static_p(void)
{
    unsigned int x = 1u;
    unsigned int y = 2u;
    int a = 3;
    /*...*/
    a = sizeof(x);
}
```

### MISRA_CPP_2008_05_08_01_rule　移位运算符的右边操作数的位宽应该介于零和一个小于左操作数的原始类型的位宽之间
> 等级：**强制**　分类：表达式

如果右操作数为负，大于或等于左操作数宽度，这些都是未定义行为。

**示例1：不规范用法**

```cpp
void static_p(void)
{
    unsigned int x = 0u;
    unsigned int y = 2u;
    /*...*/
    x = y<<34;
}
```

**示例1：规范用法之一**

```cpp
void static_p(void)
{
    unsigned int x = 0u;
    unsigned int y = 2u;
    /*...*/
    x = y<<30;
}
移位运算的右操作数需小于左操作数类型的位宽。
```

### MISRA_CPP_2008_05_14_01_rule　逻辑运算符 && 或 || 的右边操作数不得包含副作用
> 等级：**强制**　分类：表达式

如果这些子表达式包含副作用，则那些副作用可能会发生或可能不会发生，这取决于其他子表达式的值。 如果开发人员依赖于子表达式的副作用，则可能会产生问题。

**示例1：不规范用法**

```cpp
void foo( ) {
int i;
int j;
if ((j == i) || (0 == i++)) ; // 违规
}
```

**示例1：规范用法之一**

```cpp
void foo( ) {
int i;
int j;
if ((j == i) || (0 == i)) ; // ok
i++;
}
```

### MISRA_CPP_2008_05_17_01_rule　二进制运算符及其赋值运算符形式之间的语义等价应得到保留
> 等级：**强制**　分类：表达式

应确保运算符重载时，运算符之间的相互作用符合开发人员的预期。

**示例1：不规范用法**

> 原文未给出该类型的独立示例。

**示例1：规范用法之一**

```cpp
class A
{
public:
    A &operator=(A const &rhs);
};
A &operator+=(A const &lhs, A const &rhs);
A const operator+(A const &lhs, A const &rhs);
void f(A a1, A a2)
{
    A x;
    x = a1 + a2; // Example 1
    a1 += a2; // Example 2
    if (x == a1) // Example 3
    {
    }
}
```

### MISRA_CPP_2008_05_18_01_rule　不得使用逗号操作符
> 等级：**强制**　分类：表达式

使用逗号运算符不利于代码的可读性，而可以通过其他方法实现相同的效果。

**示例1：不规范用法**

```cpp
int main(void)
{
    int a=8,b=9;
    int c = (a,b); //not compliant
    return 0;
}
```

**示例1：规范用法之一**

```cpp
int main(void)
{
    int a=8,b=9;
    int c =a;
    c = b;
    return 0;
}
将第[4]行的表达式拆开
```

### MISRA_CPP_2008_05_19_01_rule　常量无符号整数表达式的计算不能溢出
> 等级：**推荐**　分类：表达式

编译器无法检测到无符号整数表达式求值的“溢出”，这可能是一个程序错误。

**示例1：不规范用法**

```cpp
// 假定 16 - bit int type，32 - bit long type :
#define START 0x8000
#define END 0xFFFF
#define LEN 0x8000
#if ((START + LEN) > END)
#error Buffer Overrun // OK as START and LEN are unsigned long
#endif
#if (((END – START) – LEN) < 0)
#error Buffer Overrun
// Not OK: subtraction result wraps around to 0xFFFFFFFF
#endif
    // contrast the above START + LEN with the following
    void
    fn()
{
    if ((START + LEN) > END)
    {
        error("Buffer overrun");
        // Not OK: START + LEN wraps around to 0x0000 due to unsigned int
        // arithmetic
    }
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

---

## 第 6 章 语句（23 条）

### MISRA_CPP_2008_06_02_01_rule　赋值运算符不得被用于子表达式
> 等级：**强制**　分类：语句

在子表达式中使用赋值会给完整表达式添加额外的副作用，可能导致值与开发人员预期不一致。此外，这有助于避免将 "=" 和 "==" 混淆。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
void foo();
int fun()
{
  int x,y,z;
  x = y;
  x = y = z; // Non-compliant
  if ( x != 0 ) // Compliant
   {
     foo ( );
   }
  bool b1 = x != y; // Compliant
  bool b2;
  b2 = x != y; // Compliant
  if ( ( x = y ) != 0 ) // Non-compliant
    {
      foo ( );
    }
  if ( x = y ) // Non-compliant
    {
      foo ( );
    }
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_06_02_02_rule　浮点表达式不得直接或间接地作为相等或不相等的判定
> 等级：**强制**　分类：语句

浮点数在存储的时候会有舍入误差，所以不能直接在程序中直接比较两个浮点数相等或不相等。

**示例1：不规范用法**

```cpp
void foo() {
float x, y;
if (x == y); // Violation
if (x == 0.0f); // Violation
}
```

### MISRA_CPP_2008_06_02_03_rule　在预处理之前，只能在单独的一行上出现空语句；可以在其后跟一个注释，前提是空语句后的第一个字符是空格字符。
> 等级：**强制**　分类：语句

通常不应该故意包含空语句，但在使用时，它们应单独出现在一行上。空格字符可以在空语句前面以保留缩进。如果注释跟在空语句后面，则应至少有一个空格字符将空语句与注释分开。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
while ( ( port & 0x80 ) == 0 )
{
    ; // wait for pin - Compliant
    /* wait for pin */ ; // Non-compliant, comment before ;
    ;// wait for pin – Non-compliant, no white-space char after ;
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_06_03_01_rule　构成 switch, while, do while 或者 for 语句体的语句应该是一个复合语句
> 等级：**强制**　分类：语句

构成 switch, while, do while 或者 for 语句体的语句应该是一个复合语句

**示例1：不规范用法**

```cpp
void foo( int x ) {
int i;
switch(i) // Violation
;
for (i=0; i< 10; i++) // Violation
foo( x );
while (1) // Violation
foo( x );
do // Violation
foo( x );
while(1);
}
```

### MISRA_CPP_2008_06_04_01_rule　if (条件) 结构应该后接一个复合语句。 else 关键字必须后接一个复合语句，或者另外的 if 语
> 等级：**强制**　分类：语句

如果这些结构的主体不是复合语句，则如果一个开发人员在试图将单个语句主体更改为多语句主体时未添加所需的大括号，就可能出错。 要求这些结构的主体应该是复合语句（用花括号括起来），可以确保不会出现这些错误。

**示例1：不规范用法**

```cpp
int main_bad(void)
{
    int i = 0;
    int j;
    // ......
    if (0 == i) // Cobot报在此处
        j = 1; // not-1
    else if (1 == i) // Cobot报在此处
        j = 3; // not-2
    else // Cobot报在此处
        j = 5; // not-3
    return 0;
}
```

**示例1：规范用法之一**

```cpp
int main_good(void)
{
    int i = 0;
    int j;
    // ......
    if (0 == i)
    {
        j = 1; // ok-1
    }
    else if (1 == i)
    {
        j = 3; // ok-2
    }
    else
    {
        j = 5; // ok-3
    }
    return 0;
}
if，else if，else用大括号括起来。
```

### MISRA_CPP_2008_06_04_02_rule　所有的 if ... else if 结构应该由 else 子句结束
> 等级：**强制**　分类：语句

当 if 语句后面跟着一个或多个 else if 语句时，最后一个 else if 应后跟一个 else 语句。对于简单的 if 语句，可以不包含 else 语句。最后的 else 语句应采取适当的行动或包含适当的注释，说明为什么没有采取任何行动，这是防御性编程要求。

**示例1：不规范用法**

```cpp
void foo(int a)
{
if(a > 0)
{
}
else if (a > 10) // Violation
{
}
}
```

### MISRA_CPP_2008_06_04_03_rule　switch 语句应该是一个格式规范的 switch 语句
> 等级：**强制**　分类：语句

C++ 中 switch 语句的语法比较弱，允许出现复杂、无结构的行为。

**示例1：不规范用法**

```cpp
void foo( int a, int b ) {
switch(a) {
case 1:
{
case 6: /* 违规 */
;
default: /* 违规 */
break;
}
break;
case 2:
if (b == 1) {
case 3: /* 违规 */
break;
}
break;
}
}
```

**示例1：规范用法之一**

```cpp
switch (x)
{
case 0:
    ...
    break; // break is required here
case 1: // empty clause, break not required
case 2:
    break; // break is required here
default: // default clause is required
    break; // break is required here, in case a future
    // modification turns this into a case clause
}
```

### MISRA_CPP_2008_06_04_04_rule　switch-标签应该只能用在当紧接着的复合语句是 switch 语句体的时候
> 等级：**强制**　分类：语句

switch-label 可以放置在构成 switch 语句主体的语句的任何位置，这可能会导致无结构的代码。为了防止发生这种情况，case-label 或 default-label 的范围应该是形成 switch 语句主体的复合语句，所有 case-clauses 和 default-clause 应该在同一个作用域内。

**示例1：不规范用法**

```cpp
void foo( int a, int b ) {
switch(a) {
case 1:
{
case 6: /* 违规 */
;
default: /* 违规 */
break;
}
break;
case 2:
if (b == 1) {
case 3: /* 违规 */
break;
}
break;
}
}
```

**示例1：规范用法之一**

```cpp
switch (x)
{
case 0:
    ...
    break; // break is required here
case 1: // empty clause, break not required
case 2:
    break; // break is required here
default: // default clause is required
    break; // break is required here, in case a future
    // modification turns this into a case clause
}
```

### MISRA_CPP_2008_06_04_05_rule　每一个非空的 switch-clause 应该以一个无条件的 throw 或 break 语句结束
> 等级：**强制**　分类：语句

如果开发人员未在 switch-clause 的末尾添加 break 语句，则控制流会“落入”后续的 switch-clause 中。虽然这有时是有意的，但通常是错误的。
为确保能检测到这种错误，每个 switch-clause 的最后一个语句应该是 break 语句，或者如果 switch-clause 是一个复合语句，则复合语句的最后一个语句应该是 break 语句。
如果 switch-clause 为空，则存在一种特殊情况，因为这允许创建需要相同语句的多个 clause 组。

**示例1：不规范用法**

```cpp
switch (x)
{
case 0:
    break; // Compliant
case 1: // Compliant - empty drop through
case 2: // allows a group
    break; // Compliant
case 3:
    throw; // Compliant
case 4:
    a = b; // Non-compliant - non empty drop through
default:; // Non-compliant – default must also have "break"
}
```

**示例1：规范用法之一**

```cpp
switch (x)
{
case 0:
    ...
    break; // break is required here
case 1: // empty clause, break not required
case 2:
    break; // break is required here
default: // default clause is required
    break; // break is required here, in case a future
    // modification turns this into a case clause
}
```

### MISRA_CPP_2008_06_04_06_rule　switch 语句的最后子句应该是 default-子句
> 等级：**强制**　分类：语句

switch 语句需要一个最终的 default-clause，此 clause 应采取适当的行动，或包含适当的注释，说明为什么没有采取任何行动。
如果switch 语句的条件是 enum 类型，并且所有枚举值都在 case 标签中列出例外。

**示例1：不规范用法**

```cpp
enum Colours { RED, BLUE, GREEN } colour;
void foo(int i)
{
switch( i ) // 违规
{
case 0:
break;
case 1:
case 2:
break;
}
switch( colour ) // 违规
{
case RED:
break;
case GREEN:
break;
}
switch( colour ) // OK
{
case RED:
break;
case BLUE:
break;
case GREEN:
break;
}
}
```

### MISRA_CPP_2008_06_04_07_rule　switch 语句的条件不得含有布尔类型
> 等级：**强制**　分类：语句

if 语句给出了布尔选择的更清晰表示。

**示例1：不规范用法**

```cpp
void foo(int i)
{
switch(i == 0) // 违规
{
case 0 : break;
default:;
}
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_06_04_08_rule　每个 switch 语句应该至少有一个 case-clause
> 等级：**强制**　分类：语句

没有 case-clauses 的 switch 语句是多余的。

**示例1：不规范用法**

```cpp
switch (x)
{
// Non-compliant
default:
    break;
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_06_05_01_rule　for 循环应该包含一个没有浮动类型的单一的循环计数器
> 等级：**强制**　分类：语句

没有循环计数器的for循环就是while循环。如果这是期望的行为，则while循环更合适。

**示例1：不规范用法**

```cpp
#include <iostream>
#include <string>
using namespace std;
int main()
{
    int y = 0;
    for(int i = 0; i < 10; i++){}
    for(int i = 0; i < y; i = y++){} //not compliant
    for(int i =0; i < y; i++) //not compliant
    {
        y++;
    }
    int j = 0;
    for(j =0; j < y; j++) //not compliant
    {
        y = 20;
    }
    return 0;
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_06_05_02_rule　如果循环计数器不是被 -- 或 ++ 修改，那么在条件中此循环计数器应该只能被用作 <=, <, > or >= 的操作数
> 等级：**强制**　分类：语句

当使用除--或++之外的运算符修改循环计数器时，则不得使用==和!=，因为循环终止可能不会发生，这可能与开发人员的期望不一致。

**示例1：不规范用法**

```cpp
#include<iostream>
using namespace std;

int main()
{
    int i = 0;
    for(i = 0; i != 10; i++)
    {
    }
    for(i = 0; i != 10; i += 2) //not compliant
    {
    }
    for(int j = 0; j != 10; j += 2) //not compliant
    {
    }
	return 0;
}
```

**示例1：规范用法之一**

```cpp
for (i = 0; i < 10; i += 2) // Compliant
{
}
for (i = 0; i < 10; ++i) // Compliant
{
}
```

### MISRA_CPP_2008_06_05_03_rule　循环计数器不得在判定条件或循环体语句中被修改
> 等级：**强制**　分类：语句

除了在表达式中进行修改，修改循环计数器会导致形成错误的for循环。

**示例1：不规范用法**

```cpp
#include<iostream>
using namespace std;
int modify(int *x)
{
	return *x;
}

int main()
{
	int x, y, z;
	for(x = 0; modify(&x);) //not compliant
	{

	}
	for(x = 0; x < 10;) //not compliant
	{
 x = x * 2;
	}
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_06_05_04_rule　循环计数器应该被 --, ++, -=n, 或 +=n 之一修改；这里的 n 在整个循环期间保持不变
> 等级：**强制**　分类：语句

这有助于确保确定性循环终止，其他for循环规则意味着修改只能在表达式中进行。

**示例1：不规范用法**

```cpp
#include<iostream>
using namespace std;
int fun()
{
	return 1;
}

int main()
{
	int x, n;
	for(x = 0; x < 10; ++x) { }
	for(x = 0; x < 10; x += 1) { }
	for(x = 0; x < 10; x += n) { }
	for(x = 0; x < 10; x += fun())	//not compliant
	for(x = 0; x < 10; fun()) //not compliant
	return 0;
}
```

### MISRA_CPP_2008_06_05_05_rule　循环控制变量除循环计数器外，在条件或表达式中不得被修改。
> 等级：**强制**　分类：语句

循环控制变量是循环终止的标志，如果这些变量在条件或表达式中被修改，则代码不易于理解。
注意：volatile的循环控制变量可能在语句外更改值，这种修改不违反此规则。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
try
	{
 throw(0);
	}
	catch(int ie){}
	catch(...){} //compliant

	try
	{
 throw(0);
	}
	catch(int ie) //Not compliant
	{}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_06_05_06_rule　除循环计数器外，在语句中修改的循环控制变量应具有bool类型
> 等级：**强制**　分类：语句

循环控制变量通常用于尽早终止for循环，如果是布尔值，则代码易于理解。

**示例1：不规范用法**

```cpp
for (x = 0; (x < 10) && (u8a != 3U); ++x) // Non-compliant
{
    uint8_a = fn();
}
```

**示例1：规范用法之一**

```cpp
for (x = 0; (x < 10) && flag; ++x) // Compliant
{
    u8a = fn();
    flag = u8a != 3U;
}
```

### MISRA_CPP_2008_06_06_01_rule　goto语句引用的任何标签应在同一块中声明，或在包含goto语句的块中声明
> 等级：**强制**　分类：语句

对goto的无限制使用可能导致程序极难理解、分析，并且对于C++来说，还可能导致程序展现未指定的行为。
完全禁止goto需要引入标志来确保正确的控制流，可能这些标志本身比他们取代的goto不透明, 因此，允许受限制的goto使用。
禁止跳入嵌套块，这会导致复杂的流程图。

**示例1：不规范用法**

```cpp
void f1()
{
    int32_t j = 0;
    goto L1;
    for (j = 0; j < 10; ++j)
    {
    L1: // Non-compliant
        j;
    }
}
```

**示例1：规范用法之一**

```cpp
void f2()
{
    for (int32_t j = 0; j < 10; ++j)
    {
        for (int32_t i = 0; i < 10; ++i)
        {
            goto L1;
        }
    }
L1: // Compliant
    f1();
}
```

### MISRA_CPP_2008_06_06_02_rule　goto语句应跳转到同一函数体中稍后声明的标签
> 等级：**强制**　分类：语句

对goto的无限制使用可能导致程序极难理解、分析，并且对于C++来说，还可能导致程序展现未指定的行为。
完全禁止goto需要引入标志来确保正确的控制流，可能这些标志本身比他们取代的goto不透明, 因此，允许受限制的goto使用。
禁止后退跳转，这会导致复杂的流程图。

**示例1：不规范用法**

```cpp
void f()
{
    int32_t j = 0;
L1:
    ++j;
    if (10 == j)
    {
        goto L2; // Compliant
    }
    goto L1; // Non-compliant
L2:
    ++j;
}
```

**示例1：规范用法之一**

```cpp
void f2()
{
    for (int32_t j = 0; j < 10; ++j)
    {
        for (int32_t i = 0; i < 10; ++i)
        {
            goto L1;
        }
    }
L1: // Compliant
    f1();
}
```

### MISRA_CPP_2008_06_06_03_rule　continue语句只应在格式正确的for循环中使用
> 等级：**强制**　分类：语句

过度使用continue语句可能会导致代码中出现不必要的复杂性。由于控制流依赖关系，所需的测试可能无法实现。格式正确的for循环是指满足规则6-5-1到规则6-5-6的循环。

**示例1：不规范用法**

```cpp
void fn()
{
    int32_t j = -1;
    for (int32_t i = 0; i != 10 && j != i; ++i)
    {
        if ((i % 2) == 0)
        {
            continue; // Non-compliant – loop is not well-formed
        }
        // ...
        ++j;
    }
}
```

**示例1：规范用法之一**

```cpp
void fn()
{
    for (int32_t i = 0; i != 10; ++i)
    {
        if ((i % 2) == 0)
        {
            continue; // Compliant
        }
        // ...
    }
}
```

### MISRA_CPP_2008_06_06_04_rule　对于任何迭代语句不得有超过一个用于循环终止的 break 或 goto 语句
> 等级：**强制**　分类：语句

对于任何迭代语句不得有超过一个用于循环终止的 break 或 goto 语句

**示例1：不规范用法**

```cpp
#include <math.h>
#include <stdio.h>
int main()
{
    int i;
   for(i=1;i<10;i++)
	{
 if(i==1)
 {
                        break; //not compliant
                        continue;
        }
 else if(i==5)
 {
 break; //not compliant
 }
 printf("Number=%d\n",i);
	}

}
```

**示例1：规范用法之一**

```cpp
#include <math.h>
#include <stdio.h>
int main()
{
    int i;
   for(i=1;i<10;i++)
	{
 if(i==1)
 {
                        continue;
        }
 else if(i==5)
 {
 break;
 }
 printf("Number=%d\n",i);
	}

}
第[6]的for循环中使用了第[14]行1个break语句
```

### MISRA_CPP_2008_06_06_05_rule　一个函数应该在函数末尾有单一的出口点
> 等级：**强制**　分类：语句

原理：这是IEC 61508 [12]的要求之一，是模块化方法的要求之一。
例外：实现函数try块的函数允许具有多个出口点，一个是try块，每个catch处理程序一个。在函数内部未捕获的抛出异常不视为此规则的出口点。

**示例1：不规范用法**

```cpp
void foo(){
int a;
for(a=0;a<10;a++){
if(a==5)}
nreak;
}
if(a==7)}
nreal;}
]
```

---

## 第 7 章 声明（16 条）

### MISRA_CPP_2008_07_01_01_rule　未修改的变量应具有const限定符
> 等级：**强制**　分类：声明

如果一个变量不需要被修改，则应声明为带有const限定符，以便它不能被修改。
非参数变量将需要在声明点进行初始化，避免未来的维护时意外修改该值。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
void b(int32_t *);
int32_t f(int32_t *p1, // Non-compliant
          int32_t *const p2, // Compliant
          int32_t *const p3) // Compliant
{
    *p1 = 10;
    *p2 = 10;
    b(p3);
    int32_t i = 0; // Non-compliant
    return i;
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_07_01_02_rule　如果相应的对象未被修改，函数中的指针或引用需声明为指向const的指针或引用
> 等级：**强制**　分类：声明

const限定符应应用于所指向的对象，而不是指针本身，此规则确保函数接口定义更加精确。
例外：如果一组重载函数中的任何函数修改了参数对象，则不适用此规则。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
void myfunc(int16_t *param1,
            const int16_t *param2,
            int16_t *param3,
            int16_t *const param4)
// param1: Addresses an object which is modified - Compliant
// param2: Addresses an object which is not modified – Compliant
// param3: Addresses an object which is not modified – Non-compliant
// param4: Addresses an object which is not modified – Non-compliant
{
    *param1 = *param2 + *param3 + *param4;
    // Data at address param3 and param4 have not been changed
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_07_02_01_rule　含有枚举基础类型的表达式仅应具有与枚举对应的值
> 等级：**强制**　分类：声明

如果枚举类型的表达式的计算产生未对应于枚举的值，则这是未指定的行为。
此外，标准中的其他规则假定枚举类型的对象仅包含与枚举对应的值，此规则确保这些假设的有效性。

**示例1：不规范用法**

> 原文未给出该类型的独立示例。

**示例1：规范用法之一**

```cpp
enum1 convert(int16_t v)
{
    enum1 result = enum1_ERROR;
    switch (v)
    {
    case 0:
    {
        result = enum1_E1;
        break;
    }
    case 1:
    {
        result = enum1_E2;
        break;
    }
    default:
    {
        throw(ENUM_ERROR);
        break;
    }
    }
    return result;
}
```

### MISRA_CPP_2008_07_03_01_rule　全局命名空间应只包含main函数、命名空间声明和extern“C”声明
> 等级：**强制**　分类：声明

将名称声明到适当的命名空间中能提高查找效率，确保找到的名称符合开发人员的期望。

例外：为符合规则 3-9-2 而定义的类型也可以位于全局命名空间中。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
void f1(int32_t); // Non-compliant
int32_t x1; // Non-compliant
namespace
{
    void f2(int32_t); // Compliant
    int32_t x2; // Compliant
}
void f1(int32_t); // Non-compliant
int32_t x1; // Non-compliant
namespace
{
    void f2(int32_t); // Compliant
    int32_t x2; // Compliant
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_07_03_02_rule　标识符main不应用于除全局函数main之外的函数
> 等级：**强制**　分类：声明

main通常是程序的入口点，并且是必须在全局命名空间中的唯一标识符。将main用于其他函数可能不符合开发人员的期望。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
int32_t main() // Compliant
{
}
namespace
{
    int32_t main() // Non-compliant
    {
    }
}
namespace NS
{
    int32_t main() // Non-compliant
    {
    }
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_07_03_03_rule　头文件中不应有未命名的命名空间
> 等级：**强制**　分类：声明

未命名的命名空间在每个翻译单元中都是唯一的。在头文件中出现的任何声明都可能引用每个翻译单元中的不同实体，这与开发人员的期望可能不一致。

**示例1：不规范用法**

```cpp
// Header.hpp
namespace // Non-compliant
{
    extern int32_t x;
}
// File1.cpp
#include "Header.hpp"
namespace
{
    int32_t x;
}
void fn_a(void)
{
    x = 24;
}
// File2.cpp
#include "Header.hpp"
namespace
{
    int32_t x;
}
void fn_b(void)
{
    fn_a();
    if (x == 24) // This x will not have been initialized.
    {
    }
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_07_03_04_rule　不应使用using-directives
> 等级：**强制**　分类：声明

using-directives将附加作用域添加到名称查找期间搜索的作用域集中。
这些作用域中的所有标识符都变得可见，增加了编译器找到的标识符不符合开发人员期望的可能性。
使用声明或完全限定名称将名称集合限制为仅显式指定的名称，是更安全的选项。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
namespace NS1
{
    int32_t i1;
    int32_t j1;
    int32_t k1;
}
using namespace NS1; // Non-compliant
namespace NS2
{
    int32_t i2;
    int32_t j2;
    int32_t k2;
}
using NS2::j2; // Compliant
namespace NS3
{
    int32_t i3;
    int32_t j3;
    int32_t k3;
}
void f()
{
    ++i1;
    ++j2;
    ++NS3::k3;
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_07_03_05_rule　同一命名空间中标识符的多个声明不得跨越该标识符的using-declaration
> 等级：**强制**　分类：声明

使用声明引入的标识符集不包括可能在命名空间中后续声明中添加的任何声明。任何后续声明都将无法通过using-declaration找到，这可能与开发人员的期望不一致。

**示例1：不规范用法**

```cpp
namespace NS1
{
    void f(uint16_t); // Example 1
}
using NS1::f;
namespace NS1
{
    void f(uint32_t); // Example 2 – Non-compliant
}
void bar()
{
    f(0U);
}
// 将using-declaration移动到第二个命名空间下方会导致Example 2被调用，因为它比Example 1更符合要求
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_07_03_06_rule　头文件中不得使用using-directives和using-declarations（不包括类作用域或函数作用域的using-declarations）
> 等级：**强制**　分类：声明

确保头文件的包含顺序不会影响程序的行为。

**示例1：不规范用法**

```cpp
// f1.h
void foo(char_t a);
namespace NS1
{
    void foo(int32_t a);
}
inline void bar()
{
    foo(0);
}
// f2.h
namespace NS1
{
}
using namespace NS1;
// f1.cc
#include "f1.h"
#include "f2.h"
int32_t m1()
{
    bar(); // bar calls foo ( char_t );
}
// f2.cc
#include "f2.h"
#include "f1.h"
void m2()
{
    bar(); // bar calls foo ( int32_t );
}
// 改变头文件的顺序会改变程序的含义
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_07_04_01_rule　应记录所有汇编语言的使用
> 等级：**文档**　分类：声明

汇编语言代码是实现定义的，因此不可移植。

> 原文未给出该条的代码示例。

### MISRA_CPP_2008_07_04_02_rule　汇编指令只能使用asm声明引入
> 等级：**强制**　分类：声明

asm声明对所有C++实现都可用，允许使用一致的机制。但是，asm的参数仍然是实现定义的。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
void Delay_a(void)
{
    asm("NOP"); // Compliant
}
void Delay_b(void)
{
#pragma asm
    "NOP" // Non-compliant
#pragma endasm
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_07_04_03_rule　汇编语言应该被封装和隔离
> 等级：**强制**　分类：声明

确保汇编语言代码被封装和隔离有助于可移植性。如果需要汇编语言指令，则应将其封装和隔离在汇编器函数或C++函数中。

**示例1：不规范用法**

```cpp
void static_p(void)
{
    unsigned int x;
    x = 0u;
    _asm
    {
        mov eax, x
    }
}
```

**示例1：规范用法之一**

```cpp
void static_p(void)
{
    unsigned int x;
    x = 0u;
   /* _asm
    {
        mov eax, x
    }*/
}
将原位置的汇编语言删掉或注释掉，根据需要将汇编语言进行封装。
```

### MISRA_CPP_2008_07_05_01_rule　函数不得返回一个指向定义在函数中自动变量的引用或指针(包括参数)
> 等级：**强制**　分类：声明

自动变量在函数调用结束时被销毁。返回对这样的变量的引用或指针允许在其销毁后使用它，导致未定义的行为。

**示例1：不规范用法**

```cpp
int& fun()
{
    int a;
    return a; //not compliant
}
```

**示例1：规范用法之一**

```cpp
int32_t* fn5(void)
{
    static int32_t x = 0;
    return &x; // Compliant
}
```

### MISRA_CPP_2008_07_05_02_rule　不应将具有自动存储的对象的地址分配给可能在第一个对象不存在后继续存在的另一个对象
> 等级：**强制**　分类：声明

如果将自动对象的地址分配给更大范围的另一个自动对象或静态对象，或从函数返回，则包含该地址的对象可能在原始对象停止存在后访问无效地址。
注意，将指向具有自动存储的对象的指针抛出也违反此规则。

**示例1：不规范用法**

```cpp
void foobar(void)
{
    int8_t *p1;
    {
        int8_t local_auto;
        p1 = &local_auto; // Non-compliant
    }
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_07_05_03_rule　函数不得返回一个指向通过引用或 const 引用传递参数的引用或指针
> 等级：**强制**　分类：声明

引用参数是临时对象还是参数的引用是实现定义的行为，如果是临时对象，函数返回时将销毁此对象，尝试在其销毁后使用此类对象的操作会导致未定义的行为。

**示例1：不规范用法**

```cpp
int32_t *fn1(int32_t &x)
{
    return (&x); // Non-compliant
}
int32_t *fn2()
{
    int32_t i = 0;
    return fn1(i);
}
const int32_t *fn3(const int32_t &x)
{
    return (&x); // Non-compliant
}
int32_t &fn4(int32_t &x)
{
    return (x); // Non-compliant
}
const int32_t &fn5(const int32_t &x)
{
    return (x); // Non-compliant
}
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_07_05_04_rule　函数不得调用它们本身，无论是直接或间接
> 等级：**推荐**　分类：声明

无限递归可能导致堆栈溢出，并可能影响系统时间。这也适用于迭代算法。

**示例1：不规范用法**

```cpp
void foo_B();

void foo_A()
{
	foo_B();//函数[foo_A]调用了函数[foo_B]，在函数[foo_B]调用了函数[foo_A]，存在循环调用关系。
}
void foo_B()
{
	foo_A();//函数[foo_A]调用了函数[foo_B]，在函数[foo_B]调用了函数[foo_A]，存在循环调用关系。
}
int main()
{
	foo_A();
  	return 0;
}
```

**示例1：规范用法之一**

```cpp
void foo_B();

void foo_A()
{
     if(...) //增添合适的调用条件检查
	foo_B();
}
void foo_B()
{
     if(...) //增添合适的调用条件检查
	foo_A();
}
int main()
{
	foo_A();
  	return 0;
}
函数循环调用中存在调用条件检查。
```

---

## 第 8 章 声明符（9 条）

### MISRA_CPP_2008_08_00_01_rule　初始声明列表或成员声明列表应该分别由单一的初始声明或成员声明组成
> 等级：**强制**　分类：声明符

在同一声明中出现多个声明符时，标识符的类型可能不符合开发人员的期望。

**示例1：不规范用法**

```cpp
void foo( )
{
	int* a, b; // 违规
}
```

**示例1：规范用法之一**

```cpp
void foo( )
{
	int* a; // ok
    int* b;
}
每个变量单独在一行声明。
```

### MISRA_CPP_2008_08_03_01_rule　在重载的虚函数中的参数应该使用同他们所覆盖的函数一样缺省的实参，否则不得指定任何缺省实参
> 等级：**强制**　分类：声明符

默认参数由对象的静态类型确定。如果在覆盖函数的参数中使用不同的默认参数，则通过基对象或派生对象进行调用时将使用不同的值，这可能与开发人员的期望相反。

**示例1：不规范用法**

```cpp
class A{
    public:
    virtual int fun(int a = 0);
};
class B: public A{
    public:
    virtual int fun(int a = 3); // not compliant
};
class C:public A{
    public:
    virtual int fun(int a);
};
```

**示例1：规范用法之一**

```cpp
class A{
    public:
    virtual int fun(int a = 3);
};
class B: public A{
    public:
    virtual int fun(int a = 3); // Compliant
};
class C:public A{
    public:
    virtual int fun(int a);
};
将[A]中定义的虚拟函数[fun]的参数[a]的缺省值改为[3]，或者将[B]中定义的虚拟函数虚拟函数[fun]的参数[a]的缺省值改为[0]。
```

### MISRA_CPP_2008_08_04_01_rule　函数不得使用省略符号定义
> 等级：**强制**　分类：声明符

通过省略号传递参数将绕过编译器执行的类型检查。

**示例1：不规范用法**

```cpp
unsigned int static_p(unsigned char *p_1, ...)
{
    /*...*/
    return 1u;
}
```

**示例1：规范用法之一**

```cpp
unsigned int static_p(unsigned char *p_1)
{
    /*...*/
    return 1u;
}
函数定义禁止带有可变参数。
```

### MISRA_CPP_2008_08_04_02_rule　用于参数的标识符在函数的重声明中应该和声明中的相同
> 等级：**强制**　分类：声明符

参数名称有助于在函数体内记录参数的目的。如果在后续的重新声明中重命名函数参数，则为同一对象使用不同的名称可能会导致开发人员混淆。

例外：如果声明或重新声明中包含未命名参数，则不视为违反本规则。

**示例1：不规范用法**

```cpp
int fun(int a, int b);
int fun2(int b, int a); //not compliant
```

**示例1：规范用法之一**

```cpp
// File1
void fn2(int32_t);

// File2
void fn2(int32_t b); // Compliant —— 首次声明使用未命名参数，属本规则的例外
```

### MISRA_CPP_2008_08_04_03_rule　非 void 返回类型函数的所有退出路径应该有显式表达式的返回语句
> 等级：**强制**　分类：声明符

没有带表达式的返回会导致未定义行为（且编译器可能不会报错）。
例外：如果函数退出是由于异常处理（即throw语句），则不适用此规则。

**示例1：不规范用法**

```cpp
#include <stdio.h>
#include <string.h>

int mystrlen(char *src)
{
    //... //非空函数没有返回语句

}

int main(int argc, char *argv[])
{
    mystrlen("hello");
    return 0;
}
```

**示例1：规范用法之一**

```cpp
#include <stdio.h>
#include <string.h>

int mystrlen(char *src)
{
    //...
    return strlen(src); //添加应有的返回语句
}

int main(int argc, char *argv[])
{
    mystrlen("hello");
    return 0;
}
第[7]行，对非空函数[mystrlen]增加返回语句。
```

### MISRA_CPP_2008_08_04_04_rule　函数标识符只能用来调用函数或之前应加&
> 等级：**强制**　分类：声明符

函数标识符可以隐式转换为函数指针，在某些情况下，这可能会会与开发人员的期望相反。
例如， if (f) 可能是测试函数地址是否为NULL， 也可能是调用函数f()并无意中省略了括号，使用&（取地址）运算符将解决此歧义。
例外：通过引用传递函数或将其分配给引用对象不违反此规则。

**示例1：不规范用法**

```cpp
#include <stdlib.h>
int fun(int para1, int para2);
int main(void)
{
    int a = 2, b = 1, c = 0;

    if (NULL == fun) // not-1
    {
        return -1;
    }
    else
    {
        int(*p)(int, int) = fun; // not-2
        c = p(a, b);
    }

    return 0;
}
int fun(int para1, int para2)
{
    return (para1 - para2);
}
```

**示例1：规范用法之一**

```cpp
#include <stdlib.h>
int fun(int para1, int para2);
int main(void)
{
    int a = 2, b = 1, c = 0;

    if (NULL == &fun) // ok-1
    {
        return -1;
    }
    else
    {
        int(*p)(int, int) = &fun; // ok-2
        c = p(a, b);
    }

    return 0;
}
int fun(int para1, int para2)
{
    return (para1 - para2);
}
第(7)行和第(13)行加前缀&使用函数标识符。
```

### MISRA_CPP_2008_08_05_01_rule　所有变量在使用之前都应有定义的值
> 等级：**强制**　分类：声明符

此规则要求变量在读取之前有定义的值，这不意味着一定要在声明时初始化。
注意，根据ISO/IEC 14882:2003[1]，静态变量默认情况下会自动初始化为零，除非明确初始化。实际上，许多嵌入式环境不实现此行为。
类的每个构造函数都应初始化其类的所有非静态成员。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
class C
{
public:
    C() : m_a(10), m_b(7) // Compliant
    {
    }
    C(int32_t a) : m_a(a) // Non-compliant
    {
    }
    int32_t GetmB(void)
    {
        return (m_b);
    }


private:
    int32_t m_a;
    int32_t m_b;
};
C c(5);
int main(void)
{
    if (c.GetmB() > 0) // m_b has not been initialized
    {
    }
}
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_08_05_02_rule　括号应该被用于指明和匹配在数组和结构体的非零初始化中的结构
> 等级：**强制**　分类：声明符

ISO/IEC 14882:2003 [1]要求将数组、结构和联合类型的初始化器列表封闭在一对大括号中（不这样做的行为将是未定义的）。
此规则进一步要求使用大括号来表示嵌套结构，迫使开发人员明确考虑复杂数据类型的初始化顺序（例如，多维数组）。
数组或结构体的零初始化仅适用于顶级，数组或结构体的非零初始化需要将每个元素显式进行初始化。

**示例1：不规范用法**

```cpp
int y[3][2] = { 1, 2, 3, 4, 5, 6 }; // Violation
struct S {
int i;
struct T {
int j;
}t;
} s = {1, 2}; // Violation
```

**示例1：规范用法之一**

```cpp
int16_t a1[5] = { 1, 2, 3, 0, 0 }; // Non-zero initialization
int16_t a2[5] = { 0 }; // Zero initialization
int16_t a3[2][2] = { }; // Zero initialization
```

### MISRA_CPP_2008_08_05_03_rule　在枚举成员列表中，不得使用 = 结构显式地初始化除第一个以外的成员，除非所有项目都显式地被初始化
> 等级：**强制**　分类：声明符

在枚举成员列表中，不得使用 = 结构显式地初始化除第一个以外的成员，除非所有项目都显式地被初始化

**示例1：不规范用法**

```cpp
enum colour { red = 3, blue, green, yellow = 5 } ; /* not compliant */
```

**示例1：规范用法之一**

```cpp
enum colour { red = 3, blue = 4, green = 4, yellow = 5 } ; /* compliant */
为枚举colour的所有元素显示的赋值
```

---

## 第 9 章 类（8 条）

### MISRA_CPP_2008_09_03_01_rule　const 成员函数不得返回指向类数据成员的非 const 指针或引用
> 等级：**强制**　分类：类

当使用const类型声明对象时，只能在该对象上调用const成员函数，期望在调用函数时不能修改对象的状态。但是，从const函数返回的非const指针或引用允许修改对象的数据状态。

**示例1：不规范用法**

```cpp
class Test{
public:
  Test(int & p) : _i(p)
  {
      _k = new int; // makes data pointed by _k a "class-data"
  }

  int* GetI1() const
  {
      return &_i; // 违规
  }
protected:
  int& GetI2() const
  {
      return _i; // 违规
  }
  int * GetI3() const
  {
      return _k; // 违规
  }
private:
  int & _i;
  int * _k;
};

class Child: public Test
{
public:
  Child() : Test(z)
  {

  }
  void foo() const
  {
      GetI2() = 0; // Modification of possibly-const object
      *(GetI3()) = 0; // Modification of possibly-const object
  }
private:
  int z;
};

void bar()
{
    const Child c;
    *(c.GetI1()) = 0; // Modification of possibly-const object
}

```

**示例1：规范用法之一**

```cpp
class Test{
public:
  Test(int & p) : _i(p)
  {
      _k = new int; // makes data pointed by _k a "class-data"
  }

  int* GetI1() const
  {
      return &_i; // ok
  }
protected:
  int& GetI2() const
  {
      return _i; // ok
  }
  int * GetI3() const
  {
      return _k; // ok
  }
private:
  const int & _i;
  const int * _k;
};
```

### MISRA_CPP_2008_09_03_02_rule　成员函数不应返回对类数据的非const句柄
> 等级：**强制**　分类：类

通过使用成员函数实现类接口，可以保留对修改对象状态的控制，并有助于使类的维护。返回对类数据的句柄允许客户端修改对象的状态而不使用任何接口。

**示例1：不规范用法**

```cpp
class C
{
public:
    int32_t &getA() // Non-compliant
    {
        return a;
    }


private:
    int32_t a;
};
void b(C &c)
{
    int32_t &a_ref = c.getA();
    a_ref = 10; // External modification of private C::a
}
```

**示例1：规范用法之一**

```cpp
class C
{
public:
    C(int32_t *shared) : m_shared(shared)
    {
    }
    int32_t *getA()
    {
        return m_shared; // Compliant - m_shared is not class-data
    }


private:
    int32_t *m_shared;
};
```

### MISRA_CPP_2008_09_03_03_rule　需要将成员函数尽量定义为static或const
> 等级：**强制**　分类：类

将成员函数声明为static或const会限制对非静态数据成员的访问，避免意外修改数据，并有助于符合规则7-1-1。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
class A
{
public:
    int16_t f1() // Non-compliant – can be const
    {
        return m_i;
    }
    int16_t f2() // Non-compliant – can be static
    {
        return m_s;
    }
    int16_t f3() // Compliant – cannot be const or static
    {
        return ++m_i;
    }


private:
    int16_t m_i;
    static int16_t m_s;
};
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_09_05_01_rule　不得使用联合体(union)
> 等级：**强制**　分类：类

使用联合体以不同的方式访问对象可能会导致数据被错误解释。因此，该规则禁止使用联合体。
有的情况下可以谨慎使用联合体，前提是文档记录了所有相关的行为。

**示例1：不规范用法**

```cpp
union static_p{float fu; unsigned int xu;};
void dummy(void)
{
    /*...*/
}
```

**示例1：规范用法之一**

```cpp
//union static_p{float fu; unsigned int xu;};
void dummy(void)
{
    /*...*/
}
谨慎使用联合（union）的声明。
```

### MISRA_CPP_2008_09_06_01_rule　如果需要绝对定位表示位字段的位，则必须记录位字段的行为和填充方式
> 等级：**文档**　分类：类

位字段的某些行为是实现定义的，需要谨慎使用：
• 从存储单元（通常一个字节）的高端或低端分配位字段。
• 位字段是否可以重叠存储单元边界。
如果位字段的绝对位置很重要（例如访问硬件寄存器时），就可能导致错误。

**示例1：不规范用法**

```cpp
struct message // Struct is for bit-fields only
{
    signed int little : 4; // Note: use of basic types is required
    unsigned int x_set : 1;
    unsigned int y_set : 1;
} message_chunk;
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_09_06_02_rule　位字段应该是bool类型，无符号或有符号整数类型
> 等级：**强制**　分类：类

int是实现定义的，int类型的位字段可以是有符号或无符号的。
禁止使用wchar_t作为位字段类型，因为ISO/IEC 14882:2003 [1]没有明确定义有符号或无符号。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
struct S
{
    signed int a : 2; // Compliant
    unsigned int b : 2; // Compliant
    char c : 2; // Non-compliant
    signed char d : 2; // Compliant
    unsigned char e : 2; // Compliant
    short f : 2; // Non-compliant
    signed short g : 2; // Compliant
    unsigned short h : 2; // Compliant
    int i : 2; // Non-compliant
    bool j : 2; // Compliant
    wchar_t k : 2; // Non-compliant
    uint32_t l : 2; // Compliant
    int8_t m : 2; // Compliant
};
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_09_06_03_rule　位字段不能有枚举类型
> 等级：**强制**　分类：类

禁止将枚举用作位字段类型，因为ISO/IEC 14882:2003 没有明确将其定义有符号或无符号。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
struct S
{
    signed int a : 2; // Compliant
    unsigned int b : 2; // Compliant
    char c : 2; // Non-compliant
    signed char d : 2; // Compliant
    unsigned char e : 2; // Compliant
    short f : 2; // Non-compliant
    signed short g : 2; // Compliant
    unsigned short h : 2; // Compliant
    int i : 2; // Non-compliant
    bool j : 2; // Compliant
    wchar_t k : 2; // Non-compliant
    uint32_t l : 2; // Compliant
    int8_t m : 2; // Compliant
};
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_09_06_04_rule　具有带符号整数类型的位字段长度应大于一个位
> 等级：**推荐**　分类：类

长度为1的位字段可以表示的值可能不符合开发者的期望。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
struct S
{
    signed int a : 1; // Non-compliant
    signed int : 1; // Compliant
    signed int : 0; // Compliant
    signed int b : 2; // Compliant
    signed int : 2; // Compliant
};
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

---

## 第 10 章 派生类（7 条）

### MISRA_CPP_2008_10_01_01_rule　类不得从虚基类派生而来
> 等级：**推荐**　分类：派生类

使用虚基类可以引入许多未定义的和潜在混乱的行为，不建议使用虚基类。

**示例1：不规范用法**

```cpp
#include <iostream>
using namespace std;
class A{
	public:
	void func();
};
class B:public virtual A	//not compliant
{
};
```

### MISRA_CPP_2008_10_01_02_rule　被用于菱形派生的基类应该被声明为虚基类
> 等级：**强制**　分类：派生类

使用虚基类可以引入许多未定义的和潜在混乱的行为。因此，只有当该基类用作钻石层次结构中的公共基类时，才应将其声明为虚拟基类。

**示例1：不规范用法**

```cpp
#include<iostream>
using namespace std;
class A
{
public:
  A(void);
  void SetA(int);
private:
  int a;
};

A::A(void):a(0)
{}

void A::SetA(int va)
{
	a=va;
}

class B1:public A //not
 /* class B1:public virtual A */
{
public:
  B1(void);
  void SetB1(int);
private:
  int b1;
};

B1::B1(void):A(),b1(0)
{
}
void B1::SetB1(int vb)
{
  b1=vb;
  SetA(b1+1);
}

class B2:public A //not
/* class B2:public virtual A */
{
public:
  B2(void);
  void SetB2(int);
private:
  int b2;
};

B2::B2(void):A(),b2(0)
{}

void B2::SetB2(int vb)
{
	b2=vb;
    SetA(b2+2);
}

class D:public B1,public B2
{
public:
  D(void);
private:
  int d;
};

D::D(void):B1(),B2(),d(0)
{}
int main(void)
{
  D thed;
  thed.SetB1(1);
  thed.SetB2(2);
  return 0;
}
```

**示例1：规范用法之一**

```cpp
class Good_A
{
public:
  Good_A(void);
  void SetA(int);
private:
  int a;
};

Good_A::Good_A(void):a(0)
{}

void Good_A::SetA(int va)
{
	a=va;
}

class Good_B1:public virtual Good_A
{
public:
  Good_B1(void);
  void SetB1(int);
private:
  int b1;
};

Good_B1::Good_B1(void):Good_A(),b1(0)
{
}
void Good_B1::SetB1(int vb)
{
  b1=vb;
  SetA(b1+1);
}

class Good_B2:public virtual Good_A
{
public:
  Good_B2(void);
  void SetB2(int);
private:
  int b2;
};

Good_B2::Good_B2(void):Good_A(),b2(0)
{}

void Good_B2::SetB2(int vb)
{
	b2=vb;
    SetA(b2+2);
}

class Good_D:public Good_B1,public Good_B2
{
public:
  Good_D(void);
private:
  int d;
};

Good_D::Good_D(void):Good_B1(),Good_B2(),d(0)
{}

int main(void)
{
  Good_D thed1;
  thed1.SetB1(1);
  thed1.SetB2(2);
  return 0;
}
第[18]、[36]行的派生类集成的基类使用virtual说明
```

### MISRA_CPP_2008_10_01_03_rule　可访问的基类在同一层次结构中不能同时是虚拟和非虚拟的
> 等级：**强制**　分类：派生类

如果一个基类在多重继承层次结构中既是虚拟的又是非虚拟的，那么派生对象中将至少有两个基类子对象的副本。这可能与开发人员的期望不一致。

**示例1：不规范用法**

```cpp
class A {};
class B1: public virtual A {};
class B2: public virtual A {};
class B3: public A {};
class C: public B1, B2, B3 {}; // Non-compliant – C has two A sub-objects
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_10_02_01_rule　多重继承层次结构中的所有可访问实体名称应该是唯一的
> 等级：**推荐**　分类：派生类

如果名称不具有唯一性，编译器需要报告名称冲突，而不生成任意或意外解析的代码。

例外：就本规则而言，构成重载集的可见函数标识符应视为同一实体。

**示例1：不规范用法**

```cpp
class B1
{
public:
    int32_t count; // Non-compliant
    void foo(); // Non-compliant
};
class B2
{
public:
    int32_t count; // Non-compliant
    void foo(); // Non-compliant
};
class D : public B1, public B2
{
public:
    void Bar()
    {
        ++count; // Is that B1::count or B2::count?
        foo(); // Is that B1::foo() or B2::foo()?
    }
};
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_10_03_01_rule　每条继承层次结构路径上每个虚函数只能有一个定义
> 等级：**强制**　分类：派生类

该规则的主要目的是确保从类层次结构的任何点执行的函数版本都是清晰明确的。
此外，在类形成钻石层次结构时，可能会发生优先调用（[1]§10.3（11）），导致调用与开发者预期不一致的函数。
例外：在类层次结构的多个成员中可以声明虚析构函数。如果将函数声明为纯虚函数并在同一类中定义，则该定义将忽略此规则。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
class A
{
public:
    virtual void f1() = 0; // f1 is pure
    virtual void f2() = 0; // f2 is pure
    virtual void f3() {} // f3 is not pure
    virtual void f4() = 0; // f4 is pure
    virtual ~A(); // destructor
};
// A::f1 is both pure and has a definition
void A::f1()
{
}
// A::f4 is both pure and has a definition
void A::f4()
{
}
class B : public A
{
public:
    virtual void f2() {} // Compliant: f2 pure in A and
    // defined in B
    virtual void f3() {} // Non-compliant: f3 defined in A and B
    virtual void f4() = 0; // Compliant: f4 is pure in A and in B
    virtual ~B(); // Compliant: destructor
};
// Compliant by Exception - f4 defined in A but also declared pure in A
void B::f4()
{
}
class C : public B
{
public:
    virtual void f1() {} // Compliant: f1 defined in A and C
    // but was pure in A
    virtual void f2() {} // Non-compliant f2: defined in B and C
    // and not declared pure in B
    virtual void f4() {} // Compliant by Exception: f4 defined in A
    // and B but also declared pure in A and B
};
class D : public C
{
public:
    virtual void f1() {} // Non-compliant f1: defined in C and D
    // as well as A
    virtual ~D(); // Compliant: destructor
};
// Call by dominance example
class V
{
public:
    virtual void foo()
    {
    }
};
class B1 : public virtual V
{
public:
    virtual void foo() // Non-compliant
    {
    }
};
class B2 : public virtual V
{
public:
    void f1()
    {
        foo(); // V::foo would appear to be the only
        // candidate to be called here
    }
};
class D : public B1, public B2
{
public:
    void f2()
    {
        f1();
    }
};
B2 b2;
b2.f1(); // calls V::foo by normal inheritance rules
D d;
d.f2(); // calls B2::f1 which now calls B1::foo
// "by dominance"
d.f1(); // also calls B1::foo "by dominance"
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_10_03_02_rule　每个重写的虚函数应该被声明有虚拟关键字
> 等级：**强制**　分类：派生类

使用virtual关键字声明重写的虚函数可以避免检查基类以确定函数是否为虚函数。

**示例1：不规范用法**

```cpp
class A
{
    public :
    virtual int fun();
};
class B
{
    public:
    int fun(); //not compliant
};
```

**示例1：规范用法之一**

```cpp
class A
{
public:
virtual void g();
virtual void b();
};
class B1 : public A
{
public:
virtual void g(); // Compliant - explicitly declared "virtual"
};
```

### MISRA_CPP_2008_10_03_03_rule　如果一个虚函数本身被声明为纯虚函数，那它只能被纯虚函数所覆盖
> 等级：**强制**　分类：派生类

重新声明函数为纯虚函数可能不符合开发人员的期望。

**示例1：不规范用法**

```cpp
#include <iostream>

using namespace std;

class A
{
public:
    A(void);
    virtual ~A(void);
    virtual void foo(void) = 0;
	virtual void foo2(void);
};
A::A(void){}
A::~A(void){}
void A::foo2(void){}
class B : public A
{
public:
    B(void);
    virtual ~B(void);
    virtual void foo(void);
    virtual void foo2(void) = 0; //Not compliant
    virtual void foo3(void);
};
B::B(void){}
B::~B(void){}
void B::foo(void){}
void B::foo3(void){}
class C : public B
{
public:
    C(void);
    virtual ~C(void);
    virtual void foo(void) = 0; //Not compliant
    virtual void foo3(void); //ok
};
C::C(void){}
C::~C(void){}
void C::foo3(void){}
int main()
{
    return 0;
}
```

**示例1：规范用法之一**

```cpp
#include <iostream>

using namespace std;

class A
{
public:
    A(void);
    virtual ~A(void);
    virtual void foo(void) = 0;
	virtual void foo2(void);
};
A::A(void){}
A::~A(void){}
void A::foo2(void){}
class B : public A
{
public:
    B(void);
    virtual ~B(void);
    virtual void foo(void);
    virtual void foo2(void) ; // ok
    virtual void foo3(void);
};
B::B(void){}
B::~B(void){}
void B::foo(void){}
void B::foo3(void){}
class C : public B
{
public:
    C(void);
    virtual ~C(void);
    virtual void foo(void); // OK
    virtual void foo3(void); //ok
};
C::C(void){}
C::~C(void){}
void C::foo3(void){}
int main()
{
    return 0;
}
第[22]行派生类[B]中的虚函数[foo2]函数重写了第[11]基类[A]中的虚函数[foo2]；第[34]行派生类[C]中的虚函数[foo]重写了第[22]行基类[B]的虚函数[foo]
```

---

## 第 11 章 成员访问控制（1 条）

### MISRA_CPP_2008_11_00_01_rule　非POD类型中的数据成员应为private
> 等级：**强制**　分类：访问控制

通过使用成员函数实现类接口，可以控制对象状态的修改方式，并有助于类的后续维护。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
class C
{
public:
int32_t b; // Non-compliant
protected:
int32_t c; // Non-compliant
private:
int32_t d; // Compliant
};
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

---

## 第 12 章 特殊的成员函数（5 条）

### MISRA_CPP_2008_12_01_01_rule　一个对象的动态类型不应从其构造函数或析构函数的主体中使用
> 等级：**强制**　分类：特殊的成员函数

在对象构造和销毁期间，其类型可能有别于完全构造的对象类型，在构造函数或析构函数中使用对象动态类型的结果可能与开发者的期望不一致。
对象的动态类型在以下过程中使用：
 • 具有虚函数或基类有虚函数的类typeid
 • dynamic_cast
 • 调用虚函数的虚拟调用
此规则还禁止在构造函数或析构函数中调用纯虚函数，这样的调用会导致未定义的行为。

**示例1：原文示例（合规与不合规写法混排）**

```cpp
class B1
{
public:
    B1()
    {
        typeid(B1); // Compliant, B1 not polymorphic
    }
};
class B2
{
public:
    virtual ~B2();
    virtual void foo();
    B2()
    {
        typeid(B2); // Non-compliant
        B2::foo(); // Compliant – not a virtual call
        foo(); // Non-compliant
        dynamic_cast<B2 *>(this); // Non-compliant
    }
};
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_12_01_02_rule　一个类的所有构造函数应该显式地为它的所有直接基类和所有虚基类调用一个构造函数
> 等级：**推荐**　分类：特殊的成员函数

此规则减少了哪个构造函数将被使用以及使用什么参数所产生的混淆。

**示例1：不规范用法**

```cpp
#include <iostream>
using namespace std;
class Foo
{
public:
    int b;
    Foo(void);
    explicit Foo(int);
};
Foo::Foo(void): b(0)
{

}
Foo::Foo(int var)
{
    b = var;
}
class Book : public Foo
{
public:
    int bid;
    Book(void):bid(1) //not complinat
    {

    }
};
int main()
{
    Book f;
    return 0;
}
```

**示例1：规范用法之一**

```cpp
/*good class*/
class Good_foo
{
public:
    int b;
    Good_foo(void);
    explicit Good_foo(int var);
};
Good_foo::Good_foo(void):b(0)
{
}
Good_foo::Good_foo(int aVal)
{
    b = aVal;
}
class Good_Book : public Good_foo
{
public:
    int bid;
    Good_Book(void):Good_foo(1),bid(1)
    {

    }
};
int main()
{
    Good_Book gf1;
    return 0;
}
第[22]行派生类[Good_Book]的构造函数说明了直接基类[Good_foo]的构造函数
```

### MISRA_CPP_2008_12_01_03_rule　所有可用单个基本类型参数调用的构造函数都应声明为显式的
> 等级：**强制**　分类：特殊的成员函数

显式关键字防止构造函数被用于从基本类型到类类型的隐式转换

**示例1：原文示例（合规与不合规写法混排）**

```cpp
class C
{
public:
    C(int32_t a) // Non-compliant
    {
    }
};
class D
{
public:
    explicit D(int32_t a) // Compliant
    {
    }
};
```

> 代码块中标注 `// Compliant` 的语句为合规写法，`// Non-compliant`（或 `// not compliant`）的语句为不合规写法；原文未把两者拆成独立小节。

### MISRA_CPP_2008_12_08_01_rule　拷贝构造函数只初始化它的基类和作为成员的类的非静态成员
> 等级：**强制**　分类：特殊的成员函数

如果编译器可能省略拷贝构造函数的调用，即使拷贝构造函数除构造对象副本以外还具有副作用。
因此，需要确保拷贝构造函数不修改程序状态。

**示例1：不规范用法**

```cpp
class A
{
public:
    A(A const &rhs)
        : m_i(rhs.m_i)
    {
        ++m_static; // Non-compliant
    }


private:
    int32_t m_i;
    static int32_t m_static;
};
int32_t A::m_static = 0;
A f()
{
    return A();
}
void b()
{
    A a = f();
}
// 调用b()后m_static的值是取决于编译器实现
```

**示例1：规范用法之一**

> 原文未给出该类型的独立示例。

### MISRA_CPP_2008_12_08_02_rule　抽象类的复制赋值运算符应声明为protected或private
> 等级：**强制**　分类：特殊的成员函数

从抽象类调用复制构造函数将只复制基子对象。

**示例1：不规范用法**

```cpp
class B1
{
public:
    B1();
    virtual void f() = 0;
    B1 &operator=(B1 const &rhs); // Non-compliant
    int32_t getKind() const { return kind; }


private:
    int32_t kind;
};
class D1 : public B1
{
public:
    virtual void f() {}
    D1 &operator=(D1 const &rhs);


private:
    int32_t member;
};
void f1(B1 &b1, B1 &b2)
{
    b1 = b2;
}
// 赋值运算符是public，函数f1可以调用该运算符，并复制b1和b2的基子对象。
// 由于b1和b2是抽象类型，所以b1和b2必须是子对象，但两者派生对象中包含的信息将不会被复制
```

**示例1：规范用法之一**

```cpp
class B2
{
public:
    B2();
    virtual void f() = 0;
    int32_t getKind() const { return kind; }


protected:
    B2 &operator=(B2 const &rhs); // Compliant
private:
    int32_t kind;
};
class D2 : public B2
{
public:
    virtual void f() {}
    D2 &operator=(D2 const &rhs);
};
void f2(B2 &b1, B2 &b2)
{
    b1 = b2; // Compiler error will be reported
}
// 将复制赋值运算符设置为私有是限制对象复制的常见做法
```

---

## 第 14 章 模板（10 条）

### MISRA_CPP_2008_14_05_01_rule　非成员泛型函数只能在不是关联命名空间的命名空间中声明
> 等级：**强制**　分类：模板


参数依赖查找（ADL）在查找所调用的函数名称时，将额外的关联命名空间添加到搜索的作用域集中。在这些额外的命名空间中找到的通用函数将添加到重载集中，并由重载分决策选择，这与开发人员的期望不一致。

**示例1：不规范用法**

```cpp
template <typename T>
class B
{
public:
  B operator+ ( long & rhs );
  void f ( )
  {
    *this + 10; // calls NS::operator+ and not B::operator+ when B is instantiated with NS::A
  }
};
namespace NS
{
  class A
  {
  public:
  };
  template <typename T>
  bool operator+ ( T, int32_t ); // 不合法 – within associated namespace
}
template class<NS::A> B;
```

**示例1：规范用法之一**

```cpp
template <typename T>
class B
{
public:
  B operator+ ( long & rhs );
  void f ( )
  {
    *this + 10; // calls NS::operator+ and not B::operator+ when B is instantiated with NS::A
  }
};
namespace NS
{
  class A
  {
  public:
  };
}
template <typename T>
bool operator+ ( T, int32_t ); // 合法 – not in associated namespace
template class<NS::A> B;
```

### MISRA_CPP_2008_14_05_02_rule　当存在具有单个泛型参数的模板构造函数参数时，应声明复制构造函数
> 等级：**强制**　分类：模板


与可能的开发人员期望相反，模板构造函数不会抑制由编译器生成的复制构造函数。这可能会导致需要深度复制的成员的副本语义不正确。

**示例1：不规范用法**

```cpp
class A
{
public:
  A ( );
  // A ( A const & rhs ); Example 1 - implicitly generated
  template <typename T>
  A ( T const & rhs ) // Example 2
    : i ( new int32_t )
  {
    *i = *rhs.i;
  }
private:
  int32_t * i; // Member requires deep copy
};
void f ( A const & a1 )
{
  A a2 ( a1 ); // 不合法 - Unexpectedly uses Example 1
}
```

**示例1：规范用法之一**

```cpp
class A
{
public:
  A ( );
  A ( A const & rhs ); // Example 1
    : i ( new int32_t )
  {
    *i = *rhs.i;
  }
  template <typename T>
  A ( T const & rhs ) // Example 2
    : i ( new int32_t )
  {
    *i = *rhs.i;
  }
private:
  int32_t * i; // Member requires deep copy
};
void f ( A const & a1 )
{
  A a2 ( a1 ); // 合法 - Unexpectedly uses Example 1
}
```

### MISRA_CPP_2008_14_05_03_rule　当存在具有泛型参数的模板赋值运算符参数时，应声明复制赋值运算符
> 等级：**强制**　分类：模板


与可能的开发人员期望相反，模板赋值运算符不会抑制由编译器生成的复制赋值运算符。这可能会导致需要深度复制的成员的拷贝语义不正确。

**示例1：不规范用法**

```cpp
class A
{
public:
  // 不合法，未定义复制赋值运算符
  // A & operator= ( A const & rhs ) Example 1 - implicitly generated
  // {
  // i = rhs.i;
  // return *this;
  // }
  template <typename T>
  T & operator= ( T const & rhs ) // Example 2
  {
    if ( this != &rhs )
    {
      delete i;
      i = new int32_t;
      *i = *rhs.i;
    }
    return *this;
  }
private:
  int32_t * i; // Member requires deep copy
};
void f ( A const & a1, A & a2 )
{
  a2 = a1; // Unexpectedly uses Example 1
}
```

**示例1：规范用法之一**

```cpp
class A
{
public:
  // 合法，定义复制赋值运算符，进行深度拷贝
  A & operator= ( A const & rhs ) Example 1 - implicitly generated
  {
    if ( this != &rhs )
    {
      delete i;
      i = new int32_t;
      *i = *rhs.i;
    }
    return *this;
  }
  template <typename T>
  T & operator= ( T const & rhs ) // Example 2
  {
    if ( this != &rhs )
    {
      delete i;
      i = new int32_t;
      *i = *rhs.i;
    }
    return *this;
  }
private:
  int32_t * i; // Member requires deep copy
};
void f ( A const & a1, A & a2 )
{
  a2 = a1; // Unexpectedly uses Example 1
}
```

### MISRA_CPP_2008_14_06_01_rule　在具有依赖基类的类模板中，任何可能在该依赖基类中找到的名称都应该使用限定符或this->引用。
> 等级：**强制**　分类：模板

使用限定符或在标识符前加上this->可以确保所选择的实体与开发者的期望一致。

**示例1：不规范用法**

```cpp
typedef int32_t TYPE;
void g ( );
template <typename T>
class B;
template <typename T>
class A : public B
{
  void f1 ( )
  {
    TYPE t = 0; // 不合法
    g( ); // 不合法
  }
};
template <typename T>
class B
{
public:
  typedef T TYPE;
  void g ( );
};
template class A<int32_t>;
```

**示例1：规范用法之一**

```cpp
typedef int32_t TYPE;
void g ( );
template <typename T>
class B;
template <typename T>
class A : public B
{
  void f2 ( )
  {
    ::TYPE t1 = 0; // Compliant - explicit use global TYPE
    ::g ( ); // Compliant - explicit use global func typename
    B<T>::TYPE t2 = 0; // Compliant - explicit use base TYPE
    this->g ( ); // Compliant - explicit use base "g"
  }
};
template <typename T>
class B
{
public:
  typedef T TYPE;
  void g ( );
};
template class A<int32_t>;
```

### MISRA_CPP_2008_14_06_02_rule　由重载决策选择的函数应解析为在翻译单元中先前声明的函数
> 等级：**强制**　分类：模板


参数依赖查找（ADL）在查找所调用的函数的名称时，为搜索的作用域集添加了其他相关联的命名空间。对于函数模板，ADL在函数模板的实例化点执行，因此可能会调用在模板之后声明的函数。为了确保在调用具有依赖参数的函数时不会发生ADL，表示所调用的函数的后缀表达式可以是限定名称或括号表达式。

**示例1：不规范用法**

```cpp
void b ( int32_t );
template <template T>
void f ( T const & t )
{
  b ( t ); // Non-compliant - Calls NS::b declared after
}
namespace NS
{
  struct A
  {
    operator int32_t ( ) const;
  };
  void b ( A const & a );
}
int main ( )
{
  NS::A a;
  f ( a );
}
```

**示例1：规范用法之一**

```cpp
void b ( int32_t );
template <template T>
void f ( T const & t )
{
  ::b ( t ); // Compliant - Calls ::b
  ( b ) ( t ); // Compliant - Calls ::b
}
namespace NS
{
  struct A
  {
    operator int32_t ( ) const;
  };
  void b ( A const & a );
}
int main ( )
{
  NS::A a;
  f ( a );
}
```

### MISRA_CPP_2008_14_07_01_rule　所有类模板，函数模板，类模板成员函数和类模板静态成员都应至少实例化一次
> 等级：**强制**　分类：模板

所有类模板，函数模板，类模板成员函数和类模板静态成员都应至少实例化一次。

**示例1：不规范用法**

```cpp
template < typename T >
class Sample
{
public:
  void inst_mem( )
  {
    // ...
  }
  void uninst_mem( ) // 不合法 - 整个程序中没被实例化过
  {
    // ...
  }
};
Sample s;
s.inst_mem( ); // 实例化 inst_mem()
```

**示例1：规范用法之一**

```cpp
template < typename T >
class Sample
{
public:
  void inst_mem( )
  {
    // ...
  }
};
Sample s;
s.inst_mem( ); // 实例化 inst_mem()
```

### MISRA_CPP_2008_14_07_02_rule　对于任何给定的模板特化，使用该特化中使用的模板参数显式实例化模板时不应使程序无法形成
> 等级：**强制**　分类：模板


隐式的模板特化不会实例化模板的每个成员。当实例化成员将导致一个无法形成的程序时，不清楚该模板是否应该使用提供的模板参数。

**示例1：不规范用法**

```cpp
template <typename T>
class A
{
public:
  void f1 ()
  {
    // ...
  }
  void f2 ()
  {
    T t;
    t.x = 0; // Will only work for types that have a .x member
  }
};
void b ()
{
  A<int32_t> a; // A::f2 is not instantiated.
  a.f1 ();
}
template class A<int32_t>; // 不合法
```

**示例1：规范用法之一**

```cpp
template <typename T>
class A
{
public:
  void f1 ()
  {
    // ...
  }
  void f2 ()
  {
    T t;
  }
};
void b ()
{
  A<int32_t> a;
  a.f1 ();
}
template class A<int32_t>; // 合法
```

### MISRA_CPP_2008_14_07_03_rule　一个模板的所有局部和显式的特化应该在它们原始模板的同一个文件中被定义
> 等级：**强制**　分类：模板


如果编译器生成隐式实例化，并且程序中的某个地方声明或定义了一个偏特化或显式特化，该偏特化或显式特化将匹配模板参数集，则行为是未定义的。

**示例1：不规范用法**

```cpp
// tmpl.h
template <typename T>
void bad_tmpl(){}
template <typename T>
void good_tmpl(){}
template <>
void good_tmpl<int>(){}
// tmpl.cc
#include "01_02_14_08.h"

template <>
void bad_tmpl<int>(){} //not complaint
template <>

void good_tmpl<int>(){} //not complaint
```

**示例1：规范用法之一**

```cpp
// header file: mytemplate.h

template <typename T>
class MyTemplate
{
public:
    void foo(T x);
};

template <typename T>
void MyTemplate::foo(T x)
{
    // implementation
}

template <>
class MyTemplate
{
public:
    void foo(int x);
};

void MyTemplate::foo(int x)
{
    // implementation
}
模板的特化与模板定义在同一个文件中
```

### MISRA_CPP_2008_14_08_01_rule　重载的函数模板不应该被显式地特化
> 等级：**强制**　分类：模板


显式特化只有在重载解析选择了来自主函数模板集的最佳匹配项之后才会被考虑。这可能与开发人员的预期不一致。

**示例1：不规范用法**

```cpp
template <typename T> void f ( T ); // overload Example 1
template <typename T> void f ( T* ); // overload Example 2
template <> void f<int32_t*> ( int32_t* ); // explicit specialization of Example 1
void b ( int32_t * i )
{
  f ( i ); // 不合法- Calls Example 2, f<int32_t*>
}
```

**示例1：规范用法之一**

```cpp
template <typename T> void f ( T ); // Example 1
template <> void f<int32_t*> ( int32_t* ); // Example 2
void b ( int32_t * i )
{
  f ( i ); // 合法 - Calls Example 2, f<int32_t*>
}
```

### MISRA_CPP_2008_14_08_02_rule　函数调用的可行函数集应该不包含函数模板的特化，或者只包含函数模板的特化
> 等级：**推荐**　分类：模板


如果在重载解析后，将函数和函数模板的特化视为等效，则非特化函数将优先于函数模板的特化被选择，这可能与开发人员的预期不一致。

例外：本规则不适用于拷贝构造函数或拷贝赋值运算符。

**示例1：不规范用法**

```cpp
void f( short ); // Example 1
template <typename T> void f( T ); // Example 2
void b ( short s )
{
  f ( s ); // 不合法 - Calls Example 1
  f ( s + 1 ); // 不合法 - Calls Example 2
}
```

**示例1：规范用法之一**

```cpp
void f( short ); // Example 1
template <typename T> void f( T ); // Example 2
void b ( short s )
{
  f<>( s ); // 合法 - Explicitly calls Example 2
  f<>( s + 1 ); // 合法 - Explicitly calls Example 2
}
```

---

## 第 15 章 异常处理（17 条）

### MISRA_CPP_2008_15_00_01_rule　异常只应用于错误处理
> 等级：**文档**　分类：异常处理


异常处理机制可以提供有效而清晰的方式来处理错误条件，特别是当函数需要返回一些所需的结果以及成功或失败的指示时。但是，由于其能够将控制传递回调用树，因此它也可能导致难以理解的代码。因此，必须仅使用该机制来捕获在某种意义上不希望看到并且在正常程序执行中不应出现的行为。

**示例1：不规范用法**

```cpp
void fn ( )
{
  try
  {
    if ( x < 10 )
    {
      throw ( 10 ); // 不合法
    }
    // Action "A"
  }
  catch ( int32_t y )
  {
    // Action "B"
  }
}
```

**示例1：规范用法之一**

```cpp
int divide(int a, int b)
{
    if (b == 0) {
        throw std::runtime_error("division by zero"); // throwing an exception for error handling
    }

    return a / b;
}
```

### MISRA_CPP_2008_15_00_02_rule　异常对象不应该具有指针类型
> 等级：**推荐**　分类：异常处理


如果抛出指针类型的异常对象，并且该指针引用动态创建的对象，则可能不清楚哪个函数负责销毁它以及何时销毁它。如果通过值或引用捕获对象，则不存在这种歧义。

**示例1：不规范用法**

```cpp
class A
{
  // Implementation
};
void fn ( int16_t i )
{
  static A a1;
  A * a2 = new A;
  if ( i > 10 )
  {
    throw ( &a1 ); // Non-compliant – pointer type thrown
  }
  else
  {
    throw ( a2 ); // Non-compliant – pointer type thrown
  }
}
```

**示例1：规范用法之一**

```cpp
class A
{
  // Implementation
};
void fn ( int16_t i )
{
  static A a1;
  if ( i > 10 )
  {
    throw ( a1 ); // 合法
  }
}
```

### MISRA_CPP_2008_15_00_03_rule　不应使用goto或switch语句将控制转移到try或catch块中
> 等级：**强制**　分类：异常处理


如果使用goto或switch语句将控制转移到try或catch块中，则程序是不符合规范的。但是，并非所有编译器都会发出诊断消息。

**示例1：不规范用法**

```cpp
void f ( int32_t i )
{
  if ( 10 == i )
  {
    goto Label_10; // 不合法
  }
  if ( 11 == i )
  {
    goto Label_11; // 不合法
  }
  switch ( i )
  {
    case 1:
      try
      {
        Label_10: // 不合法
        case 2:
          break;
      }
      catch ( ... )
      {
        Label_11: // 不合法
        case 3:
          break;
      }
    break;
    default: {
      break;
    }
  }
}
```

**示例1：规范用法之一**

```cpp
void foo()
{
    try {
        // code that may throw an exception
    }
    catch (const std::exception& e) {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }
}
```

### MISRA_CPP_2008_15_01_01_rule　throw语句的赋值表达式本身不应该导致异常抛出
> 等级：**强制**　分类：异常处理


如果在构造异常对象时或在初始化异常对象的赋值表达式求值时抛出异常，则会优先传播该异常，而不是即将抛出的异常。这可能与开发人员的期望不一致。

**示例1：不规范用法**

```cpp
class E2
{
public:
  E2 ( )
  {
    throw (10)
  }
};

void f2(void)
{
  try
  {
    if ( ... )
    {
      throw E ( ); // 不合法，构造对象时抛出异常
    }
  }
}
```

**示例1：规范用法之一**

```cpp
class E
{
public:
  E ( ){ } // 假定构造函数不会抛出异常
};

void f1(void)
{
  try
  {
    if ( ... )
    {
      throw E ( ); // 合法，构造对象时没有抛出异常
    }
  }
}
```

### MISRA_CPP_2008_15_01_02_rule　不应显式地抛出NULL
> 等级：**强制**　分类：异常处理


hrow(NULL)（等同于throw(0)）永远不是null指针常量的抛出，因此只会被整数处理程序捕获。这可能与开发人员的期望不一致，特别是如果程序仅具有针对指针类型异常的处理程序。

**示例1：不规范用法**

```cpp
try
{
  throw ( NULL ); // 不合法
}
catch ( int32_t i ) // NULL exception handled here
{
  // ...
}
```

**示例1：规范用法之一**

```cpp
try
{
  throw ( static_cast < const char_t * > ( NULL ) ); // 合法
  throw ( p );
}
catch ( int32_t i )
{
  // ...
}
catch ( const char_t * )
{
  // ...
}

```

### MISRA_CPP_2008_15_01_03_rule　仅在catch处理程序的复合语句中使用空throw
> 等级：**强制**　分类：异常处理


空throw重新抛出表示异常的临时对象。它的使用旨在使异常处理分散在两个或多个处理程序中。但是，在语法上，没有什么可以阻止在catch处理程序之外使用throw;，在这种情况下没有异常对象可供重新抛出。这可能会导致实现定义的程序终止。

**示例1：不规范用法**

```cpp
void f2 ( void ) {
  throw; // 不合法
}
void g2 ( void ) {
  try {
    throw; // 不合法
  }
  catch ( ... ) {
    // ...
  }
}
```

**示例1：规范用法之一**

```cpp
void f1 ( void ) {
  try {
    throw ( 42 );
  } catch ( int32_t i ) // int will be handled here first
  {
    if ( i > 0 ) {
      throw; // 合法，重新抛出异常
    }
  }
}
void g1 ( void ) {
  try {
    f1 ( );
  } catch ( int32_t i ) {
    // Handle re-throw from f1 ( )
    // after f1's handler has done what it needs
  }
}
```

### MISRA_CPP_2008_15_03_01_rule　只能在程序启动后和终止前抛出异常
> 等级：**强制**　分类：异常处理


在启动或终止期间抛出异常会导致程序以实现定义的方式终止。
在main函数执行主体之前，程序处于启动阶段，构造和初始化静态对象。同样，在main函数返回后，程序处于终止阶段，静态对象正在被销毁。如果在这些阶段中抛出异常，它会导致程序以实现定义的方式终止。具体来说，根据ISO/IEC 14882:2003 [1]第15.3（13）节的规定，如果main函数被实现为函数try块，则启动和关闭期间抛出的异常不会被main函数的catch块捕获。
这实际上是规则15-3-4的一个特例，因为在启动或终止期间抛出的异常无法被处理程序处理。

**示例1：不规范用法**

```cpp
class C {
public:
  C ( ) {
    throw ( 0 ); // Non-compliant – thrown before main starts
  }
  ~C ( ) {
    throw ( 0 ); // Non-compliant – thrown after main exits
  }
};
C c;
int main( ... ) {
  try {
    // program code return 0;
  } catch ( ... ) {
    // Handle exception return 0;
  }
}
```

**示例1：规范用法之一**

```cpp
#include <iostream>

void foo()
{
    // code that may throw an exception
}

int main()
{
    try {
        foo(); // call to a function after start-up phase
    }
    catch (const std::exception& e) {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }

    return 0;
}
```

### MISRA_CPP_2008_15_03_02_rule　应该至少有一个异常处理程序来捕获所有其他未处理的异常
> 等级：**推荐**　分类：异常处理


如果程序抛出未处理的异常，则以一种实现定义的方式终止。特别地，实现定义了在终止之前是否展开调用栈，因此自动对象的析构函数可能会或可能不会被执行。通过强制提供“最后的抓取所有”处理程序，开发人员可以确保程序以一致的方式终止。

**示例1：不规范用法**

```cpp
    try
	{
 throw(0);
	}
	catch(int ie){}
	catch(...){} //compliant

	try
	{
 throw(0);
	}
	catch(int ie) //Not compliant
	{}
```

**示例1：规范用法之一**

```cpp
#include <iostream>

int main()
{
    try {
        // code that may throw an exception
    }
    catch (const std::exception& e) {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Caught unknown exception" << std::endl;
    }
}
```

### MISRA_CPP_2008_15_03_03_rule　类构造函数或析构函数的函数try块实现的处理程序不应引用该类或其基类的非静态成员
> 等级：**强制**　分类：异常处理


在类构造函数或析构函数的函数try块中的处理程序（即catch部分）中访问类或基类的非静态成员是未定义的行为。
例如，如果在创建对象期间抛出内存分配异常，则在处理程序尝试访问其成员时，对象将不存在。相反，在析构函数中，在异常处理之前对象可能已成功销毁，因此在处理程序中也将无法使用该对象。
相比之下，静态成员的生命周期比对象本身更长，因此当处理程序访问它时，可以保证静态成员存在。

**示例1：不规范用法**

```cpp
class C {
public:
  int32_t x;
  C ( )
    try {
      // Action that may raise an exception
    } catch ( ... ) {
      if ( 0 == x ) // 不合法，x 此刻可能不存在
      {
        // Action dependent on value of x
      }
    }
  ~C ( )
    try {
      // Action that may raise an exception
    } catch ( ... ) {
      if ( 0 == x ) // 不合法，x 此刻可能不存在
      {
        // Action dependent on value of x
      }
    }
};
```

**示例1：规范用法之一**

```cpp
class MyClass {
 public:
  MyClass() try {
    // constructor body
  }
  catch (...) {
    // error handling code
  }
};

class MyDerivedClass: public MyClass {
 public:
  MyDerivedClass() try : MyClass() {
    // constructor body
  }
  catch (...) {
    // error handling code
  }
};
```

### MISRA_CPP_2008_15_03_04_rule　代码中显式抛出的每个异常都应该在所有可能导致该点的调用路径中具有兼容类型的处理程序
> 等级：**强制**　分类：异常处理


如果程序抛出未经处理的异常，则以实现定义的方式终止。特别地，调用堆栈在终止之前是否展开是由实现定义的，因此任何自动对象的析构函数可能或可能不会被调用。
如果以派生类对象的形式抛出异常，则“兼容类型”可以是该派生类或其任何基类。

**示例1：不规范用法**

```cpp
void func1() {
  throw runtime_error("Error in func1");
}

void func2() {
  try {
    func1();
  }
  catch (logic_error& e) {
    cout << "Caught exception: " << e.what() << endl;
  }
}
```

**示例1：规范用法之一**

```cpp
void func1() {
  throw runtime_error("Error in func1");
}

void func2() {
  try {
    func1();
  }
  catch (runtime_error& e) {
    cout << "Caught exception: " << e.what() << endl;
  }
}
```

### MISRA_CPP_2008_15_03_05_rule　类类型的异常应该始终被引用捕获
> 等级：**强制**　分类：异常处理


在C++中，如果捕获类类型异常对象时使用值（by value）方式捕获，则会发生切片（slicing）现象。这意味着，如果异常对象是派生类对象且在catch语句块中以基类方式捕获，则只能调用基类及其虚函数，而派生类中的任何额外成员数据都无法访问。

**示例1：不规范用法**

```cpp
#include<iostream>
using namespace std;

class Exp
{
public:
	Exp(void){}
};
int main(void)
{
    try
    {
        throw Exp();
    }
    catch(Exp e) //Not Compliant
    {
        cout<<"exception:Exp"<<endl;
    }
    catch(Exp *e) //Not Compliant
    {
        cout<<"exception:Exp"<<endl;
    }
    return 0;
}
```

**示例1：规范用法之一**

```cpp
#include<iostream>
using namespace std;

class Exp
{
public:
	Exp(void){}
};
int main(void)
{
    try
    {
        throw Exp();
    }
    catch(Exp &e) //OK
    {
       cout<<"exception:Exp"<<endl;
    }
    return 0;
}
第[15]行的catch类型按照饮用方式进行捕获
```

### MISRA_CPP_2008_15_03_06_rule　try-catch处理遵循从最底层派生类到基类顺序
> 等级：**强制**　分类：异常处理


当程序在处理异常时，查找与异常类型匹配的catch语句块时，derived（派生）类异常对象可以与其base（基类）类异常处理器匹配。如果在程序代码中定义了一个派生类和一个基类异常处理器，如果先找到基类异常处理器，则将使用基类异常处理器来处理该异常。在这种情况下，派生类异常处理程序将被认为是不可达代码，永远不会被执行。

**示例1：不规范用法**

```cpp
#include<iostream>
using namespace std;

class Document
{
public:
    Document(void) : docid(0)
        {

        }
    int get_docid(void);
private:
    int docid;
};
int Document::get_docid(void)
{
    return docid;
}
class Book : public Document
{
public:
    Book(void) : Document(),bookid(0)
    {

    }
    int get_bookid(void);
private:
    int bookid;
};
int Book::get_bookid()
{
    return bookid;
}
int main()
{
    Book book;
    try{
        throw book;
    }
    catch(Document &d) //not complaint
    {
        cout << d.get_docid() <<endl;
    }
    catch(Book &b) //not complaint
    {
        cout<< b.get_bookid() <<endl;
    }
    return 0;
}
```

**示例1：规范用法之一**

```cpp
#include<iostream>
using namespace std;

class Document
{
public:
    Document(void) : docid(0)
        {

        }
    int get_docid(void);
private:
    int docid;
};
int Document::get_docid(void)
{
    return docid;
}
class Book : public Document
{
public:
    Book(void) : Document(),bookid(0)
    {

    }
    int get_bookid(void);
private:
    int bookid;
};
int Book::get_bookid()
{
    return bookid;
}
/*good example*/
int good_main()
{
    Book book;
    try{
        throw book;
    }
    catch(Book &d) //ok
    {
        cout << d.get_bookid() <<endl;
    }
    catch(Document &b) //ok
    {
        cout<< b.get_docid() <<endl;
    }
    return 0;
}
第[40]、[44]行的catch分支按照从最底层的派生类到基类的顺序进行捕获
```

### MISRA_CPP_2008_15_03_07_rule　如果有多个处理程序都在一个规定的try-catch语句或函数try块，任何省略（catch-all）处理程序将应该在最后
> 等级：**强制**　分类：异常处理


如果catch-all语句块在任何其他语句块之前被找到，则程序将执行catch-all语句块的代码，并跳过所有后续的catch语句块。后续的catch语句块将被视为无法到达的代码，永远不会被执行。这可能会导致程序行为异常或不可预测。

**示例1：不规范用法**

```cpp
int main(void)
{
	try{
 throw(0);
	}
	catch(int ie){}
	catch(...){}

	try{
 throw 0;
	}
	catch(...) {} //不合法
	catch(int ie){}
}
```

**示例1：规范用法之一**

```cpp
int main(void)
{
  try {
    // Some code that may throw an exception
  }
  catch (std::runtime_error& e) {
    // 处理 runtime_error 异常
  }
  catch (std::logic_error& e) {
    // 处理 logic_error 异常
  }
  catch (...) {
    // 处理所有异常
  }
}
```

### MISRA_CPP_2008_15_04_01_rule　同一函数的所有声明都必须使用相同的异常说明符集合进行声明
> 等级：**强制**　分类：异常处理

同一函数的所有声明都必须使用相同的异常说明符集合进行声明。

**示例1：不规范用法**

```cpp
// 文件 A
void foo( ) throw ( const char_t * ) {
  throw "Hello World!";
}
// 文件 B
extern void foo ( ) throw ( int32_t );
```

**示例1：规范用法之一**

```cpp
// 文件 A
void foo( ) throw ( const char_t * ) {
  throw "Hello World!";
}
// 文件 B
extern void foo ( ) throw ( const char_t * );
```

### MISRA_CPP_2008_15_05_01_rule　类的析构函数不得带有异常退出
> 等级：**强制**　分类：异常处理


当抛出异常时，调用堆栈将解除到处理异常的点。从抛出异常的点到要处理异常的点之间声明的所有自动对象的析构函数将被调用。如果这些析构函数中的一个使用异常退出，则程序将以实现定义的方式终止。需要注意的是，析构函数抛出并在其中被处理的异常是可以接受的，例如在try-catch块中。

**示例1：不规范用法**

```cpp
class Foo {
public:
  Foo( ) { }
  ~Foo( ) {
    throw; // 违规
  }
};
```

**示例1：规范用法之一**

```cpp
class Exception {};
class Foo {
public:
  Foo( ) { }
  ~Foo( ) {
    try { // OK
    } catch (Exception& e) {
    // 捕获所有的异常
    }
  }
};
用try..catch代替
```

### MISRA_CPP_2008_15_05_02_rule　如果函数的声明包含异常说明符，那么函数只能抛出指定类型的异常
> 等级：**强制**　分类：异常处理


在C++中，函数的声明可以包含异常说明符，以指示该函数可能会抛出哪些类型的异常。如果在函数执行过程中抛出了未在异常说明符中列出的异常类型，那么将会调用unexpected()函数。这个函数的行为可以在项目中被重载，但默认情况下会导致std::bad_exception 异常被抛出。如果std::bad_exception 未在异常说明符中列出，则将调用terminate()函数，导致实现定义的程序终止。

**示例1：不规范用法**

```cpp
void foo ( ) {
    throw ( 21 );
}

void goo ( ) throw ( Exception ) {
    foo ( ); // 不合法，异常列表中没有 int
}
```

**示例1：规范用法之一**

```cpp
void func() throw(int) {
  throw 42;
}

int main() {
  try {
    func();
  }
  catch (int) {
    // Handle the exception
  }
}
```

### MISRA_CPP_2008_15_05_03_rule　不得隐式调用terminate()函数
> 等级：**强制**　分类：异常处理


由于在调用terminate()函数时，调用堆栈是否被解除还是取决于具体实现，所以隐式地调用terminate()函数可能导致程序可能还没有执行完所有的析构函数，从而可能导致内存泄漏和其他问题。

**示例1：不规范用法**

```cpp
void func() {
  throw "An error occurred";
}

int main() {
  try {
    func();
  }
  catch (...) {
    // Do nothing
  }
}
```

**示例1：规范用法之一**

```cpp
void func() {
  throw "An error occurred";
}

int main() {
  try {
    func();
  }
  catch (...) {
    // Handle the exception
    std::terminate();
  }
}
```

---

## 第 16 章 预处理指令（19 条）

### MISRA_CPP_2008_16_00_01_rule　文件中的#include指令之前只能有其他预处理器指令或注释
> 等级：**强制**　分类：预处理指令

为了提高代码的可读性，特定代码文件中的所有#include指令都应该成组列在文件头。文件中#include之前仅能是其他预处理器指令或注释。

**示例1：不规范用法**

```cpp
int32_t i;
#include <f2.h> // Non-compliant
int main_bad(void)
{
#include "..\061\061.h" // Non-compliant
    int ix = 0;
    int iy = 1;
    int iz = 2;
    int idata;
    idata = ix + iy + iz;
    return 0;
}
```

**示例1：规范用法之一**

```cpp
/*将#include语句放在可执行代码前，文件最开始的位置。*/
#include "..\060\060.h" // compliant
int main_good(void)
{
    int ix = 0;
    int iy = 1;
    int iz = 2;
    int idata;
    idata = ix + iy + iz;
    return 0;
}
```

### MISRA_CPP_2008_16_00_02_rule　只能在全局的命名空间中 #define 或 #undef 宏
> 等级：**强制**　分类：预处理指令

虽然将#define或#undef指令放在源文件中的任何位置都是合法的，但将它们放在全局命名空间之外会产生误导，因为它们的范围没有受到限制。这可能与开发人员的期望不一致。

**示例1：不规范用法**

```cpp
#define A
#undef A
int main()
{
        # define B //not compliant
	# undef B //not compliant
	return 0;
}
```

**示例1：规范用法之一**

```cpp
#ifndef MY_HDR
#define MY_HDR // Compliant
namespace NS {
}
#endif
```

### MISRA_CPP_2008_16_00_03_rule　不应使用 #undef
> 等级：**强制**　分类：预处理指令

通常不应需要#undef。当在代码中使用宏时，它的使用可能会导致对宏的存在或含义的混淆。

**示例1：不规范用法**

```cpp
#ifndef MY_HDR
#define MY_HDR
#undef MY_HDR // Non-compliant
#endif
```

**示例1：规范用法之一**

```cpp
#ifndef MY_HDR
#define MY_HDR // compliant
#endif
```

### MISRA_CPP_2008_16_00_04_rule　不得定义函数式宏
> 等级：**强制**　分类：预处理指令

虽然宏可以提供比函数更快的速度优势，但函数提供了更安全、更健壮的机制。这对于参数的类型检查以及函数式宏可能多次评估参数的问题，尤其正如此。应改用内联函数。

**示例1：不规范用法**

```cpp
#define SUM(A,B) ((A)+(B)) /*违规*/
void foo( int x, int y ) {
/* ... */
SUM( x, y );
/* ... */
}
```

**示例1：规范用法之一**

```cpp
/*建议使用函数。*/
void SUM(int A, int B) // ok
{
	return A+B;
}
void foo( int x, int y ) {
/* ... */
SUM( x, y );
/* ... */
}
```

### MISRA_CPP_2008_16_00_05_rule　函数式宏的参数不应包含看起来像预处理指令的符号
> 等级：**强制**　分类：预处理指令


如果任何参数的行为类似于预处理器指令，则进行宏替换时的行为可能是不可预测的。

**示例1：不规范用法**

```cpp
#define MACRO1(x)
#define MACRO2(x, y)
void foo( void ) {
  int i = 0;
  MACRO1( #foo ); /* 违规 */
  MACRO2( i, #foo ); /* 违规 */
  MACRO2( i, "#foo" ); /* 违规 */
  MACRO1( i );
}
```

**示例1：规范用法之一**

```cpp
#define MIN(x, y) ((x) < (y)) ? (x) : (y)

const int FOO = 4;
MIN(3, FOO)
```

### MISRA_CPP_2008_16_00_06_rule　在函数式宏的定义中，每个参数的实例应该置于括号内，除非它是用作 # 或 ## 的操作数
> 等级：**强制**　分类：预处理指令

如果未使用括号，则当预处理器将宏替换到代码中时，运算符优先级可能不会给出所需的结果。在函数式宏的定义中，参数应括在括号中。

**示例1：不规范用法**

```cpp
#define E1(X) X //Not compliant
#define E2(X) X+A1 //Not compliant
#define E3(X) (((X)>=0)?(X):-X) //Not compliant
#define F1(X,Y) X Y //Not compliant
#define F2(X,Y) X#Y X //Not compliant
#define F3(X,Y) X+Y //Not compliant
#define F4(X,Y) ((X)+Y) //Not compliant
```

**示例1：规范用法之一**

```cpp
#define C2(X) #X // compliant
#define C3(X) (((X)>=0)?(X):-(X))// compliant
#define C4(X,...) do {} while(0);// compliant
#define D1(X,Y) (X)+(Y)+1 // compliant
#define D2(X,Y) X##Y // compliant
```

### MISRA_CPP_2008_16_00_07_rule　未定义的宏标识符不得在 #if 或 #elif 预处理指令中使用，除了作为 defined 运算符的操作数
> 等级：**强制**　分类：预处理指令

如果试图在预处理器指令中使用标识符，但尚未定义该标识符，则预处理器将假定值为零。提供#ifdef、#ifndef和defined()是为了测试宏的存在，因此被排除在外。

**示例1：不规范用法**

```cpp
#if M == 0 /* Non-compliant */
#endif
```

**示例1：规范用法之一**

```cpp
/*提前用#defined判断操作数是否定义*/
// 第一种修复方案
#if defined ( M ) /* Compliant - M is not evaluated */
#if M == 0 /* Compliant - M is known to be defined */
#endif
#endif

// 第二种修复方案
#if defined ( M ) && ( M == 0 )
#endif
```

### MISRA_CPP_2008_16_00_08_rule　如果#符号作为第一个符号出现在一行中，那么它后面应该紧跟一个预处理符
> 等级：**强制**　分类：预处理指令

当预处理器指令排除源代码的一部分时，每个被排除语句的内容都会被忽略，直到遇到#else、#elif或#endif指令为止（取决于上下文）。如果这些排除指令中的一个格式不正确，编译器可能会忽略它而不发出警告，从而产生意外的后果。
该规则的要求是，即使它们出现在排除的代码块中，所有预处理器指令在语法上都应有效。
注意，请确保#else和#endif指令后面没有空格以外的任何字符。编译器在执行这一要求时并不总是一致的。

**示例1：不规范用法**

```cpp
#define AAA 2
int32_t foo(void) {
  int32_t x = 0;
  ...
#ifndef AAA
      x = 1;
#else1 // Non-compliant
  x = AAA;
#endif
  ... return x;
}
```

### MISRA_CPP_2008_16_01_01_rule　defined 预处理运算符应该只能用于两个标准形式之一
> 等级：**强制**　分类：预处理指令

defined 的预处理器运算符唯一允许的两种形式是：
 • defined (identifier)
 • defined identifier
任何其他形式都是约束冲突，但并非所有编译器都报告这一点。

**示例1：不规范用法**

```cpp
#if defined hh>2 //not compliant
#endif
```

**示例1：规范用法之一**

```cpp
/*使用defined预处理操作符的许可形式。*/
#if defined hh // compliant
#endif
```

### MISRA_CPP_2008_16_01_02_rule　所有的 #else, #elif 和 #endif 预处理指令应该存在于和 #if 或 #ifdef 指示符相关的相同文件中
> 等级：**强制**　分类：预处理指令

当语句块的包含和排除由一系列预处理器指令控制时，如果所有相关指令都不出现在一个文件中，则可能会出现混淆。此规则要求所有预处理器指令以#if/#ifdef...#elif...#else...#endif的形式排列于同一文件中。遵守此规则可以保留良好的代码结构，避免维护问题。
请注意，这并不排除此类指令可能存在于包含的文件中的可能性，前提是与同一序列相关的所有指令都位于一个文件中。

**示例1：不规范用法**

```cpp
#define MISMATCHEDIF 1
#if MISMATCHEDIF == 1
void static_126(void)
{
   /* ... */
}
```

**示例1：规范用法之一**

```cpp
/*在同文件第(10)行添加#endif，与#if配对使用。*/
#define MISMATCHEDIF 1
#if MISMATCHEDIF == 1
void static_126(void)
{
   /* ... */
}
#endif // MISMATCHEDIF
```

### MISRA_CPP_2008_16_02_01_rule　预处理器只能用于文件包含和include 保护
> 等级：**强制**　分类：预处理指令

预处理器只能用于文件包含和include 保护。

**示例1：不规范用法**

```cpp
#define X(Y) (Y) // 不合法
```

**示例1：规范用法之一**

```cpp
#ifndef HDR // 合法
#define HDR // 合法
#endif
```

### MISRA_CPP_2008_16_02_02_rule　C++宏只能用于include 保护、类型限定符或存储类说明符
> 等级：**强制**　分类：预处理指令

C++宏只能用于include 保护、类型限定符或存储类说明符。

**示例1：不规范用法**

```cpp
// 以下不合法
#define CLOCK (xtal/16) // 常量表达式
#define PLUS2(X) ((X) + 2) //宏展开为表达式
#define HEADER "filename.h" // 字符常量
```

**示例1：规范用法之一**

```cpp
#define STOR extern // 合法
```

### MISRA_CPP_2008_16_02_03_rule　应该提供include保护机制
> 等级：**强制**　分类：预处理指令


当一个源文件中包含一个复杂的嵌套头文件层次结构时，可能会出现一个特定的头文件被多次包含的情况。这可能会导致混淆。如果多次包含导致多个或冲突的定义，那么这可能会导致未定义的或错误的行为。

**示例1：不规范用法**

```cpp
// file.h
#ifndef FILE_H
#endif
// file.cc
#include "file.h"
#define FILE_H // 不合法
```

**示例1：规范用法之一**

```cpp
// file.h
#ifndef FILE_H
#define FILE_H // 合法
#endif
// file.cc
#include "file.h"
```

### MISRA_CPP_2008_16_02_04_rule　头文件名中不应出现单引号（'）、双引号（"）、注释起始符（/*）或双斜杠（//）字符
> 等级：**推荐**　分类：预处理指令

头文件名中不应出现单引号（'）、双引号（"）、注释起始符（/*）或双斜杠（//）字符。

**示例1：不规范用法**

```cpp
#include "my"file.h" // 不合规
#include "my//file.h" // 不合规
#include "my/*file.h" // 不合规
```

**示例1：规范用法之一**

```cpp
#include "myfile.h"
#include "my_file.h"
```

### MISRA_CPP_2008_16_02_05_rule　头文件名中不应该出现反斜杠字符
> 等级：**推荐**　分类：预处理指令

头文件名中不应该出现反斜杠（\）字符。

**示例1：不规范用法**

```cpp
#include "my\Header.h" // 不合规
```

**示例1：规范用法之一**

```cpp
#include "myHeader.h"
#include "my.Header.h"
#include "my/Header.h"
```

### MISRA_CPP_2008_16_02_06_rule　#include 指令后面应该紧跟着 <文件名> 或 "文件名" 序列
> 等级：**强制**　分类：预处理指令

\#include 指令后面应该紧跟着 <文件名> 或 "文件名" 序列。

**示例1：不规范用法**

```cpp
#include HEADER "filename.h"
#include another.h
```

**示例1：规范用法之一**

```cpp
#include "filename.h"
#include <filename.h>
```

### MISRA_CPP_2008_16_03_01_rule　在单个的宏定义中应该最多出现一个 # 或 ## 操作符
> 等级：**强制**　分类：预处理指令


与 # 和 ## 预处理器操作符相关的评估顺序是未指定的。
通过在单个宏定义中只有一个操作符出现（即一个 # 或一个 ## 或两者都没有），可以避免这个问题。

**示例1：不规范用法**

```cpp
#define TEST1(A,B,C) A # B # C // 违规
#define TEST2(A,B,C) A ## B # C //违规
#define TEST3(A,B,C) A ## B ## C // 违规
```

**示例1：规范用法之一**

```cpp
#define TEST2_1(A,B) A ## B // 合规
#define TEST2_2(C,D) C # D // 合规
```

### MISRA_CPP_2008_16_03_02_rule　不得使用 # 和 ## 操作符
> 等级：**推荐**　分类：预处理指令

不得使用 # 和 ## 操作符

**示例1：不规范用法**

```cpp
#define stringer( x ) printf( #x "\n" ) /* 违规 */
```

**示例1：规范用法之一**

```cpp
#define stringer( x ) printf( x "\n" ) /* 合规 */
```

### MISRA_CPP_2008_16_06_01_rule　所有使用#pragma指令的地方都必须有文档记录
> 等级：**文档**　分类：预处理指令


\#pragma 指令是由实现定义的，因此展示所有使用是正确的非常重要。
这个规则要求本文档的用户列出他们在应用程序中选择使用的任何 #pragma 列表。每个 #pragma 的含义都应该有文档记录。文档应当有足够的支撑描述来证明这个#pragma 的行为和它对应用程序的影响已经被充分理解了。
任何使用 #pragma 均应尽量减少，并在可能的情况下将其封装在专用函数中，以局部化和封装化 #pragma 的使用。

**示例1：不规范用法**

```cpp
#pragma message("This is a test message") //不合规，没有文档记录
class Example {
public:
  Example() : val_(0) {}
private:
  int val_;
};
```

**示例1：规范用法之一**

```cpp
// 确保头文件只被编译一次
#pragma once /* 合规，有注释说明 */
class Example {
public:
  Example() : val_(0) {}
private:
  int val_;
};
通过注释解释[#pragma]用途
```

---

## 第 17 章 库介绍（5 条）

### MISRA_CPP_2008_17_00_01_rule　不得定义，重定义或取消定义保留标识符，标准库中的宏和函数
> 等级：**强制**　分类：标准库

通常，在#undef一个标准库中定义的宏是错误的做法。#define一个作为C++保留标识符、C++关键字或标准库中任何宏名称、对象名或函数名的宏名称，也是不好的做法。例如，已知有一些特定的保留字和函数名称，如果它们被重新定义或未定义，包括defined、_ _LINE_ _、_ _FILE_ _、_ _DATE_ _、_ _TIME_ _、_ _STDC_ _、errno和assert，则会导致未定义的行为。
有关保留标识符的列表，请参阅ISO/IEC 14882:2003 [1]。通常，所有以下划线字符开头的标识符都会被保留。
请注意，无论实际包括哪些头文件（如果有），此规则都适用。

**示例1：不规范用法**

```cpp
define __TIME__ 11111111 // Non-compliant
```

**示例1：规范用法之一**

```cpp
define MY_TIME 11111111 // compliant
```

### MISRA_CPP_2008_17_00_02_rule　不得重复使用标准库宏和对象的名称
> 等级：**强制**　分类：标准库

如果开发人员使用新版本的标准库宏或对象（例如，增强功能或添加输入值检查），则修改后的宏或对象应具有新名称。这是为了避免混淆是使用标准宏或对象，还是使用它们的修改版本

**示例1：不规范用法**

```cpp
#define NULL ( a > b ) // Non-compliant
```

**示例1：规范用法之一**

```cpp
#define P_NULL nullptr // compliant
```

### MISRA_CPP_2008_17_00_03_rule　标准库函数的名称不应被覆盖
> 等级：**强制**　分类：库介绍

如果开发人员使用新版本的标准库函数（例如，增强功能或添加输入值检查），则修改后的函数应具有新名称。但是，如果功能与原始参数类型一致，则允许重载名称以添加新的参数类型。这样可以确保与名称相关联的行为保持一致。因此，例如，如果编写新版本的sqrt函数来检查输入是否为负数，则新函数不应命名为“sqrt”，而是应赋予一个新名称。允许为库中不存在的类型添加新的sqrt函数。

**示例1：不规范用法**

```cpp
int32_t printf(int32_t a, int32_t b) // Non-compliant
{
  return ((a > b) ? a : b);
}
```

**示例1：规范用法之一**

```cpp
int32_t printf_good(int32_t a, int32_t b) // compliant
{
  return ((a > b) ? a : b);
}
```

### MISRA_CPP_2008_17_00_04_rule　所有库代码应符合MISRA C++
> 等级：**文档**　分类：库介绍

任何库（被链接的或被包含的）的质量必须至少达到与其他库相同的标准（即SIL级别）项目。库代码可以作为源代码或目标代码存在。任何一种类型都应包括证明该代码符合MISRA C++的文件。

> 原文未给出该条的代码示例。

### MISRA_CPP_2008_17_00_05_rule　不得使用 setjmp 宏和 longjmp 函数
> 等级：**强制**　分类：标准库

不应使用setjmp和longjmp，它们允许绕过正常的函数调用机制。异常处理为此提供了一个更好的定义机制。

**示例1：不规范用法**

```cpp
#include <setjmp.h>
void f2();
jmp_buf buf;
void f1() {
  if (!setjmp(buf)) // Non-compliant
  {
    f2();
  } else {
  }
}
void f2() {
  longjmp(buf, 10); // Non-compliant
}
```

---

## 第 18 章 语言支持库（8 条）

### MISRA_CPP_2008_18_00_01_rule　不应使用C语言的库
> 等级：**强制**　分类：语言支持库

一些C++库（例如<cstdio>）也有相应的C版本（例如<stdio.h>）。此规则要求使用C++版本。

**示例1：不规范用法**

```cpp
#include <stdio.h>
```

**示例1：规范用法之一**

```cpp
#include <cstdio>
```

### MISRA_CPP_2008_18_00_02_rule　不应使用来自库<cstdlib>的atof、atoi和atol库函数
> 等级：**强制**　分类：语言支持库

当字符串无法转换时，这些函数具有与它们关联的未定义行为

**示例1：不规范用法**

```cpp
#include <cstdlib>
int32_t f(const char_t *numstr) {
  return atoi(numstr); // Non-compliant
}
```

### MISRA_CPP_2008_18_00_03_rule　不得使用来自库<cstdlib>的abort、exit、 getenv和system库函数
> 等级：**强制**　分类：语言支持库

使用这些函数会导致实现定义的行为。

**示例1：不规范用法**

```cpp
#include <cstdlib>
void f() {
  exit(0); // Non-compliant
}
```

### MISRA_CPP_2008_18_00_04_rule　不应使用库<ctime>的时间处理函数
> 等级：**强制**　分类：语言支持库

各个方面都是实现定义的或未指定的，例如时间的格式。

**示例1：不规范用法**

```cpp
#include <ctime>
void f() {
  clock(); // Non-compliant
}
```

### MISRA_CPP_2008_18_00_05_rule　不应使用库<cstring>的无界函数
> 等级：**强制**　分类：语言支持库

库中的strcpy、strcmp、strcat、strchr、strspn、strcspn、strpbrk、strrchr、strstr、strtok和strlen函数可以在缓冲区末尾之外读取或写入，从而导致未定义的行为。 理想情况下，应使用安全的字符串处理库。

**示例1：不规范用法**

```cpp
#include <cstring>
void fn(const char_t *pChar) {
  char_t array[10];
  strcpy(array, pChar); // Non-compliant
}
```

### MISRA_CPP_2008_18_02_01_rule　不应使用宏offsetof
> 等级：**强制**　分类：语言支持库

当操作数的类型不兼容或使用位域时，使用此宏可能会导致未定义的行为。

**示例1：不规范用法**

```cpp
#include <cstddef>
struct A {
  int32_t i;
};
void f1() {
  offsetof(A, i); // Non-compliant
}
```

### MISRA_CPP_2008_18_04_01_rule　不应使用动态堆内存分配
> 等级：**强制**　分类：语言支持库

使用动态内存可能会导致存储不足的运行时故障，这是不可取的。除了放置版本之外，内置的new和delete运算符使用动态堆内存。函数calloc、malloc、realloc和free也使用动态堆内存。
有许多与动态内存分配相关的未指定、未定义和实现定义的行为，以及许多其他潜在的陷阱。动态堆内存分配可能导致内存泄漏、数据不一致、内存耗尽、不确定性行为等。
请注意，一些工具可能使用动态堆内存分配来实现其他函数（例如，库cstring中的函数）。如果是这种情况，则也应避免使用这些功能。

**示例1：不规范用法**

```cpp
void f1() {
  int32_t *i = new int32_t; // Non-compliant
  delete i;
}
```

### MISRA_CPP_2008_18_07_01_rule　不应使用信号处理工具<csignal.h>
> 等级：**强制**　分类：语言支持库

信号处理包含了实现定义的和未定义的行为。

**示例1：不规范用法**

```cpp
#include <csignal>
void my_handler(int32_t);
void f1() {
  signal(1, my_handler); // Non-compliant
}
```

---

## 第 19 章 诊断库（1 条）

### MISRA_CPP_2008_19_03_01_rule　不得使用 errno 错误标识
> 等级：**强制**　分类：错误标识

不应使用错误指示器errno。
errno是C++的一种工具，理论上应该是有用的，但在实践中，ISO/IEC 14882:2003[1]对它的定义很差。非零值可以也可以不表明问题已经发生；因此，不应使用errno。即使是那些定义了errno行为的函数，最好在调用函数之前检查输入的值，而不是依靠使用errno来捕获错误。

**示例1：不规范用法**

```cpp
#include <cstdlib>
#include <cerrno>
void f1(const char_t *str) {
  errno = 0; // Non-compliant
  int32_t i = atoi(str);
  if (0 != errno) // Non-compliant
  {
    // handle error case???
  }
}
```

**示例1：规范用法之一**

```cpp
#include <cstdlib>
void f1(const char_t *str) {
  if(str != NULL) {
    int32_t i = atoi(str);
  }
}
```

---

## 第 27 章 输入输出库（1 条）

### MISRA_CPP_2008_27_00_01_rule　不应使用流输入输出库<cstdio>
> 等级：**强制**　分类：输入输出库


流输入/输出库<cstdio> 包含文件和 I/O 函数 fgetpos、fopen、ftell、gets、perror、remove、rename 和 ungetc。文件 I/O 具有大量未指定的、未定义的和实现定义的行为。

**示例1：不规范用法**

```cpp
#include <cstdio> // Non-compliant
void fn() {
  char_t array[10];
  gets(array); // Can lead to buffer over-run
}
```

**示例1：规范用法之一**

```cpp
#include <iostrem> // compliant
void fn() {
  char_t array[10];
  std::cin.getline(array, 10);
}
```

---
